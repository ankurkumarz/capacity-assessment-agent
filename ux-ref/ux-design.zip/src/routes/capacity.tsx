import { createFileRoute } from "@tanstack/react-router";
import { AppShell, PageHeader, usePersona, useScenario } from "@/components/AppShell";
import { ChatDrawer } from "@/components/ChatDrawer";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { POOLS } from "@/lib/mock-data";

export const Route = createFileRoute("/capacity")({
  head: () => ({
    meta: [
      { title: "Capacity — CORE_COMPUTE" },
      { name: "description", content: "Live GPU pool inventory, allocations, and maintenance state." },
      { property: "og:title", content: "Capacity — CORE_COMPUTE" },
      { property: "og:description", content: "Pool health, utilization, and maintenance windows." },
    ],
  }),
  component: CapacityPage,
});

function CapacityPage() {
  return (
    <AppShell>
      <CapacityContent />
    </AppShell>
  );
}

function CapacityContent() {
  const { persona } = usePersona();
  const isExecutive = persona === "requester";
  const { scenario } = useScenario();
  const totalGpus = POOLS.reduce((a, p) => a + p.total, 0);
  const alloc = POOLS.reduce((a, p) => a + p.allocated, 0);
  const live = POOLS.reduce((a, p) => a + p.live, 0);

  return (
    <>
      <PageHeader
        breadcrumb={<span>Capacity · pools</span>}
        status={{ label: "1 POOL FROZEN", tone: "warn" }}
        actions={
          <button
            disabled={persona !== "sre"}
            className="bg-brand text-surface px-4 py-1.5 rounded text-xs font-bold hover:brightness-110 disabled:opacity-40 disabled:cursor-not-allowed"
            title={persona !== "sre" ? "owned by: sre" : ""}
          >
            {persona === "sre" ? "CONFIRM MAINTENANCE" : "CONFIRM (owned by: sre)"}
          </button>
        }
      />
      <div className="flex-1 overflow-auto p-6 space-y-6">
        <div className="grid grid-cols-4 gap-4">
          <Kpi label="Total GPUs" value={totalGpus.toString()} />
          <Kpi label="Allocated" value={alloc.toString()} sub={`${((alloc / totalGpus) * 100).toFixed(1)}%`} />
          <Kpi label="Live utilization" value={live.toString()} sub={`${((live / totalGpus) * 100).toFixed(1)}%`} />
          <Kpi label="Reserved (pool G)" value="24" tone="brand" />
        </div>

        {isExecutive ? (
          <Collapsible>
            <CollapsibleTrigger className="text-[10px] font-mono uppercase tracking-widest text-brand hover:underline">
              Show technical detail ▾
            </CollapsibleTrigger>
            <CollapsibleContent className="space-y-6 mt-4">
              <PoolTable scenario={scenario} />
              <Heatmap />
            </CollapsibleContent>
          </Collapsible>
        ) : (
          <>
            <PoolTable scenario={scenario} />
            <Heatmap />
          </>
        )}
      </div>
      <ChatDrawer scenario={scenario} />
    </>
  );
}

function PoolTable({ scenario }: { scenario: ReturnType<typeof useScenario>["scenario"] }) {
  return (
    <div className="bg-panel rounded-xl border border-border overflow-hidden">
      <table className="w-full text-left text-xs">
        <thead>
          <tr className="bg-panel-2/50 border-b border-border text-text-dim">
            <th className="p-3 font-medium">Pool</th>
            <th className="p-3 font-medium">Region</th>
            <th className="p-3 font-medium">Data Center</th>
            <th className="p-3 font-medium">Cluster</th>
            <th className="p-3 font-medium">Source</th>
            <th className="p-3 font-medium">GPU class</th>
            <th className="p-3 font-medium text-right">Total</th>
            <th className="p-3 font-medium text-right">Allocated</th>
            <th className="p-3 font-medium text-right">Live</th>
            <th className="p-3 font-medium">Occupancy</th>
            <th className="p-3 font-medium">State</th>
            <th className="p-3 font-medium">Candidacy (current scenario)</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-border font-mono">
          {POOLS.map((p) => (
            <tr key={p.id} className="hover:bg-panel-2/40">
              <td className="p-3 text-brand">{p.id}</td>
              <td className="p-3 text-text-dim">{p.region}</td>
              <td className="p-3 text-text-dim">{p.dataCenter}</td>
              <td className="p-3 text-text-dim">{p.cluster}</td>
              <td className="p-3 text-text-dim">{p.source}</td>
              <td className="p-3">{p.gpu}</td>
              <td className="p-3 text-right">{p.total}</td>
              <td className="p-3 text-right">{p.allocated}</td>
              <td className="p-3 text-right">{p.live}</td>
              <td className="p-3">
                <Heat total={p.total} live={p.live} allocated={p.allocated} />
              </td>
              <td className="p-3">
                {p.maintenance ? (
                  <span className="px-2 py-0.5 border border-warn/40 text-warn rounded text-[10px]">
                    {p.maintenance}
                  </span>
                ) : (
                  <span className="text-ok text-[10px]">healthy</span>
                )}
              </td>
              <td className="p-3 text-[10px] font-mono">
                {(() => {
                  const c = scenario.candidacy.find((x) => x.pool === p.id);
                  if (!c) return <span className="text-text-dim">—</span>;
                  const tone = c.verdict === "chosen" ? "text-ok" : c.verdict === "blocked" ? "text-bad" : "text-text-dim";
                  const glyph = c.verdict === "chosen" ? "✓" : c.verdict === "blocked" ? "✗" : "○";
                  return <span className={tone}>{glyph} {c.verdict} · {c.reason}</span>;
                })()}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Heatmap() {
  return (
    <div className="bg-panel rounded-xl border border-border p-6">
      <h3 className="text-sm font-bold uppercase tracking-widest mb-4">Occupancy heatmap · pool B (56 × NVIDIA H200)</h3>
      <div className="grid gap-1.5" style={{ gridTemplateColumns: "repeat(14, minmax(0, 1fr))" }}>
        {Array.from({ length: 56 }).map((_, i) => {
          const shade = i < 49 ? "bg-brand" : i < 52 ? "bg-brand/40" : "bg-panel-2";
          const flag = i === 27 ? "bg-warn" : shade;
          return <div key={i} className={`aspect-square rounded-xs ${flag}`} />;
        })}
      </div>
      <div className="mt-3 flex justify-between text-[10px] font-mono text-text-dim">
        <span>as_of: 14:03:12Z · sample 5m</span>
        <span>1 amber MIG slice · 49/56 live · 87.5% util</span>
      </div>
    </div>
  );
}

function Kpi({ label, value, sub, tone }: { label: string; value: string; sub?: string; tone?: "brand" }) {
  return (
    <div className="bg-panel border border-border rounded-xl p-4">
      <div className="text-[10px] font-bold uppercase tracking-widest text-text-dim">{label}</div>
      <div className={`text-2xl font-mono mt-2 ${tone === "brand" ? "text-brand" : ""}`}>{value}</div>
      {sub && <div className="text-[10px] text-text-dim mt-1 font-mono">{sub}</div>}
    </div>
  );
}

function Heat({ total, live, allocated }: { total: number; live: number; allocated: number }) {
  const pct = (n: number) => `${(n / total) * 100}%`;
  return (
    <div className="w-40 h-2 bg-panel-2 rounded relative overflow-hidden">
      <div className="absolute inset-y-0 left-0 bg-brand/30" style={{ width: pct(allocated) }} />
      <div className="absolute inset-y-0 left-0 bg-brand" style={{ width: pct(live) }} />
    </div>
  );
}
