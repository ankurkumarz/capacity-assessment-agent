import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { AppShell, PageHeader, usePersona, useScenario } from "@/components/AppShell";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChatDrawer } from "@/components/ChatDrawer";
import { applyWhatIf, DEFAULT_WHATIF, type WhatIfParams } from "@/lib/whatif";
import {
  Area, CartesianGrid, ComposedChart, Line, ReferenceLine,
  ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";

export const Route = createFileRoute("/forecast")({
  head: () => ({
    meta: [
      { title: "Forecast — CORE_COMPUTE" },
      { name: "description", content: "180-day peak_rps forecast with breach-day vs lead-time countdown, backtest folds, and coverage gaps." },
      { property: "og:title", content: "Forecast — CORE_COMPUTE" },
      { property: "og:description", content: "Breach-vs-lead-time countdown driving procurement." },
    ],
  }),
  component: ForecastPage,
});

function ForecastPage() {
  return (
    <AppShell>
      <ForecastContent />
    </AppShell>
  );
}

function ForecastContent() {
  const { scenario } = useScenario();
  const { persona } = usePersona();
  const isExecutive = persona === "requester";
  const [whatIf, setWhatIf] = useState<WhatIfParams>(DEFAULT_WHATIF);
  const [metric, setMetric] = useState<"gpu" | "tokens">("gpu");
  const f = useMemo(() => applyWhatIf(scenario.forecast, whatIf), [scenario.forecast, whatIf]);
  const metricScale = metric === "tokens" ? scenario.sizing.outTokens : 1;
  const metricUnit = metric === "tokens" ? "tok/s" : "rps";
  const data = f.baseline.map((v, i) => ({
    day: i,
    baseline: v * metricScale,
    p10: f.p10[i] * metricScale,
    p90: f.p90[i] * metricScale,
    band: [f.p10[i] * metricScale, (f.p90[i] - f.p10[i]) * metricScale],
  }));
  const runway = f.breachDay == null ? null : f.breachDay - f.leadTimeDays;
  const countdown = f.breachDay == null
    ? "no breach projected in the 180-day window"
    : runway! <= 0
      ? `breach at day ${f.breachDay} · 74d lead time · order NOW — lead time exceeds runway`
      : `breach at day ${f.breachDay} · 74d lead time · ${runway} days before ordering must start`;
  const tone = f.breachDay == null ? "ok" : runway! <= 0 ? "bad" : "warn";
  const avgMape = f.quality.folds.reduce((a, x) => a + x.mape, 0) / f.quality.folds.length;

  return (
    <>
      <PageHeader
        breadcrumb={<><span>Forecast</span><span className="text-border">/</span><span className="text-foreground">{scenario.sizing.model} · 180d</span></>}
        status={{ label: countdown.toUpperCase(), tone: tone as "ok" | "warn" | "bad" }}
        actions={<span className="text-[10px] font-mono text-text-dim">{f.quality.model} · trained {f.quality.trained}</span>}
      />
      <div className="flex-1 overflow-auto p-6 space-y-6">
        {isExecutive ? (
          <div className="bg-panel border border-border rounded-xl p-4 flex items-center gap-4">
            <span className="text-[10px] font-mono uppercase tracking-widest text-text-dim">Growth scenario</span>
            <select
              value={whatIf.growthPct}
              onChange={(e) => setWhatIf((w) => ({ ...w, growthPct: Number(e.target.value) }))}
              className="bg-panel-2 border border-border text-sm rounded p-2 outline-none focus:border-brand"
            >
              <option value={-20}>Slower than expected</option>
              <option value={0}>As expected</option>
              <option value={50}>Faster than expected</option>
              <option value={100}>Much faster than expected</option>
            </select>
          </div>
        ) : (
          <div className="bg-panel border border-border rounded-xl p-4 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold uppercase tracking-widest">What-if controls</h3>
              <div className="flex gap-2 text-[10px] font-mono">
                <button
                  onClick={() => setMetric("gpu")}
                  className={`px-2 py-1 rounded border ${metric === "gpu" ? "border-brand text-brand bg-brand/10" : "border-border text-text-dim"}`}
                >
                  GPU Impact
                </button>
                <button
                  onClick={() => setMetric("tokens")}
                  className={`px-2 py-1 rounded border ${metric === "tokens" ? "border-brand text-brand bg-brand/10" : "border-border text-text-dim"}`}
                >
                  Tokens/sec Impact
                </button>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-6">
              <div>
                <div className="flex justify-between text-[10px] font-mono text-text-dim mb-2">
                  <span>Demand growth</span><span>{whatIf.growthPct > 0 ? "+" : ""}{whatIf.growthPct}%</span>
                </div>
                <Slider
                  value={[whatIf.growthPct]}
                  min={-20} max={100} step={5}
                  onValueChange={([v]) => setWhatIf((w) => ({ ...w, growthPct: v }))}
                />
              </div>
              <div>
                <div className="flex justify-between text-[10px] font-mono text-text-dim mb-2">
                  <span>Pool size delta</span><span>{whatIf.poolDeltaGpus > 0 ? "+" : ""}{whatIf.poolDeltaGpus} GPU</span>
                </div>
                <Slider
                  value={[whatIf.poolDeltaGpus]}
                  min={-40} max={40} step={5}
                  onValueChange={([v]) => setWhatIf((w) => ({ ...w, poolDeltaGpus: v }))}
                />
              </div>
              <div className="flex items-center gap-3">
                <span className="text-[10px] font-mono text-text-dim">Traffic spike (+40%, 2wk)</span>
                <Switch checked={whatIf.spike} onCheckedChange={(v: boolean) => setWhatIf((w) => ({ ...w, spike: v }))} />
              </div>
            </div>
          </div>
        )}
        <div className="grid grid-cols-4 gap-4">
          <Kpi label="Baseline day 180" value={(f.baseline[179] * metricScale).toFixed(1)} unit={metricUnit} />
          <Kpi label="p90 day 180" value={(f.p90[179] * metricScale).toFixed(1)} unit={metricUnit} tone="warn" />
          <Kpi label="Policy line" value={(f.policyLine * metricScale).toFixed(0)} unit={metricUnit} />
          <Kpi label="Backtest MAPE" value={`${(avgMape * 100).toFixed(1)}%`} unit="" tone={avgMape < 0.1 ? "ok" : "warn"} />
        </div>

        <div className="bg-panel rounded-xl border border-border p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-bold uppercase tracking-widest">180-day peak_rps</h2>
            <div className="flex gap-2 text-[10px] font-mono">
              <span className="px-2 py-0.5 border border-brand/40 text-brand rounded">baseline</span>
              <span className="px-2 py-0.5 border border-brand/20 text-text-dim rounded">p10–p90 band</span>
              <span className="px-2 py-0.5 border border-bad/40 text-bad rounded">policy line</span>
              {f.breachDay != null && <span className="px-2 py-0.5 border border-warn/40 text-warn rounded">breach day</span>}
            </div>
          </div>
          <div className="h-80">
            <ResponsiveContainer>
              <ComposedChart data={data} margin={{ top: 8, right: 8, bottom: 8, left: 0 }}>
                <CartesianGrid stroke="oklch(0.32 0.02 260)" strokeDasharray="2 4" />
                <XAxis dataKey="day" stroke="oklch(0.65 0.02 260)" tick={{ fontSize: 10, fontFamily: "JetBrains Mono" }} tickFormatter={(d) => `D+${d}`} />
                <YAxis stroke="oklch(0.65 0.02 260)" tick={{ fontSize: 10, fontFamily: "JetBrains Mono" }} />
                <Tooltip contentStyle={{ background: "oklch(0.21 0.018 260)", border: "1px solid oklch(0.32 0.02 260)", fontSize: 11, fontFamily: "JetBrains Mono" }} labelFormatter={(d) => `Day +${d}`} />
                <Area type="monotone" dataKey="band" stroke="none" fill="oklch(0.87 0.16 200)" fillOpacity={0.12} />
                <Line type="monotone" dataKey="baseline" stroke="oklch(0.87 0.16 200)" strokeWidth={2} dot={false} />
                <ReferenceLine y={f.policyLine * metricScale} stroke="oklch(0.65 0.22 25)" strokeDasharray="4 3" label={{ value: `policy ${(f.policyLine * metricScale).toFixed(0)}`, position: "right", fill: "oklch(0.65 0.22 25)", fontSize: 10 }} />
                {f.breachDay != null && (
                  <ReferenceLine x={f.breachDay} stroke="oklch(0.75 0.17 55)" strokeDasharray="4 3" label={{ value: `breach D+${f.breachDay}`, position: "top", fill: "oklch(0.75 0.17 55)", fontSize: 10 }} />
                )}
                {f.breachDay != null && f.breachDay - f.leadTimeDays > 0 && (
                  <ReferenceLine x={f.breachDay - f.leadTimeDays} stroke="oklch(0.75 0.17 55 / 0.5)" strokeDasharray="2 6" label={{ value: `order-by D+${f.breachDay - f.leadTimeDays}`, position: "bottom", fill: "oklch(0.75 0.17 55)", fontSize: 10 }} />
                )}
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </div>

        {isExecutive ? (
          <Collapsible>
            <CollapsibleTrigger className="text-[10px] font-mono uppercase tracking-widest text-brand hover:underline">
              Show technical detail ▾
            </CollapsibleTrigger>
            <CollapsibleContent className="mt-4">
              <div className="grid grid-cols-2 gap-6">
                <div className="bg-panel rounded-xl border border-border p-6">
                  <h3 className="text-sm font-bold uppercase tracking-widest mb-4">Backtest folds</h3>
                  <div className="space-y-2 font-mono text-xs">
                    {f.quality.folds.map((fold) => (
                      <div key={fold.fold} className="flex justify-between items-center border-b border-border pb-2">
                        <span className="text-text-dim">fold {fold.fold}</span>
                        <span className={fold.mape < 0.1 ? "text-ok" : "text-warn"}>MAPE {(fold.mape * 100).toFixed(1)}%</span>
                      </div>
                    ))}
                    <div className="flex justify-between pt-1"><span className="text-text-dim">avg</span><span className={avgMape < 0.1 ? "text-ok" : "text-warn"}>{(avgMape * 100).toFixed(1)}%</span></div>
                  </div>
                </div>
                <div className="bg-panel rounded-xl border border-border p-6">
                  <h3 className="text-sm font-bold uppercase tracking-widest mb-4">Coverage</h3>
                  <Coverage label="Series present" pct={Math.round(f.coverage.present * 100)} warn={f.coverage.present < 0.9} />
                  <div className="mt-3 font-mono text-[11px] text-text-dim space-y-1">
                    <div>gaps: <span className="text-foreground">{f.coverage.gaps}</span></div>
                    <div>longest gap: <span className="text-foreground">{f.coverage.longestGapDays}d</span></div>
                    <div>policy_line: <span className="text-foreground">{(f.policyLine * metricScale).toFixed(0)} {metricUnit}</span></div>
                    <div>lead_time: <span className="text-foreground">{f.leadTimeDays}d</span></div>
                  </div>
                </div>
              </div>
            </CollapsibleContent>
          </Collapsible>
        ) : (
          <div className="grid grid-cols-2 gap-6">
            <div className="bg-panel rounded-xl border border-border p-6">
              <h3 className="text-sm font-bold uppercase tracking-widest mb-4">Backtest folds</h3>
              <div className="space-y-2 font-mono text-xs">
                {f.quality.folds.map((fold) => (
                  <div key={fold.fold} className="flex justify-between items-center border-b border-border pb-2">
                    <span className="text-text-dim">fold {fold.fold}</span>
                    <span className={fold.mape < 0.1 ? "text-ok" : "text-warn"}>MAPE {(fold.mape * 100).toFixed(1)}%</span>
                  </div>
                ))}
                <div className="flex justify-between pt-1"><span className="text-text-dim">avg</span><span className={avgMape < 0.1 ? "text-ok" : "text-warn"}>{(avgMape * 100).toFixed(1)}%</span></div>
              </div>
            </div>
            <div className="bg-panel rounded-xl border border-border p-6">
              <h3 className="text-sm font-bold uppercase tracking-widest mb-4">Coverage</h3>
              <Coverage label="Series present" pct={Math.round(f.coverage.present * 100)} warn={f.coverage.present < 0.9} />
              <div className="mt-3 font-mono text-[11px] text-text-dim space-y-1">
                <div>gaps: <span className="text-foreground">{f.coverage.gaps}</span></div>
                <div>longest gap: <span className="text-foreground">{f.coverage.longestGapDays}d</span></div>
                <div>policy_line: <span className="text-foreground">{(f.policyLine * metricScale).toFixed(0)} {metricUnit}</span></div>
                <div>lead_time: <span className="text-foreground">{f.leadTimeDays}d</span></div>
              </div>
            </div>
          </div>
        )}
      </div>
      <ChatDrawer scenario={scenario} />
    </>
  );
}

function Kpi({ label, value, unit, tone }: { label: string; value: string; unit: string; tone?: "warn" | "ok" }) {
  const c = tone === "warn" ? "text-warn" : tone === "ok" ? "text-ok" : "text-foreground";
  return (
    <div className="bg-panel border border-border rounded-xl p-4">
      <div className="text-[10px] font-bold uppercase tracking-widest text-text-dim">{label}</div>
      <div className={`text-2xl font-mono mt-2 ${c}`}>{value} <span className="text-xs text-text-dim">{unit}</span></div>
    </div>
  );
}
function Coverage({ label, pct, warn }: { label: string; pct: number; warn?: boolean }) {
  return (
    <div>
      <div className="flex justify-between font-mono text-[11px]"><span className="text-text-dim">{label}</span><span className={warn ? "text-warn" : "text-foreground"}>{pct}%</span></div>
      <div className="mt-1 h-1.5 bg-panel-2 rounded overflow-hidden"><div className={warn ? "h-full bg-warn" : "h-full bg-brand"} style={{ width: `${pct}%` }} /></div>
    </div>
  );
}
