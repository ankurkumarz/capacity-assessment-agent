"use client";

import { useSearchParams } from "next/navigation";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AppShell, PageHeader, usePersona, useScenario } from "@/components/AppShell";
import { WORKFLOW } from "@/lib/engine";
import { buildTrace, type TraceLine } from "@/lib/run-trace";
import { manifestText, SCENARIOS, SCENARIO_ORDER, type LadderRung, type PumaTool, type Scenario } from "@/lib/scenarios";
import { DecisionBanner } from "@/components/DecisionBanner";
import { ExecutiveSummaryCard } from "@/components/ExecutiveSummaryCard";
import { ChatDrawer } from "@/components/ChatDrawer";
import { ToolBadgeRow } from "@/components/ToolBadge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

const NODE_W = 150;
const NODE_H = 44;
const NODE_GAP = 40;

type NodeStatus = "pending" | "running" | "done";
type Phase = "idle" | "running" | "done";

const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

function useRunner(scenario: Scenario) {
  const trace = useMemo(() => buildTrace(scenario), [scenario]);
  const [phase, setPhase] = useState<Phase>("idle");
  const [status, setStatus] = useState<Record<string, NodeStatus>>({});
  const [log, setLog] = useState<{ node: string; line: TraceLine }[]>([]);
  const runIdRef = useRef(0);

  const start = useCallback(async () => {
    const myRun = ++runIdRef.current;
    setPhase("running");
    setStatus(Object.fromEntries(trace.map((s) => [s.id, "pending" as NodeStatus])));
    setLog([]);
    for (const step of trace) {
      if (runIdRef.current !== myRun) return;
      setStatus((p) => ({ ...p, [step.id]: "running" }));
      const per = Math.max(160, step.ms / Math.max(1, step.lines.length));
      for (const line of step.lines) {
        await sleep(per);
        if (runIdRef.current !== myRun) return;
        setLog((l) => [...l, { node: step.id, line }]);
      }
      await sleep(140);
      if (runIdRef.current !== myRun) return;
      setStatus((p) => ({ ...p, [step.id]: "done" }));
    }
    setPhase("done");
  }, [trace]);

  const reset = useCallback(() => {
    runIdRef.current++;
    setPhase("idle");
    setStatus({});
    setLog([]);
  }, []);

  return { phase, status, log, start, reset, trace };
}

export default function RunDetail({ id }: { id: string }) {
  return (
    <AppShell>
      <RunDetailContent id={id} />
    </AppShell>
  );
}

function RunDetailContent({ id }: { id: string }) {
  const searchParams = useSearchParams();
  const run = searchParams.get("run") ?? undefined;
  const { scenario: current } = useScenario();
  const { persona } = usePersona();
  const isExecutive = persona === "requester";
  // Pick the scenario whose record matches, else fall through to selected scenario.
  const matched = SCENARIO_ORDER.map((sid) => SCENARIOS[sid]).find((s) => s.record.id === id);
  const scenario = matched ?? current;
  const [selected, setSelected] = useState<string>("planning");
  const [evidenceOpen, setEvidenceOpen] = useState(false);
  const { phase, status: nodeStatus, log, start, reset } = useRunner(scenario);

  // Auto-run when arriving via the sidebar's "Run scenario" action.
  useEffect(() => {
    reset();
    if (run) void start();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scenario.id, run]);

  const revealed = (nodeId: string) => phase === "idle" || nodeStatus[nodeId] === "done";

  const nodes = useMemo(
    () => WORKFLOW.nodes.map((n, i) => ({ ...n, x: 30 + i * (NODE_W + NODE_GAP), y: 200 })),
    [],
  );
  const selNode = nodes.find((n) => n.id === selected) ?? nodes[0];

  const toneMap = {
    ok: { label: "AVAILABLE / READY", tone: "ok" as const },
    warn: { label: scenario.recommendation.state.toUpperCase(), tone: "warn" as const },
    bad: { label: scenario.recommendation.state.toUpperCase(), tone: "bad" as const },
    info: { label: scenario.recommendation.state.toUpperCase(), tone: "info" as const },
  };
  const status = toneMap[scenario.recommendation.tone];

  return (
    <>
      <PageHeader
        breadcrumb={
          <>
            <span>Run detail</span>
            <span className="text-border">/</span>
            <span className="text-foreground">{scenario.record.id}</span>
            <span className="text-border">/</span>
            <span>{scenario.sizing.model}</span>
            <span className="text-border">/</span>
            <span className="font-mono text-[10px]">hash {scenario.recommendation.hash}</span>
          </>
        }
        status={status}
        actions={
          <>
            <button
              onClick={() => (phase === "running" ? reset() : void start())}
              className="border border-brand/50 text-brand text-xs px-3 py-1.5 rounded hover:bg-brand/10 font-mono uppercase tracking-widest"
            >
              {phase === "running" ? "■ Stop" : phase === "done" ? "↻ Replay" : "▶ Run"}
            </button>
            <HeaderActions />
          </>
        }
      />
      <div className="flex-1 flex overflow-hidden">
        <section className="flex-1 overflow-auto p-6 space-y-6">
          <DecisionBanner scenario={scenario} />

          {isExecutive ? (
            <>
              <ExecutiveSummaryCard scenario={scenario} />
              <ExecutiveWorkflow />
              <Collapsible>
                <CollapsibleTrigger className="text-[10px] font-mono uppercase tracking-widest text-brand hover:underline">
                  Show technical detail ▾
                </CollapsibleTrigger>
                <CollapsibleContent className="space-y-6 mt-4">
                  <GuardrailBar scenario={scenario} />
                  {scenario.hitl && (
                    <Reveal on={revealed("input_review")}>
                      <HitlPanel scenario={scenario} />
                    </Reveal>
                  )}

                  <div className="mb-1 flex items-center justify-between">
                    <h2 className="text-sm font-bold uppercase tracking-widest text-text-dim">
                      Workflow · agents (rounded) → deterministic engine (hard-edged) → record
                    </h2>
                    <div className="flex gap-3 text-[10px] font-mono text-text-dim">
                      <Legend swatch="rounded-full bg-panel border border-border" label="agent" />
                      <Legend swatch="rounded-none bg-brand/20 border border-brand" label="engine" />
                      <Legend swatch="rounded-sm bg-ok/20 border border-ok" label="record" />
                    </div>
                  </div>
                  <Graph nodes={nodes} selected={selected} onSelect={setSelected} status={nodeStatus} phase={phase} />
                  <RunConsole log={log} phase={phase} onRun={() => void start()} />

                  <Reveal on={revealed("planning")}>
                    <SizingDerivation scenario={scenario} />
                  </Reveal>
                  <Reveal on={revealed("planning")}>
                    <CandidacyTable scenario={scenario} />
                  </Reveal>
                  <Reveal on={revealed("planning")}>
                    <PlanningLadder rungs={scenario.ladder} />
                  </Reveal>
                  <Reveal on={revealed("record")}>
                    <EvidenceManifest scenario={scenario} />
                  </Reveal>
                </CollapsibleContent>
              </Collapsible>
            </>
          ) : (
            <>
              <GuardrailBar scenario={scenario} />
              {scenario.hitl && (
                <Reveal on={revealed("input_review")}>
                  <HitlPanel scenario={scenario} />
                </Reveal>
              )}

              <div className="mb-1 flex items-center justify-between">
                <h2 className="text-sm font-bold uppercase tracking-widest text-text-dim">
                  Workflow · agents (rounded) → deterministic engine (hard-edged) → record
                </h2>
                <div className="flex gap-3 text-[10px] font-mono text-text-dim">
                  <Legend swatch="rounded-full bg-panel border border-border" label="agent" />
                  <Legend swatch="rounded-none bg-brand/20 border border-brand" label="engine" />
                  <Legend swatch="rounded-sm bg-ok/20 border border-ok" label="record" />
                </div>
              </div>
              <Graph nodes={nodes} selected={selected} onSelect={setSelected} status={nodeStatus} phase={phase} />
              <RunConsole log={log} phase={phase} onRun={() => void start()} />

              <Reveal on={revealed("planning")}>
                <SizingDerivation scenario={scenario} />
              </Reveal>
              <Reveal on={revealed("planning")}>
                <CandidacyTable scenario={scenario} />
              </Reveal>
              <Reveal on={revealed("planning")}>
                <PlanningLadder rungs={scenario.ladder} />
              </Reveal>
              <Reveal on={revealed("record")}>
                <EvidenceManifest scenario={scenario} />
              </Reveal>
            </>
          )}
        </section>

        <aside
          className={`relative border-l border-border flex flex-col overflow-hidden bg-panel/40 transition-[width] duration-200 ${
            evidenceOpen ? "w-[420px]" : "w-9"
          }`}
        >
          <button
            onClick={() => setEvidenceOpen((v) => !v)}
            title={evidenceOpen ? "Collapse evidence panel" : "Expand evidence panel"}
            className="absolute top-2 left-1.5 z-10 border border-border rounded text-text-dim hover:text-brand hover:border-brand/50 bg-panel w-6 h-6 flex items-center justify-center text-xs font-mono"
          >
            {evidenceOpen ? "»" : "«"}
          </button>
          {evidenceOpen ? (
            <EvidenceRail scenario={scenario} nodeId={selNode.id} nodeLabel={selNode.label} nodeKind={selNode.kind} />
          ) : (
            <div className="flex-1 flex items-center justify-center">
              <span className="text-[10px] font-mono uppercase tracking-widest text-text-dim [writing-mode:vertical-rl] rotate-180">
                Evidence
              </span>
            </div>
          )}
        </aside>
      </div>
      <ChatDrawer scenario={scenario} />
    </>
  );
}

function HeaderActions() {
  const { persona } = usePersona();
  const disabled = persona !== "capacity_manager";
  const title = disabled ? "owned by: capacity_manager" : "";
  return (
    <>
      <button disabled={disabled} title={title} className="border border-border text-xs px-3 py-1.5 rounded hover:bg-panel disabled:opacity-40">
        REQUEST REVISION
      </button>
      <button disabled={disabled} title={title} className="bg-brand text-surface px-4 py-1.5 rounded text-xs font-bold hover:brightness-110 disabled:opacity-40 disabled:cursor-not-allowed">
        APPROVE
      </button>
    </>
  );
}

const WORKFLOW_STAGES: { label: string; blurb: string; tools: PumaTool[] }[] = [
  { label: "Intake", blurb: "Request captured & validated", tools: ["puma"] },
  { label: "Input Review", blurb: "Human sign-off on ambiguous inputs", tools: [] },
  { label: "Evidence", blurb: "Live usage & inventory pulled", tools: ["grafana", "openshift"] },
  { label: "Forecast & Planning", blurb: "Demand projected, capacity plan built", tools: ["grafana", "openshift"] },
  { label: "Record & Explain", blurb: "Decision logged with rationale", tools: ["puma"] },
];

function ExecutiveWorkflow() {
  return (
    <div className="bg-panel rounded-xl border border-border p-4">
      <h3 className="text-sm font-bold uppercase tracking-widest mb-3">How this decision was made</h3>
      <div className="flex flex-wrap items-stretch gap-3">
        {WORKFLOW_STAGES.map((s, i) => (
          <div key={s.label} className="flex items-center gap-3">
            <div className="min-w-[160px] rounded-lg border border-border bg-surface p-3">
              <div className="text-sm font-semibold">{s.label}</div>
              <div className="text-xs text-text-dim mt-0.5">{s.blurb}</div>
              {s.tools.length > 0 && (
                <div className="mt-2">
                  <ToolBadgeRow tools={s.tools} />
                </div>
              )}
            </div>
            {i < WORKFLOW_STAGES.length - 1 && <span className="text-text-dim">→</span>}
          </div>
        ))}
      </div>
    </div>
  );
}

function Legend({ swatch, label }: { swatch: string; label: string }) {
  return (
    <div className="flex items-center gap-1.5">
      <span className={`inline-block size-3 ${swatch}`} />
      {label}
    </div>
  );
}

function Reveal({ on, children }: { on: boolean; children: React.ReactNode }) {
  return (
    <div
      className={
        "transition-all duration-500 " +
        (on ? "opacity-100 translate-y-0" : "opacity-25 translate-y-1 blur-[1px] pointer-events-none")
      }
    >
      {children}
    </div>
  );
}

const LINE_TONE: Record<TraceLine["t"], string> = {
  call: "text-brand",
  out: "text-text-dim",
  warn: "text-warn",
  ok: "text-ok",
};
const LINE_PREFIX: Record<TraceLine["t"], string> = { call: "→", out: " ", warn: "!", ok: "✓" };

function RunConsole({ log, phase, onRun }: { log: { node: string; line: TraceLine }[]; phase: Phase; onRun: () => void }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    ref.current?.scrollTo({ top: ref.current.scrollHeight });
  }, [log.length]);
  return (
    <div className="bg-surface rounded-xl border border-border">
      <div className="px-4 py-2 border-b border-border flex items-center justify-between">
        <span className="text-[10px] font-mono uppercase tracking-widest text-text-dim">
          Execution trace
        </span>
        <span className="text-[10px] font-mono text-text-dim flex items-center gap-2">
          {phase === "running" && <span className="size-1.5 rounded-full bg-brand animate-pulse" />}
          {phase === "idle" ? "idle" : phase === "running" ? "running" : "complete"}
        </span>
      </div>
      <div ref={ref} className="p-4 h-56 overflow-auto font-mono text-[11px] leading-relaxed">
        {log.length === 0 ? (
          <button onClick={onRun} className="text-text-dim hover:text-brand">
            ▶ press Run to execute this scenario through the workflow
          </button>
        ) : (
          log.map((l, i) => (
            <div key={i} className={LINE_TONE[l.line.t]}>
              <span className="text-text-dim mr-2">{l.node.padEnd(13, " ")}</span>
              <span className="mr-1">{LINE_PREFIX[l.line.t]}</span>
              {l.line.text}
            </div>
          ))
        )}
        {phase === "running" && <span className="inline-block w-2 h-3 bg-brand animate-pulse align-middle" />}
      </div>
    </div>
  );
}

type GraphNode = { id: string; label: string; kind: "agent" | "engine" | "record"; x: number; y: number };

function Graph({ nodes, selected, onSelect, status, phase }: { nodes: GraphNode[]; selected: string; onSelect: (id: string) => void; status: Record<string, NodeStatus>; phase: Phase }) {
  const width = 30 + nodes.length * (NODE_W + NODE_GAP);
  const height = 300;
  const byId = (id: string) => nodes.find((n) => n.id === id)!;
  return (
    <div className="bg-panel/60 rounded-xl border border-border overflow-x-auto">
      <svg width={width} height={height} className="block">
        <defs>
          <marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto">
            <path d="M0,0 L10,5 L0,10 z" className="fill-border" />
          </marker>
        </defs>
        {WORKFLOW.edges.map(([a, b], i) => {
          const na = byId(a);
          const nb = byId(b);
          const x1 = na.x + NODE_W;
          const y1 = na.y + NODE_H / 2;
          const x2 = nb.x;
          const y2 = nb.y + NODE_H / 2;
          const mx = (x1 + x2) / 2;
          const flowing = status[a] === "done" && status[b] === "running";
          const passed = status[a] === "done" && status[b] === "done";
          return (
            <path
              key={i}
              d={`M${x1},${y1} C${mx},${y1} ${mx},${y2} ${x2},${y2}`}
              className={`fill-none ${flowing ? "stroke-brand" : passed ? "stroke-ok/70" : "stroke-border"}`}
              strokeWidth={flowing ? 2 : 1}
              strokeDasharray={flowing ? "6 6" : undefined}
              markerEnd="url(#arrow)"
            >
              {flowing && <animate attributeName="stroke-dashoffset" from="24" to="0" dur="0.6s" repeatCount="indefinite" />}
            </path>
          );
        })}
        {nodes.map((n) => (
          <GNode key={n.id} node={n} selected={n.id === selected} onSelect={onSelect} status={phase === "idle" ? "done" : (status[n.id] ?? "pending")} />
        ))}
      </svg>
    </div>
  );
}

function GNode({ node, selected, onSelect, status }: { node: GraphNode; selected: boolean; onSelect: (id: string) => void; status: NodeStatus }) {
  const rx = node.kind === "engine" ? 2 : node.kind === "record" ? 6 : 22;
  const running = status === "running";
  const pending = status === "pending";
  const fill = running ? "fill-brand/25" : node.kind === "engine" ? "fill-brand/20" : node.kind === "record" ? "fill-ok/15" : "fill-panel";
  const stroke = running
    ? "stroke-brand"
    : selected
      ? "stroke-brand"
      : pending
        ? "stroke-border"
        : node.kind === "engine"
          ? "stroke-brand"
          : node.kind === "record"
            ? "stroke-ok"
            : "stroke-border";
  const dot = running ? "fill-brand" : pending ? "fill-border" : "fill-ok";
  return (
    <g
      transform={`translate(${node.x}, ${node.y})`}
      className={`cursor-pointer transition-opacity ${pending ? "opacity-40" : "opacity-100"}`}
      onClick={() => onSelect(node.id)}
    >
      {running && (
        <rect x={-4} y={-4} width={NODE_W + 8} height={NODE_H + 8} rx={rx + 4} ry={rx + 4} className="fill-none stroke-brand/40" strokeWidth={2}>
          <animate attributeName="opacity" values="0.2;1;0.2" dur="1.2s" repeatCount="indefinite" />
        </rect>
      )}
      <rect width={NODE_W} height={NODE_H} rx={rx} ry={rx} className={`${fill} ${stroke}`} strokeWidth={selected || running ? 2 : 1} />
      <circle cx={12} cy={NODE_H / 2} r={4} className={dot}>
        {running && <animate attributeName="r" values="3;5.5;3" dur="0.9s" repeatCount="indefinite" />}
      </circle>
      <text x={24} y={NODE_H / 2 + 4} className="fill-foreground text-[11px] font-medium" style={{ fontFamily: "Inter, sans-serif" }}>
        {node.label}
      </text>
    </g>
  );
}

function GuardrailBar({ scenario }: { scenario: Scenario }) {
  const g = scenario.guardrail;
  return (
    <div className="bg-panel rounded-xl border border-border p-3 flex items-center gap-6 text-[11px] font-mono">
      <span className="text-[9px] uppercase tracking-widest text-text-dim">guardrail</span>
      <span>allowlisted <span className="text-ok">{g.allowlisted}</span></span>
      <span>writes <span className="text-ok">{g.writes}</span></span>
      <span>blocked <span className={g.blocked ? "text-bad" : "text-text-dim"}>{g.blocked}</span></span>
      <span>retries <span className={g.retries ? "text-warn" : "text-text-dim"}>{g.retries}</span></span>
      <span className="ml-auto text-text-dim">policy cap-policy v3.2 · asOf {scenario.asOf}</span>
    </div>
  );
}

function HitlPanel({ scenario }: { scenario: Scenario }) {
  const h = scenario.hitl!;
  return (
    <div className={`rounded-xl border p-4 ${h.answered ? "border-ok/40 bg-ok/5" : "border-warn/40 bg-warn/5"}`}>
      <div className="text-[10px] font-mono uppercase tracking-widest text-text-dim mb-1">
        Human-in-the-loop {h.answered ? "· resolved" : "· awaiting input"}
      </div>
      <div className="text-sm">{h.question}</div>
      {h.answered && h.answers && (
        <div className="mt-2 font-mono text-[11px] text-text-dim">
          {h.fields.map((f) => (
            <span key={f} className="mr-4">
              {f}=<span className="text-foreground">{String(h.answers![f])}</span>
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

function SizingDerivation({ scenario }: { scenario: Scenario }) {
  const s = scenario.sizing;
  return (
    <div className="bg-panel rounded-xl border border-border">
      <div className="p-4 border-b border-border flex items-center justify-between">
        <h3 className="text-sm font-bold uppercase tracking-widest">Sizing derivation</h3>
        <div className="text-[10px] font-mono text-text-dim">
          benchmark {s.benchmarkId} · match {s.matchScore.toFixed(2)} · band {s.band}
        </div>
      </div>
      <table className="w-full text-left text-xs">
        <thead>
          <tr className="bg-panel-2/50 border-b border-border text-text-dim">
            <th className="p-3 font-medium">Step</th>
            <th className="p-3 font-medium">Expression</th>
            <th className="p-3 font-medium text-right">Value</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-border font-mono">
          {s.steps.map((st) => (
            <tr key={st.label}>
              <td className="p-3 text-text-dim">{st.label}</td>
              <td className="p-3 text-text-dim">{st.expr}</td>
              <td className="p-3 text-right text-foreground">
                {Number.isInteger(st.value) ? st.value : st.value.toFixed(3)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function CandidacyTable({ scenario }: { scenario: Scenario }) {
  return (
    <div className="bg-panel rounded-xl border border-border">
      <div className="p-4 border-b border-border">
        <h3 className="text-sm font-bold uppercase tracking-widest">Pool candidacy sweep</h3>
        <div className="text-[10px] font-mono text-text-dim mt-1">
          shortfall {scenario.sizing.shortfallGpus.toFixed(3)} GPU · gpu/replica {scenario.sizing.gpusPerReplica.toFixed(3)}
        </div>
      </div>
      <table className="w-full text-left text-xs">
        <thead>
          <tr className="bg-panel-2/50 border-b border-border text-text-dim">
            <th className="p-3 font-medium">Pool</th>
            <th className="p-3 font-medium">SKU</th>
            <th className="p-3 font-medium text-right">Free</th>
            <th className="p-3 font-medium text-right">Largest block</th>
            <th className="p-3 font-medium">Verdict</th>
            <th className="p-3 font-medium">Reason</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-border font-mono">
          {scenario.candidacy.map((p) => {
            const tone = p.verdict === "chosen" ? "text-ok" : p.verdict === "blocked" ? "text-bad" : "text-text-dim";
            return (
              <tr key={p.pool} className={p.verdict === "chosen" ? "bg-ok/5" : ""}>
                <td className="p-3">{p.pool}</td>
                <td className="p-3 text-text-dim">{p.sku ?? "—"}</td>
                <td className="p-3 text-right">{p.freeGpus.toFixed(3)}</td>
                <td className="p-3 text-right">{p.largestContiguous.toFixed(3)}</td>
                <td className={`p-3 uppercase text-[10px] font-bold ${tone}`}>{p.verdict}</td>
                <td className="p-3 text-text-dim">{p.reason}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

function PlanningLadder({ rungs }: { rungs: LadderRung[] }) {
  return (
    <div className="bg-panel rounded-xl border border-border border-l-4 border-l-brand">
      <div className="p-4 border-b border-border">
        <h3 className="text-sm font-bold uppercase tracking-widest">Planning ladder · deterministic</h3>
      </div>
      <table className="w-full text-left text-xs">
        <thead>
          <tr className="bg-panel-2/50 border-b border-border text-text-dim">
            <th className="p-3 font-medium w-8">#</th>
            <th className="p-3 font-medium">Strategy</th>
            <th className="p-3 font-medium text-right">Δ cost</th>
            <th className="p-3 font-medium">Verdict</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-border font-mono">
          {rungs.map((r) => (
            <LadderRowView key={r.step} row={r} />
          ))}
        </tbody>
      </table>
    </div>
  );
}

function LadderRowView({ row }: { row: LadderRung }) {
  const isRec = row.verdict === "win";
  const verdictNode = (() => {
    switch (row.verdict) {
      case "blocked":
        return <span className="text-bad">✗ blocked · {row.detail}</span>;
      case "win":
        return (
          <span className="text-ok font-bold">
            ✓ {row.detail}
            <span className="ml-2 bg-ok text-surface px-1.5 py-0.5 rounded text-[9px]">RECOMMENDED</span>
            {row.ack && <span className="ml-1 text-[9px] text-warn">[ack: {row.ack}]</span>}
          </span>
        );
      case "met":
        return <span className="text-ok">✓ met · {row.detail}</span>;
      case "eligible":
        return <span className="text-warn">○ eligible · {row.detail}</span>;
      case "na":
        return <span className="text-text-dim">— {row.detail}</span>;
    }
  })();
  return (
    <tr className={isRec ? "bg-ok/5" : ""}>
      <td className="p-3 text-text-dim">{row.step}</td>
      <td className="p-3">{row.strategy}</td>
      <td className="p-3 text-right">
        {row.deltaCost == null ? <span className="text-text-dim">—</span> : `$${row.deltaCost.toLocaleString()}`}
      </td>
      <td className="p-3">{verdictNode}</td>
    </tr>
  );
}

function EvidenceManifest({ scenario }: { scenario: Scenario }) {
  const text = manifestText(scenario);
  const [copied, setCopied] = useState(false);
  return (
    <div className="bg-panel rounded-xl border border-border">
      <div className="p-4 border-b border-border flex items-center justify-between">
        <h3 className="text-sm font-bold uppercase tracking-widest">Evidence manifest</h3>
        <button
          className="text-[10px] font-mono border border-border rounded px-2 py-1 hover:bg-panel-2"
          onClick={() => {
            navigator.clipboard?.writeText(text);
            setCopied(true);
            setTimeout(() => setCopied(false), 1500);
          }}
        >
          {copied ? "COPIED" : "COPY"}
        </button>
      </div>
      <pre className="text-[11px] font-mono text-text-dim p-4 whitespace-pre-wrap leading-relaxed max-h-[420px] overflow-auto">
        {text}
      </pre>
    </div>
  );
}

function EvidenceRail({ scenario, nodeId, nodeLabel, nodeKind }: { scenario: Scenario; nodeId: string; nodeLabel: string; nodeKind: string }) {
  return (
    <>
      <div className="p-4 border-b border-border">
        <div className="text-[10px] font-mono uppercase tracking-widest text-text-dim">
          Evidence rail
        </div>
        <h3 className="text-base font-bold mt-1">{nodeLabel}</h3>
        <div className="text-[10px] font-mono text-text-dim mt-1">
          kind: {nodeKind} · node: {nodeId}
        </div>
      </div>
      <div className="flex-1 overflow-auto p-4 space-y-4">
        <Field label="Recommendation">
          <div className="font-mono text-[11px] text-text-dim leading-relaxed">
            state: <span className="text-foreground">{scenario.recommendation.state}</span><br />
            confidence: <span className="text-foreground">{scenario.recommendation.confidence}</span><br />
            hash: <span className="text-foreground">{scenario.recommendation.hash}</span><br />
            engine: v3.2 · policy: cap-policy v3.2
          </div>
        </Field>
        <Field label="Trusted sources">
          <ul className="space-y-2">
            {scenario.evidence.map((e, i) => (
              <li key={i} className="bg-surface border border-border rounded p-2 text-[11px] font-mono">
                <div className="flex justify-between text-text-dim">
                  <span>
                    {e.source}.{e.kind}
                  </span>
                  <span>{e.staleness}</span>
                </div>
                <div className="mt-1 text-foreground break-words">{e.value}</div>
                <div className="text-text-dim">
                  as_of {e.asOf} · trust {e.trust} · conf {e.confidence}
                </div>
                {e.source === "telemetry" && (
                  <div className="mt-1">
                    <ToolBadgeRow tools={["grafana"]} />
                  </div>
                )}
                {e.source === "inventory" && (
                  <div className="mt-1">
                    <ToolBadgeRow tools={["openshift"]} />
                  </div>
                )}
                {e.source === "provisioning" && (
                  <div className="mt-1">
                    <ToolBadgeRow tools={["puma"]} />
                  </div>
                )}
              </li>
            ))}
          </ul>
        </Field>
        <Field label="Match dimensions">
          <ul className="text-[11px] font-mono text-text-dim space-y-1">
            {scenario.sizing.matchDimensions.map((d) => (
              <li key={d.name} className="flex justify-between">
                <span>{d.name}</span>
                <span>
                  <span className="text-foreground">{(d.score * 100).toFixed(0)}%</span>
                  <span className="ml-2 text-text-dim">w{d.weight.toFixed(2)}</span>
                </span>
              </li>
            ))}
          </ul>
        </Field>
      </div>
    </>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="text-[9px] font-mono uppercase tracking-widest text-text-dim mb-2">
        {label}
      </div>
      <div className="text-sm">{children}</div>
    </div>
  );
}
