import type { Metadata } from "next";
import RunDetail from "./RunDetail";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}): Promise<Metadata> {
  const { id } = await params;
  return {
    title: `Run ${id} — CORE_COMPUTE`,
    description: "Deterministic sizing, ladder, and evidence for a GPU capacity assessment.",
    openGraph: {
      title: `Run ${id} — CORE_COMPUTE`,
      description: "Workflow graph, sizing derivation, and evidence manifest.",
    },
  };
}

export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <RunDetail id={id} />;
}
