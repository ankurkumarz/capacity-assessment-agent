import type { Metadata } from "next";
import ForecastPage from "./ForecastPage";

export const metadata: Metadata = {
  title: "Forecast — CORE_COMPUTE",
  description: "180-day peak_rps forecast with breach-day vs lead-time countdown, backtest folds, and coverage gaps.",
  openGraph: {
    title: "Forecast — CORE_COMPUTE",
    description: "Breach-vs-lead-time countdown driving procurement.",
  },
};

export default function Page() {
  return <ForecastPage />;
}
