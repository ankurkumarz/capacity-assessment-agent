import type { Metadata } from "next";
import IntakePage from "./IntakePage";

export const metadata: Metadata = {
  title: "Intake — CORE_COMPUTE",
  description: "Assistant-guided intake for GPU inference demand profiles.",
  openGraph: {
    title: "Intake — CORE_COMPUTE",
    description: "Build a demand profile with provenance for every field.",
  },
};

export default function Page() {
  return <IntakePage />;
}
