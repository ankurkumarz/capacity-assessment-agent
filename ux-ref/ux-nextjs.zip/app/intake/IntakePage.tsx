"use client";

import { AppShell, PageHeader, usePersona, useScenario } from "@/components/AppShell";
import { ToolBadgeRow } from "@/components/ToolBadge";
import { ExecutiveSummaryCard } from "@/components/ExecutiveSummaryCard";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { INTAKE_FIELDS } from "@/lib/mock-data";

const SOURCE_TONE: Record<string, string> = {
  "pulled from PROV-8821": "bg-ok/10 text-ok border-ok/30",
  "you told me": "bg-brand/10 text-brand border-brand/30",
  "assumed default": "bg-warn/10 text-warn border-warn/30",
};

export default function IntakePage() {
  return (
    <AppShell>
      <IntakeContent />
    </AppShell>
  );
}

function IntakeContent() {
  const { persona } = usePersona();
  const { scenario } = useScenario();
  const canSubmit = persona === "requester";
  const isExecutive = persona === "requester";

  return (
    <>
      <PageHeader
        breadcrumb={
          <>
            <span>Intake</span>
            <span className="text-border">/</span>
            <span className="text-foreground">PROV-8821</span>
          </>
        }
        status={{ label: "IN_PROGRESS", tone: "warn" }}
        actions={
          <button
            disabled={!canSubmit}
            className="bg-brand text-surface px-4 py-1.5 rounded text-xs font-bold hover:brightness-110 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            {canSubmit ? "SUBMIT DEMAND PROFILE" : "SUBMIT (owned by: requester)"}
          </button>
        }
      />
      <div className="flex-1 flex overflow-hidden">
        <section className="flex-1 flex flex-col border-r border-border">
          <div className="p-4 border-b border-border">
            <div className="text-[10px] font-mono uppercase tracking-widest text-text-dim">
              PUMA event intake
            </div>
          </div>
          <div className="flex-1 overflow-auto p-6 space-y-6">
            <div className="bg-panel border border-brand/40 rounded-xl p-5">
              <div className="flex items-center justify-between">
                <div className="text-sm font-bold">Event received from PUMA</div>
                <ToolBadgeRow tools={scenario.pumaEvent.tools} />
              </div>
              <div className="mt-2 font-mono text-[11px] text-text-dim space-y-1">
                <div>
                  event_id: <span className="text-foreground">{scenario.pumaEvent.eventId}</span>
                </div>
                <div>
                  received_at: <span className="text-foreground">{scenario.pumaEvent.receivedAt}</span>
                </div>
                <div>
                  ticket: <span className="text-foreground">{scenario.record.ticket}</span>
                </div>
                <div>
                  use_case: <span className="text-foreground">{scenario.record.useCase}</span>
                </div>
                <div>
                  requester: <span className="text-foreground">{scenario.record.requester}</span>
                </div>
              </div>
            </div>
            {isExecutive && <ExecutiveSummaryCard scenario={scenario} />}
          </div>
        </section>
        <aside className="w-[480px] flex flex-col overflow-hidden">
          <div className="p-4 border-b border-border">
            <div className="text-[10px] font-mono uppercase tracking-widest text-text-dim">
              Demand profile (live)
            </div>
            <h2 className="text-lg font-bold mt-1">mistral-7b · support triage</h2>
          </div>
          <div className="flex-1 overflow-auto p-4 space-y-2">
            {isExecutive ? (
              <Collapsible>
                <CollapsibleTrigger className="text-[10px] font-mono uppercase tracking-widest text-brand hover:underline">
                  Show technical detail ▾
                </CollapsibleTrigger>
                <CollapsibleContent className="space-y-2 mt-3">
                  <FieldList />
                </CollapsibleContent>
              </Collapsible>
            ) : (
              <FieldList />
            )}
          </div>
        </aside>
      </div>
    </>
  );
}

function FieldList() {
  return (
    <>
      {INTAKE_FIELDS.map((f) => (
        <div
          key={f.key}
          className="bg-panel border border-border rounded p-3 flex items-start justify-between gap-3"
        >
          <div className="min-w-0">
            <div className="text-[10px] font-mono uppercase tracking-widest text-text-dim">
              {f.label}
            </div>
            <div className="text-sm font-mono mt-1 truncate">{f.value}</div>
          </div>
          <span
            className={`shrink-0 text-[9px] px-2 py-0.5 rounded border font-mono uppercase ${SOURCE_TONE[f.source] ?? "border-border text-text-dim"}`}
          >
            {f.source}
          </span>
        </div>
      ))}
      <div className="text-[10px] text-text-dim font-mono p-2">
        2 amber fields require confirmation before profile hardens.
      </div>
    </>
  );
}
