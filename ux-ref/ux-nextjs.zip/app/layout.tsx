import type { Metadata } from "next";
import { Inter, JetBrains_Mono } from "next/font/google";
import type { ReactNode } from "react";
import { Providers } from "./providers";

import "./globals.css";

const inter = Inter({ subsets: ["latin"], variable: "--font-sans" });
const jetbrainsMono = JetBrains_Mono({ subsets: ["latin"], variable: "--font-mono" });

export const metadata: Metadata = {
  title: "CORE_COMPUTE — GPU capacity planning",
  description: "AI-assisted capacity planning for on-prem GPU inference.",
  authors: [{ name: "CORE_COMPUTE" }],
  openGraph: {
    title: "CORE_COMPUTE — GPU capacity planning",
    description: "AI-assisted capacity planning for on-prem GPU inference.",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "CORE_COMPUTE — GPU capacity planning",
    description: "AI-assisted capacity planning for on-prem GPU inference.",
  },
  icons: { icon: "/favicon.ico" },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${inter.variable} ${jetbrainsMono.variable}`}>
      <body>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
