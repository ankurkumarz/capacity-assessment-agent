import type { Metadata } from "next";
import CapacityPage from "./CapacityPage";

export const metadata: Metadata = {
  title: "Capacity — CORE_COMPUTE",
  description: "Live GPU pool inventory, allocations, and maintenance state.",
  openGraph: {
    title: "Capacity — CORE_COMPUTE",
    description: "Pool health, utilization, and maintenance windows.",
  },
};

export default function Page() {
  return <CapacityPage />;
}
