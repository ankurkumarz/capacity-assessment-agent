"use client";

import { AppShell, PageHeader, usePersona } from "@/components/AppShell";
import { BENCHMARKS, type BenchmarkRow } from "@/lib/mock-data";
import { useState } from "react";

const USABLE = 0.75;

export default function RegistryPage() {
  const { persona } = usePersona();
  const [sel, setSel] = useState<string>(BENCHMARKS[0].id);
  const b = BENCHMARKS.find((x) => x.id === sel)!;
  return (
    <AppShell>
      <PageHeader
        breadcrumb={<span>Benchmark registry</span>}
        status={{ label: `USABLE ≥ ${USABLE}`, tone: "info" }}
        actions={
          <button
            disabled={persona !== "perf_engineer"}
            className="bg-brand text-surface px-4 py-1.5 rounded text-xs font-bold hover:brightness-110 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            {persona === "perf_engineer" ? "ATTACH BENCHMARK" : "ATTACH (owned by: perf_engineer)"}
          </button>
        }
      />
      <div className="flex-1 overflow-auto p-6 grid grid-cols-3 gap-6">
        <div className="col-span-2 bg-panel rounded-xl border border-border overflow-hidden">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-panel-2/50 border-b border-border text-text-dim">
                <th className="p-3 font-medium">Benchmark</th>
                <th className="p-3 font-medium">Model</th>
                <th className="p-3 font-medium">Hardware</th>
                <th className="p-3 font-medium">Quant</th>
                <th className="p-3 font-medium text-right">tok/s</th>
                <th className="p-3 font-medium text-right">Match</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border font-mono">
              {BENCHMARKS.map((row) => {
                const usable = row.match >= USABLE;
                return (
                  <tr
                    key={row.id}
                    onClick={() => setSel(row.id)}
                    className={`cursor-pointer hover:bg-panel-2/40 ${row.id === sel ? "bg-brand/5" : ""}`}
                  >
                    <td className="p-3 text-brand">{row.id}</td>
                    <td className="p-3">{row.model}</td>
                    <td className="p-3 text-text-dim">{row.hardware}</td>
                    <td className="p-3 text-text-dim">{row.quant}</td>
                    <td className="p-3 text-right">{row.tokensPerSec.toLocaleString()}</td>
                    <td className={`p-3 text-right font-bold ${usable ? "text-ok" : "text-bad"}`}>
                      {row.match.toFixed(2)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <MatchDetail b={b} />
      </div>
    </AppShell>
  );
}

function MatchDetail({ b }: { b: BenchmarkRow }) {
  const usable = b.match >= USABLE;
  return (
    <div className="bg-panel rounded-xl border border-border p-5 space-y-4">
      <div>
        <div className="text-[10px] font-mono uppercase tracking-widest text-text-dim">
          Match detail · {b.id}
        </div>
        <h3 className="text-lg font-bold mt-1">{b.model}</h3>
        <div className="text-[11px] font-mono text-text-dim mt-1">
          {b.version} · as_of {b.asOf}
        </div>
      </div>

      <div className={`p-3 rounded border ${usable ? "border-ok/40 bg-ok/5" : "border-bad/40 bg-bad/5"}`}>
        <div className="text-[10px] font-bold uppercase text-text-dim">Overall match</div>
        <div className={`text-3xl font-mono ${usable ? "text-ok" : "text-bad"}`}>{b.match.toFixed(2)}</div>
        <div className="text-[10px] font-mono text-text-dim mt-1">
          {usable ? "usable" : `below ${USABLE} — blocks green recommendation`}
        </div>
      </div>

      <Radar dims={b.dims} />

      <div>
        <div className="text-[10px] font-mono uppercase text-text-dim mb-2">Mismatch reasons</div>
        {b.reasons.length ? (
          <ul className="text-[11px] font-mono text-warn list-disc pl-4 space-y-1">
            {b.reasons.map((r) => (
              <li key={r}>{r}</li>
            ))}
          </ul>
        ) : (
          <div className="text-ok text-[11px] font-mono">no dimensions below threshold</div>
        )}
      </div>
    </div>
  );
}

function Radar({ dims }: { dims: BenchmarkRow["dims"] }) {
  const keys: (keyof BenchmarkRow["dims"])[] = ["model", "hardware", "quant", "seqLen", "concurrency", "runtime"];
  const cx = 130;
  const cy = 130;
  const r = 90;
  const points = keys.map((k, i) => {
    const a = (Math.PI * 2 * i) / keys.length - Math.PI / 2;
    const v = dims[k];
    return { k, x: cx + Math.cos(a) * r * v, y: cy + Math.sin(a) * r * v, lx: cx + Math.cos(a) * (r + 14), ly: cy + Math.sin(a) * (r + 14) };
  });
  const path = points.map((p, i) => `${i === 0 ? "M" : "L"}${p.x},${p.y}`).join(" ") + " Z";
  return (
    <div className="flex justify-center">
      <svg width={260} height={260}>
        {[0.25, 0.5, 0.75, 1].map((s) => (
          <circle key={s} cx={cx} cy={cy} r={r * s} className="fill-none stroke-border" strokeDasharray="2 3" />
        ))}
        {keys.map((k, i) => {
          const a = (Math.PI * 2 * i) / keys.length - Math.PI / 2;
          return (
            <line
              key={k}
              x1={cx}
              y1={cy}
              x2={cx + Math.cos(a) * r}
              y2={cy + Math.sin(a) * r}
              className="stroke-border"
            />
          );
        })}
        <path d={path} className="fill-brand/20 stroke-brand" strokeWidth={1.5} />
        {points.map((p) => (
          <g key={p.k}>
            <circle cx={p.x} cy={p.y} r={3} className="fill-brand" />
            <text
              x={p.lx}
              y={p.ly}
              textAnchor="middle"
              className="fill-text-dim text-[9px] font-mono uppercase"
              style={{ fontFamily: "JetBrains Mono" }}
            >
              {p.k}
            </text>
          </g>
        ))}
      </svg>
    </div>
  );
}
