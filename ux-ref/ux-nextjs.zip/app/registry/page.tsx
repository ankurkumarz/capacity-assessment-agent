import type { Metadata } from "next";
import RegistryPage from "./RegistryPage";

export const metadata: Metadata = {
  title: "Benchmark Registry — CORE_COMPUTE",
  description: "Six-dimension benchmark match scoring with mismatch reasons.",
  openGraph: {
    title: "Benchmark Registry — CORE_COMPUTE",
    description: "Match quality that hard-blocks green recommendations below threshold.",
  },
};

export default function Page() {
  return <RegistryPage />;
}
