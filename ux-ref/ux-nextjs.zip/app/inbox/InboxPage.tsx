"use client";

import Link from "next/link";
import { Fragment, useState } from "react";
import { AppShell, PageHeader, usePersona, useScenario } from "@/components/AppShell";
import { SCENARIOS, SCENARIO_ORDER, type Scenario } from "@/lib/scenarios";
import { PIPELINE } from "@/lib/mock-data";

const TONE_BADGE: Record<Scenario["recommendation"]["tone"], string> = {
  ok: "bg-ok/10 text-ok border-ok/30",
  warn: "bg-warn/10 text-warn border-warn/30",
  bad: "bg-bad/10 text-bad border-bad/30",
  info: "bg-brand/10 text-brand border-brand/30",
};

export default function InboxPage() {
  const { setId } = useScenario();
  const [expanded, setExpanded] = useState<string | null>(null);
  const rows = SCENARIO_ORDER.map((id) => SCENARIOS[id]);

  return (
    <AppShell>
      <PageHeader
        breadcrumb={<span>Inbox · assessments</span>}
        status={{ label: `${rows.length} SCENARIOS`, tone: "info" }}
      />
      <div className="flex-1 overflow-auto p-6 space-y-8">
        <PersonaHint />
        <section>
          <h2 className="text-[10px] font-bold text-text-dim uppercase tracking-widest mb-3">
            Needs a human
          </h2>
          <div className="bg-panel rounded-xl border border-border overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-panel-2/50 border-b border-border text-text-dim">
                  <th className="p-3 font-medium w-6"></th>
                  <th className="p-3 font-medium w-32">ID</th>
                  <th className="p-3 font-medium">Use case</th>
                  <th className="p-3 font-medium">Model</th>
                  <th className="p-3 font-medium">Requester</th>
                  <th className="p-3 font-medium">Recommendation</th>
                  <th className="p-3 font-medium text-right">Shortfall (GPU)</th>
                  <th className="p-3 font-medium text-right">$/mo Δ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {rows.map((s) => {
                  const rec = s.ladder.find((r) => r.verdict === "win");
                  const cost = rec?.deltaCost ?? null;
                  const project = s.record.projectId
                    ? PIPELINE.find((p) => p.projectId === s.record.projectId)
                    : undefined;
                  const isOpen = expanded === s.id;
                  return (
                    <Fragment key={s.id}>
                      <tr className="hover:bg-panel-2/40">
                        <td className="p-3">
                          {project && (
                            <button
                              onClick={() => setExpanded(isOpen ? null : s.id)}
                              className="text-text-dim hover:text-brand transition-transform"
                              style={{ transform: isOpen ? "rotate(90deg)" : "none" }}
                              aria-label="Toggle project details"
                            >
                              ▸
                            </button>
                          )}
                        </td>
                        <td className="p-3 font-mono">
                          <Link
                            href={`/run/${s.record.id}`}
                            onClick={() => setId(s.id)}
                            className="text-brand hover:underline"
                          >
                            {s.record.id}
                          </Link>
                        </td>
                        <td className="p-3">{s.record.useCase}</td>
                        <td className="p-3 font-mono text-text-dim">{s.record.model}</td>
                        <td className="p-3 font-mono text-text-dim">{s.record.requester}</td>
                        <td className="p-3">
                          <span className={`px-2 py-0.5 rounded border text-[10px] font-bold uppercase ${TONE_BADGE[s.recommendation.tone]}`}>
                            {s.recommendation.state}
                          </span>
                          <span className="ml-2 font-mono text-[10px] text-text-dim">
                            {s.recommendation.hash}
                          </span>
                        </td>
                        <td className={`p-3 font-mono text-right ${s.sizing.shortfallGpus > 0 ? "text-warn" : "text-ok"}`}>
                          {s.sizing.shortfallGpus > 0 ? "+" : ""}
                          {s.sizing.shortfallGpus.toFixed(3)}
                        </td>
                        <td className="p-3 font-mono text-right text-text-dim">
                          {cost == null ? "—" : `$${cost.toLocaleString()}`}
                        </td>
                      </tr>
                      {isOpen && project && (
                        <tr className="bg-panel-2/30">
                          <td className="p-3"></td>
                          <td colSpan={7} className="p-3">
                            <ProjectDetail project={project} />
                          </td>
                        </tr>
                      )}
                    </Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </AppShell>
  );
}

function ProjectDetail({ project }: { project: (typeof PIPELINE)[number] }) {
  const items: { label: string; value: string }[] = [
    { label: "Project", value: `${project.projectId} · ${project.projectName}` },
    { label: "CSI App", value: project.csiAppName },
    { label: "PTS use case", value: project.ptsUseCase },
    { label: "Sponsor", value: project.businessSponsor },
    { label: "SDLC", value: project.sdlc },
    { label: "Region", value: project.region },
    { label: "Context", value: project.contextSize },
    { label: "Avg in tok", value: project.avgInputTokens.toLocaleString() },
    { label: "Max tok", value: project.maxTokens.toLocaleString() },
    { label: "Users", value: project.totalUsers.toLocaleString() },
    { label: "Req/day", value: project.requestsPerDay.toLocaleString() },
    { label: "Avg/max QPS", value: `${project.avgQps} / ${project.maxQps}` },
  ];
  return (
    <div className="flex flex-wrap gap-x-6 gap-y-2 text-[11px] font-mono">
      {items.map((it) => (
        <div key={it.label}>
          <span className="text-text-dim uppercase tracking-widest text-[9px]">{it.label}</span>
          <span className="ml-1.5 text-foreground">{it.value}</span>
        </div>
      ))}
    </div>
  );
}

function PersonaHint() {
  const { persona } = usePersona();
  if (persona === "capacity_manager") return null;
  return (
    <div className="text-[11px] font-mono text-text-dim border border-dashed border-border rounded p-3">
      You are viewing as <span className="text-foreground">{persona}</span>. Approve/reject actions
      remain owned by <span className="text-brand">capacity_manager</span>.
    </div>
  );
}
