import type { Metadata } from "next";
import InboxPage from "./InboxPage";

export const metadata: Metadata = {
  title: "Inbox — CORE_COMPUTE",
  description: "Assessment records awaiting review, approval, or input.",
  openGraph: {
    title: "Inbox — CORE_COMPUTE",
    description: "Assessment records for on-prem GPU capacity planning.",
  },
};

export default function Page() {
  return <InboxPage />;
}
