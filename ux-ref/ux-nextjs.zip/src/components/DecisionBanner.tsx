import type { Scenario } from "@/lib/scenarios";

const BUCKET_COPY: Record<Scenario["decisionBucket"], { label: string; tone: "ok" | "warn" | "bad" }> = {
  absorb: { label: "No impact — absorbed, no provisioning required", tone: "ok" },
  provision: { label: "GPU provisioning required (order infrastructure)", tone: "bad" },
  rebalance: { label: "Workload rebalance required (internal prioritization)", tone: "warn" },
};

const TONE_CLASS = {
  ok: "border-ok/40 bg-ok/10 text-ok",
  warn: "border-warn/40 bg-warn/10 text-warn",
  bad: "border-bad/40 bg-bad/10 text-bad",
} as const;

export function DecisionBanner({ scenario }: { scenario: Scenario }) {
  const bucket = BUCKET_COPY[scenario.decisionBucket];
  return (
    <div className={`rounded-xl border-2 p-4 flex items-center gap-6 ${TONE_CLASS[bucket.tone]}`}>
      <div className="flex-1">
        <div className="text-[10px] font-mono uppercase tracking-widest opacity-70">
          Agent recommendation engine · decision
        </div>
        <div className="text-lg font-bold mt-1">{bucket.label}</div>
      </div>
      <div className="flex gap-4">
        <ImpactTile label="GPU impact" value={scenario.gpuImpact.label} />
        <ImpactTile label="Tokens/sec impact" value={scenario.tokensSecImpact.label} />
      </div>
    </div>
  );
}

function ImpactTile({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-surface/60 border border-border rounded-lg px-4 py-2 min-w-[180px]">
      <div className="text-[9px] font-mono uppercase tracking-widest text-text-dim">{label}</div>
      <div className="text-sm font-mono mt-1">{value}</div>
    </div>
  );
}
