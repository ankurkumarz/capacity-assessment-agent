"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { PERSONAS, type PersonaId } from "@/lib/mock-data";
import { SCENARIO_ORDER, SCENARIOS, type ScenarioId } from "@/lib/scenarios";

type Theme = "light" | "dark";

type AppCtx = {
  persona: PersonaId;
  setPersona: (p: PersonaId) => void;
  scenarioId: ScenarioId;
  setScenarioId: (s: ScenarioId) => void;
  theme: Theme;
  setTheme: (t: Theme) => void;
};
const Ctx = createContext<AppCtx>({
  persona: "capacity_manager",
  setPersona: () => {},
  scenarioId: "s3-rebalance",
  setScenarioId: () => {},
  theme: "dark",
  setTheme: () => {},
});
export const usePersona = () => useContext(Ctx);
export const useScenario = () => {
  const { scenarioId, setScenarioId } = useContext(Ctx);
  return { id: scenarioId, setId: setScenarioId, scenario: SCENARIOS[scenarioId] };
};
export const useTheme = () => {
  const { theme, setTheme } = useContext(Ctx);
  return { theme, setTheme };
};

const NAV = [
  { to: "/inbox", label: "PUMA Pipelines", count: SCENARIO_ORDER.length },
  { to: "/intake", label: "PUMA Intake" },
  { to: "/run/current", label: "Run GPU Agent" },
  { to: "/forecast", label: "Forecast GPU & Tokens" },
  { to: "/capacity", label: "GPU Capacity" },
  { to: "/registry", label: "Model Benchmark Registry" },
];

export function AppShell({ children }: { children: ReactNode }) {
  const [persona, setPersonaState] = useState<PersonaId>("capacity_manager");
  const [scenarioId, setScenarioIdState] = useState<ScenarioId>("s3-rebalance");
  const [theme, setThemeState] = useState<Theme>("dark");
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    if (typeof window === "undefined") return;
    const p = localStorage.getItem("persona");
    if (p) setPersonaState(p as PersonaId);
    const s = localStorage.getItem("scenario");
    if (s && s in SCENARIOS) setScenarioIdState(s as ScenarioId);
    const t = localStorage.getItem("theme");
    if (t === "light" || t === "dark") setThemeState(t);
  }, []);

  useEffect(() => {
    if (typeof document === "undefined") return;
    document.documentElement.classList.toggle("dark", theme === "dark");
  }, [theme]);

  const setPersona = (p: PersonaId) => {
    setPersonaState(p);
    if (typeof window !== "undefined") localStorage.setItem("persona", p);
  };
  const setScenarioId = (s: ScenarioId) => {
    setScenarioIdState(s);
    if (typeof window !== "undefined") localStorage.setItem("scenario", s);
    router.push(`/run/${SCENARIOS[s].record.id}?run=${Date.now()}`);
  };
  const setTheme = (t: Theme) => {
    setThemeState(t);
    if (typeof window !== "undefined") localStorage.setItem("theme", t);
  };

  const active = PERSONAS.find((p) => p.id === persona)!;
  const scenario = SCENARIOS[scenarioId];

  return (
    <Ctx.Provider value={{ persona, setPersona, scenarioId, setScenarioId, theme, setTheme }}>
      <div className="min-h-screen bg-surface text-foreground font-sans selection:bg-brand/30 flex">
        <aside className="w-64 border-r border-border flex flex-col shrink-0">
          <div className="p-5 border-b border-border">
            <div className="flex items-center gap-3">
              <div className="size-8 bg-brand rounded-sm flex items-center justify-center text-surface">
                <span className="font-mono font-bold text-xs">C0</span>
              </div>
              <div>
                <h1 className="font-mono font-bold tracking-tight text-sm">Enterprise Analytics</h1>
                <div className="text-[10px] text-text-dim font-mono">Agentic AI Planning & Forecasting</div>
              </div>
            </div>
          </div>

          <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
            <div className="text-[10px] font-bold text-text-dim uppercase tracking-widest px-2 mb-3">
              Operations
            </div>
            {NAV.map((n) => {
              const target =
                n.to === "/run/current" ? `/run/${scenario.record.id}` : n.to;
              const isActive =
                target === pathname ||
                (n.to === "/run/current" && pathname.startsWith("/run/"));
              return (
                <Link
                  key={n.label}
                  href={target}
                  className={
                    "flex items-center gap-3 px-3 py-2 text-sm border-l-2 transition-colors " +
                    (isActive
                      ? "bg-brand/10 text-brand border-brand"
                      : "text-text-dim hover:text-foreground border-transparent hover:bg-panel")
                  }
                >
                  {n.label}
                  {n.count ? (
                    <span className="ml-auto text-[10px] bg-brand/20 text-brand px-1.5 py-0.5 rounded font-mono">
                      {n.count}
                    </span>
                  ) : null}
                </Link>
              );
            })}

            <div className="text-[10px] font-bold text-text-dim uppercase tracking-widest px-2 mt-8 mb-3">
              Scenario
            </div>
            <select
              value={scenarioId}
              onChange={(e) => setScenarioId(e.target.value as ScenarioId)}
              className="w-full bg-panel border border-border text-xs rounded p-2 text-foreground outline-none focus:border-brand"
            >
              {SCENARIO_ORDER.map((id) => (
                <option key={id} value={id}>
                  {id.split("-")[0].toUpperCase()} · {SCENARIOS[id].recommendation.state}
                </option>
              ))}
            </select>
            <div className="mt-2 px-2 text-[10px] text-text-dim leading-relaxed">
              {scenario.title}
            </div>
            <button
              onClick={() => router.push(`/run/${scenario.record.id}?run=${Date.now()}`)}
              className="mt-2 flex items-center justify-center gap-2 w-full bg-brand/15 hover:bg-brand/25 text-brand border border-brand/40 rounded py-1.5 text-[11px] font-mono font-bold uppercase tracking-widest transition-colors"
            >
              ▶ Run scenario
            </button>

            <div className="text-[10px] font-bold text-text-dim uppercase tracking-widest px-2 mt-8 mb-3">
              Persona
            </div>
            <select
              value={persona}
              onChange={(e) => setPersona(e.target.value as PersonaId)}
              className="w-full bg-panel border border-border text-xs rounded p-2 text-foreground outline-none focus:border-brand"
            >
              {PERSONAS.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.short} · {p.label}
                </option>
              ))}
            </select>
            <div className="mt-3 px-2 text-[10px] text-text-dim">
              Landing: <span className="font-mono text-foreground">{active.landing}</span>
            </div>
            <div className="mt-1 px-2 text-[10px] text-text-dim">
              Owns: <span className="font-mono text-foreground">{active.owns.join(", ")}</span>
            </div>
          </nav>

          <div className="p-4 border-t border-border flex items-center justify-between">
            <div className="text-[10px] font-mono text-text-dim flex items-center gap-2">
              <span className="size-1.5 rounded-full bg-ok animate-pulse"></span>
              telemetry OK · 14:03:12Z
            </div>
            <button
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              className="text-[10px] font-mono border border-border rounded px-2 py-1 hover:bg-panel shrink-0"
              title="Toggle light/dark theme"
            >
              {theme === "dark" ? "☾ DARK" : "☀ LIGHT"}
            </button>
          </div>
        </aside>

        <main className="flex-1 flex flex-col min-w-0">{children}</main>
      </div>
    </Ctx.Provider>
  );
}

export function PageHeader({
  breadcrumb,
  status,
  actions,
}: {
  breadcrumb: ReactNode;
  status?: { label: string; tone: "ok" | "warn" | "bad" | "info" };
  actions?: ReactNode;
}) {
  const toneMap = {
    ok: "bg-ok/10 text-ok border-ok/30",
    warn: "bg-warn/10 text-warn border-warn/30",
    bad: "bg-bad/10 text-bad border-bad/30",
    info: "bg-brand/10 text-brand border-brand/30",
  } as const;
  return (
    <header className="h-14 border-b border-border flex items-center justify-between px-6 bg-surface/60 backdrop-blur-md sticky top-0 z-10">
      <div className="flex items-center gap-3 text-xs font-mono text-text-dim">
        {breadcrumb}
        {status && (
          <span
            className={`px-2 py-0.5 rounded text-[10px] font-bold border ${toneMap[status.tone]}`}
          >
            {status.label}
          </span>
        )}
      </div>
      <div className="flex items-center gap-2">{actions}</div>
    </header>
  );
}

export function OwnedBy({ role }: { role: string }) {
  return (
    <span className="text-[9px] uppercase tracking-widest text-text-dim font-mono">
      owned by: {role}
    </span>
  );
}
