import { useState } from "react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { ScrollArea } from "@/components/ui/scroll-area";
import { buildQaScript, matchQuestion, type QaPair } from "@/lib/chat-script";
import type { Scenario } from "@/lib/scenarios";

type Msg = { role: "user" | "assistant"; text: string };

export function ChatDrawer({ scenario }: { scenario: Scenario }) {
  const script = buildQaScript(scenario);
  const [messages, setMessages] = useState<Msg[]>([
    { role: "assistant", text: `Ask me about ${scenario.record.useCase}'s GPU impact, decision, cost, or timeline.` },
  ]);
  const [input, setInput] = useState("");

  function ask(text: string) {
    if (!text.trim()) return;
    const found = matchQuestion(script, text);
    const answer =
      found?.a ??
      "I can help with GPU impact, tokens/sec impact, the recommendation decision, cost, and timeline for this scenario.";
    setMessages((m) => [...m, { role: "user", text }, { role: "assistant", text: answer }]);
    setInput("");
  }

  return (
    <Sheet>
      <SheetTrigger asChild>
        <button className="fixed bottom-6 right-6 z-20 bg-brand text-surface rounded-full px-5 py-3 text-sm font-bold shadow-lg hover:brightness-110">
          Ask about this scenario
        </button>
      </SheetTrigger>
      <SheetContent side="right" className="w-[420px] flex flex-col p-0">
        <SheetHeader className="p-4 border-b border-border">
          <SheetTitle>Capacity Q&amp;A · {scenario.record.id}</SheetTitle>
        </SheetHeader>
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-3">
            {messages.map((m, i) => (
              <div key={i} className={m.role === "user" ? "flex justify-end" : ""}>
                <div
                  className={
                    "max-w-[85%] px-3 py-2 rounded text-sm " +
                    (m.role === "assistant" ? "bg-panel border border-border" : "bg-brand/10 border border-brand/30")
                  }
                >
                  {m.text}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
        <div className="p-3 border-t border-border space-y-2">
          <div className="flex flex-wrap gap-1.5">
            {script.map((qa: QaPair) => (
              <button
                key={qa.q}
                onClick={() => ask(qa.q)}
                className="text-[10px] border border-border rounded px-2 py-1 hover:bg-panel"
              >
                {qa.q}
              </button>
            ))}
          </div>
          <div className="flex gap-2">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && ask(input)}
              placeholder="Ask a question…"
              className="flex-1 bg-panel border border-border rounded px-3 py-2 text-sm outline-none focus:border-brand"
            />
            <button
              onClick={() => ask(input)}
              className="bg-brand text-surface px-3 py-2 rounded text-xs font-bold hover:brightness-110"
            >
              SEND
            </button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
