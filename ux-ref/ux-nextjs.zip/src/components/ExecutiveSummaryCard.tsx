import type { Scenario } from "@/lib/scenarios";

const BUCKET_COPY: Record<Scenario["decisionBucket"], string> = {
  absorb: "No action needed — your request fits in existing capacity.",
  provision: "New GPU hardware will be ordered to support your request.",
  rebalance: "Your request will be served by shifting capacity between pools — no new hardware needed.",
};

export function ExecutiveSummaryCard({ scenario }: { scenario: Scenario }) {
  const recommended = scenario.ladder.find((r) => r.verdict === "win");
  const cost = recommended?.deltaCost;
  const readyBy =
    scenario.forecast.breachDay == null
      ? "already within plan — no timeline risk"
      : `within ${Math.max(scenario.forecast.leadTimeDays, 1)} days if action starts now`;

  return (
    <div className="bg-panel border border-border rounded-xl p-6 max-w-xl">
      <div className="text-[10px] font-mono uppercase tracking-widest text-text-dim mb-2">
        What this means for you
      </div>
      <p className="text-base leading-relaxed">{BUCKET_COPY[scenario.decisionBucket]}</p>
      <dl className="mt-4 grid grid-cols-2 gap-4 text-sm">
        <div>
          <dt className="text-[10px] uppercase tracking-widest text-text-dim">GPU impact</dt>
          <dd className="mt-1 font-mono">{scenario.gpuImpact.label}</dd>
        </div>
        <div>
          <dt className="text-[10px] uppercase tracking-widest text-text-dim">Tokens/sec impact</dt>
          <dd className="mt-1 font-mono">{scenario.tokensSecImpact.label}</dd>
        </div>
        <div>
          <dt className="text-[10px] uppercase tracking-widest text-text-dim">Cost impact</dt>
          <dd className="mt-1 font-mono">{cost == null ? "No added cost" : `$${cost.toLocaleString()}/mo`}</dd>
        </div>
        <div>
          <dt className="text-[10px] uppercase tracking-widest text-text-dim">Ready by</dt>
          <dd className="mt-1 font-mono">{readyBy}</dd>
        </div>
      </dl>
    </div>
  );
}
