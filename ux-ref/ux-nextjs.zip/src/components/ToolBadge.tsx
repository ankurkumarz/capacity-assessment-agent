import { Badge } from "@/components/ui/badge";
import type { PumaTool } from "@/lib/scenarios";

const TOOL_LABEL: Record<PumaTool, string> = {
  grafana: "Grafana",
  puma: "PUMA",
  openshift: "OpenShift",
};

const TOOL_TONE: Record<PumaTool, string> = {
  grafana: "border-warn/40 text-warn bg-warn/10",
  puma: "border-brand/40 text-brand bg-brand/10",
  openshift: "border-bad/40 text-bad bg-bad/10",
};

export function ToolBadge({ tool }: { tool: PumaTool }) {
  return (
    <Badge variant="outline" className={`font-mono text-[9px] uppercase tracking-widest ${TOOL_TONE[tool]}`}>
      {TOOL_LABEL[tool]}
    </Badge>
  );
}

export function ToolBadgeRow({ tools }: { tools: PumaTool[] }) {
  return (
    <div className="flex gap-1.5">
      {tools.map((t) => (
        <ToolBadge key={t} tool={t} />
      ))}
    </div>
  );
}
