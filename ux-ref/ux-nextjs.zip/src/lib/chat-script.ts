import type { Scenario } from "./scenarios";

export type QaPair = { q: string; a: string; keywords: string[] };

const BUCKET_COPY: Record<Scenario["decisionBucket"], string> = {
  absorb: "No provisioning is required — the request is absorbed in existing headroom.",
  provision: "GPU infrastructure must be ordered to cover this request.",
  rebalance: "No new hardware is needed — capacity will be rebalanced across pools internally.",
};

export function buildQaScript(scenario: Scenario): QaPair[] {
  const recommended = scenario.ladder.find((r) => r.verdict === "win");
  const cost = recommended?.deltaCost;
  const costText = cost == null ? "no incremental monthly cost" : `about $${cost.toLocaleString()}/mo`;
  const breachText =
    scenario.forecast.breachDay == null
      ? "no capacity breach is projected within the 180-day forecast window"
      : `capacity is projected to breach policy in ${scenario.forecast.breachDay} days`;

  return [
    {
      q: "What decision did the recommendation engine make?",
      a: `${BUCKET_COPY[scenario.decisionBucket]} (recommended strategy: "${recommended?.strategy ?? "n/a"}").`,
      keywords: ["decision", "recommend", "why", "bucket"],
    },
    {
      q: "What is the GPU impact?",
      a: scenario.gpuImpact.label,
      keywords: ["gpu", "impact", "shortfall"],
    },
    {
      q: "What is the tokens/sec impact?",
      a: scenario.tokensSecImpact.label,
      keywords: ["token", "tokens/sec", "throughput", "tok/s"],
    },
    {
      q: "What will this cost?",
      a: `The recommended path costs ${costText}.`,
      keywords: ["cost", "price", "$", "budget"],
    },
    {
      q: "When will we run out of capacity?",
      a: breachText,
      keywords: ["when", "breach", "run out", "timeline", "forecast"],
    },
    {
      q: "What evidence backs this?",
      a: `Backed by ${scenario.evidence.length} evidence records, most recently as of ${scenario.asOf}.`,
      keywords: ["evidence", "source", "proof", "trust"],
    },
  ];
}

export function matchQuestion(script: QaPair[], input: string): QaPair | null {
  const lower = input.toLowerCase();
  return script.find((qa) => qa.keywords.some((k) => lower.includes(k))) ?? null;
}
