// Turns a derived scenario into a replayable execution trace: one step per
// workflow node, each with the tool calls / log lines that node emits. Pure —
// the animation layer just walks this list on a timer.

import { WORKFLOW, FLEET, POLICY } from "./engine";
import type { Scenario } from "./scenarios";

export type TraceLine = { t: "call" | "out" | "warn" | "ok"; text: string };
export type TraceStep = {
  id: string;
  label: string;
  kind: "agent" | "engine" | "record";
  ms: number;
  lines: TraceLine[];
};

const n = (x: number, d = 3) => x.toFixed(d);

export function buildTrace(s: Scenario): TraceStep[] {
  const win = s.ladder.find((r) => r.verdict === "win");
  const chosen = s.candidacy.find((p) => p.verdict === "chosen");
  const blocked = s.candidacy.filter((p) => p.verdict === "blocked");

  const byId: Record<string, TraceLine[]> = {
    intake: [
      { t: "call", text: `prov.lookup(ticket="${s.record.ticket}")` },
      { t: "out", text: `use_case="${s.record.useCase}" requester=${s.record.requester} model=${s.sizing.model}` },
      { t: "out", text: `peak_rps=${s.sizing.peakRps} out_tokens=${s.sizing.outTokens} concurrency=${s.sizing.concurrency}` },
      { t: "ok", text: `record ${s.record.id} opened · state=${s.record.state}` },
    ],
    input_review: s.hitl
      ? [
          { t: "call", text: `demand.validate(fields=6)` },
          { t: "warn", text: `missing/ambiguous: ${s.hitl.fields.join(", ")}` },
          s.hitl.answered
            ? { t: "ok", text: `human answered → ${Object.entries(s.hitl.answers ?? {}).map(([k, v]) => `${k}=${v}`).join(" ")}` }
            : { t: "warn", text: `awaiting human input — run paused at gate` },
        ]
      : [
          { t: "call", text: `demand.validate(fields=6)` },
          { t: "ok", text: `all six demand fields present · 0 assumptions (cap ${POLICY.max_assumptions_confident})` },
        ],
    evidence: [
      { t: "call", text: `registry.match(model="${s.sizing.model}")` },
      { t: "out", text: `best=${s.sizing.benchmarkId} score=${s.sizing.matchScore.toFixed(3)} band=${s.sizing.band}` },
      { t: "call", text: `inventory.pools() · fleet.maintenance()` },
      { t: "out", text: `${FLEET.pools.length} pools · snapshot ${FLEET.inventory_snapshot}` },
      s.sizing.band === "unusable"
        ? { t: "warn", text: `no record clears the ${POLICY.match.bands.usable} usable band` }
        : { t: "ok", text: `${s.evidence.length} trusted sources pinned` },
    ],
    forecast: [
      { t: "call", text: `forecast.series(horizon=180d)` },
      { t: "out", text: `${s.forecast.quality.model} · coverage ${(s.forecast.coverage.present * 100).toFixed(0)}% · gaps ${s.forecast.coverage.gaps}` },
      s.forecast.breachDay == null
        ? { t: "ok", text: `no policy-line breach inside 180d` }
        : {
            t: s.forecast.breachDay < s.forecast.leadTimeDays ? "warn" : "out",
            text: `breach day ${s.forecast.breachDay} vs ${s.forecast.leadTimeDays}d lead time`,
          },
    ],
    planning: [
      { t: "call", text: `sizing.derive()` },
      { t: "out", text: `required_replicas=${s.sizing.replicas} × ${n(s.sizing.gpusPerReplica)} ⇒ ${n(s.sizing.requiredGpus)} GPU` },
      { t: "out", text: `shortfall = ${n(s.sizing.requiredGpus)} − ${n(s.sizing.usableExisting)} − ${n(s.sizing.reclaimable)} = ${n(s.sizing.shortfallGpus)}` },
      { t: "call", text: `pools.sweep(gpu_per_replica=${n(s.sizing.gpusPerReplica)})` },
      ...blocked.slice(0, 3).map((p): TraceLine => ({ t: "warn", text: `${p.pool} blocked · ${p.reason}` })),
      ...s.ladder.map((r): TraceLine => ({
        t: r.verdict === "win" ? "ok" : r.verdict === "blocked" ? "warn" : "out",
        text: `rung ${r.step} ${r.strategy} → ${r.verdict === "win" ? "SELECTED" : r.verdict} · ${r.detail}`,
      })),
    ],
    record: [
      { t: "call", text: `record.write(assessment="${s.record.id}")` },
      { t: "out", text: `state=${s.recommendation.state} · confidence=${s.recommendation.confidence}` },
      chosen ? { t: "out", text: `target pool ${chosen.pool} (${chosen.sku})` } : { t: "out", text: `no pool commitment` },
      { t: "ok", text: `hash ${s.recommendation.hash} · policy ${POLICY.version} · writes=${s.guardrail.writes}` },
    ],
    explain: [
      { t: "call", text: `explain.render()` },
      { t: "out", text: s.narrative },
      win?.ack
        ? { t: "warn", text: `requires acknowledgement from ${win.ack}` }
        : { t: "ok", text: `manifest ready · ${s.evidence.length} sources · awaiting human approval` },
    ],
  };

  return WORKFLOW.nodes.map((node) => ({
    id: node.id,
    label: node.label,
    kind: node.kind,
    ms: node.kind === "engine" ? 1400 : 850,
    lines: (byId[node.id] ?? []).filter(Boolean) as TraceLine[],
  }));
}