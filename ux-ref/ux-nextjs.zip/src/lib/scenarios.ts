// Scenarios are demand + record + narrative inputs. Sizing, ladder, candidacy,
// hash and recommendation are DERIVED here by calling the deterministic
// engine in src/lib/engine.ts. Nothing in this file hand-writes a shortfall,
// a chosen pool, or a cost — those all fall out of the engine functions.

import {
  evaluateLadder,
  FLEET,
  hashOf,
  POLICY,
  rankMatches,
  SKUS,
  computeSizing,
  sweepCandidacy,
  type Demand,
  type LadderRung as EngineRung,
  type Match,
  type PoolVerdict,
  type SizingResult,
  type SizingStep,
} from "./engine";

export type ScenarioId =
  | "s1-available"
  | "s2-scale"
  | "s3-rebalance"
  | "s4-reserved"
  | "s5-procure"
  | "s6-manual";

export type RungVerdict = "met" | "blocked" | "eligible" | "win" | "na";

export type LadderRung = {
  step: number;
  strategy: string;
  verdict: RungVerdict;
  detail: string;
  deltaCost: number | null;
  ack?: string;
};

export type Evidence = {
  source: string;
  kind: string;
  value: string;
  asOf: string;
  trust: "trusted" | "advisory";
  staleness: "fresh" | "stale";
  confidence: "high" | "medium" | "low";
};

export type PoolCandidacy = {
  pool: string;
  sku?: string;
  freeGpus: number;
  largestContiguous: number;
  verdict: "eligible" | "blocked" | "chosen";
  reason: string;
  costMonthly?: number;
};

export type ForecastSeries = {
  baseline: number[];
  p10: number[];
  p90: number[];
  policyLine: number;
  breachDay: number | null;
  leadTimeDays: number;
  quality: { model: string; trained: string; folds: { fold: number; mape: number }[] };
  coverage: { present: number; gaps: number; longestGapDays: number };
};

export type Sizing = {
  model: string;
  gpusPerReplica: number;
  replicas: number;
  requiredGpus: number;
  usableExisting: number;
  reclaimable: number;
  shortfallGpus: number;
  peakRps: number;
  outTokens: number;
  concurrency: number;
  benchmarkId: string;
  band: "direct" | "derate" | "unusable";
  steps: SizingStep[];
  matchScore: number;
  matchDimensions: Match["dimensions"];
};

export type PumaTool = "grafana" | "puma" | "openshift";

export type PumaEvent = {
  eventId: string;
  receivedAt: string;
  tools: PumaTool[];
};

export type DecisionBucket = "absorb" | "provision" | "rebalance";

export type GpuImpact = { deltaGpus: number; label: string };
export type TokensSecImpact = { tokensPerSec: number; label: string };

export type Hitl = {
  question: string;
  fields: string[];
  answered: boolean;
  answers?: Record<string, string | number>;
};

export type Scenario = {
  id: ScenarioId;
  title: string;
  asOf: string;
  record: {
    id: string;
    useCase: string;
    requester: string;
    model: string;
    ticket: string;
    state: "draft" | "awaiting_input" | "assessing" | "awaiting_approval" | "approved" | "rejected";
    projectId?: string;
  };
  recommendation: {
    state: string;
    confidence: "high" | "medium" | "low";
    tone: "ok" | "warn" | "bad" | "info";
    hash: string;
  };
  guardrail: { writes: number; allowlisted: number; blocked: number; retries: number };
  hitl?: Hitl;
  sizing: Sizing;
  evidence: Evidence[];
  candidacy: PoolCandidacy[];
  ladder: LadderRung[];
  forecast: ForecastSeries;
  narrative: string;
  pumaEvent: PumaEvent;
  decisionBucket: DecisionBucket;
  gpuImpact: GpuImpact;
  tokensSecImpact: TokensSecImpact;
};

// ── Config per scenario (demand + narrative shell) ──────────────────────────

type ScenarioConfig = {
  id: ScenarioId;
  title: string;
  asOf: string;
  record: Scenario["record"];
  demand: Demand;
  extraEvidence: Evidence[];
  guardrail: Scenario["guardrail"];
  hitl?: Hitl;
  pumaEvent: PumaEvent;
  forecast: {
    baseFn: (d: number) => number;
    p10Factor: number;
    p90Factor: number;
    policyLine: number;
    folds: { fold: number; mape: number }[];
    coverage: ForecastSeries["coverage"];
    quality: { model: string; trained: string };
  };
  narrative: string;
};

const CONFIGS: ScenarioConfig[] = [
  {
    id: "s1-available",
    title: "Incomplete prompt → Available / Ready",
    asOf: "2026-07-23T14:00:00Z",
    record: { id: "ASM-4471", useCase: "fraud scoring", requester: "a.rivera", model: "mistral-7b", ticket: "PROV-8821", state: "awaiting_approval" },
    demand: {
      model_id: "mistral-7b", params_b: 7,
      runtime: { engine: "vllm", version: "0.9" }, hardware: { sku: "H100-80G", tp: 2 },
      precision: "fp8", traffic: { in_bucket: "2048", out_bucket: "512", concurrency: 64, streaming: true },
      peak_rps: 96, avg_output_tokens: 512, peak_concurrency: 480,
      usable_existing_gpus: 8.571, approved_reclaimable_gpus: 0, deployment_pool_id: "pool-C",
    },
    guardrail: { writes: 0, allowlisted: 14, blocked: 0, retries: 1 },
    pumaEvent: { eventId: "PUMA-EVT-88214", receivedAt: "2026-07-23T13:55:00Z", tools: ["puma", "grafana"] },
    hitl: {
      question: "Two inputs are missing. Average output tokens per request, and peak concurrent requests?",
      fields: ["avg_output_tokens", "peak_concurrency"], answered: true,
      answers: { avg_output_tokens: 512, peak_concurrency: 480 },
    },
    extraEvidence: [
      { source: "provisioning", kind: "demand_fields", value: "4 of 6 fields recovered from PROV-8821", asOf: "2026-07-23T13:59:00Z", trust: "trusted", staleness: "fresh", confidence: "high" },
      { source: "telemetry", kind: "p95_util", value: "0.62 over 30d", asOf: "2026-07-23T14:01:00Z", trust: "trusted", staleness: "fresh", confidence: "high" },
    ],
    forecast: {
      baseFn: (d) => 62 + 0.06 * d, p10Factor: 0.88, p90Factor: 1.15, policyLine: 96,
      folds: [{ fold: 1, mape: 0.079 }, { fold: 2, mape: 0.084 }, { fold: 3, mape: 0.078 }],
      coverage: { present: 0.92, gaps: 3, longestGapDays: 4 },
      quality: { model: "Prophet v1.4", trained: "2026-07-22" },
    },
    narrative:
      "Fraud scoring needs 29 replicas of Mistral 7B at 2/7 GPU each. That is 8.286 GPU against 8.571 already allocated, so it fits in live headroom — no shortfall, no procurement.",
  },
  {
    id: "s2-scale",
    title: "Modest growth → Scale existing deployment in home pool",
    asOf: "2026-07-23T14:00:00Z",
    record: { id: "ASM-4476", useCase: "document summarisation", requester: "l.chen", model: "mistral-7b", ticket: "PROV-8877", state: "awaiting_approval" },
    demand: {
      model_id: "mistral-7b", params_b: 7,
      runtime: { engine: "vllm", version: "0.9" }, hardware: { sku: "H100-80G", tp: 2 },
      precision: "fp8", traffic: { in_bucket: "2048", out_bucket: "512", concurrency: 64, streaming: true },
      peak_rps: 96, avg_output_tokens: 512, peak_concurrency: 480,
      usable_existing_gpus: 7.0, approved_reclaimable_gpus: 0, deployment_pool_id: "pool-C",
    },
    guardrail: { writes: 0, allowlisted: 16, blocked: 0, retries: 0 },
    pumaEvent: { eventId: "PUMA-EVT-88221", receivedAt: "2026-07-23T13:56:00Z", tools: ["puma", "openshift"] },
    extraEvidence: [
      { source: "provisioning", kind: "demand_fields", value: "all six fields present in PROV-8877", asOf: "2026-07-23T13:56:00Z", trust: "trusted", staleness: "fresh", confidence: "high" },
      { source: "telemetry", kind: "p95_util", value: "0.71 over 30d", asOf: "2026-07-23T14:00:00Z", trust: "trusted", staleness: "fresh", confidence: "high" },
    ],
    forecast: {
      baseFn: (d) => 70 + 0.04 * d, p10Factor: 0.9, p90Factor: 1.13, policyLine: 105,
      folds: [{ fold: 1, mape: 0.068 }, { fold: 2, mape: 0.073 }, { fold: 3, mape: 0.07 }],
      coverage: { present: 0.94, gaps: 2, longestGapDays: 3 },
      quality: { model: "Prophet v1.4", trained: "2026-07-22" },
    },
    narrative:
      "Summarisation needs 8.286 GPU against 7.000 allocated — a 1.286 shortfall. The home pool (pool-C) is healthy with a 12.0 contiguous block, so the deployment simply scales in place; no rebalance, no procurement.",
  },
  {
    id: "s3-rebalance",
    title: "Maintenance freeze + fragmentation → Rebalance capacity",
    asOf: "2026-07-23T14:00:00Z",
    record: { id: "ASM-4482", useCase: "claims triage", requester: "m.okafor", model: "mistral-7b", ticket: "PROV-9014", state: "awaiting_approval" },
    demand: {
      model_id: "mistral-7b", params_b: 7,
      runtime: { engine: "vllm", version: "0.9" }, hardware: { sku: "H100-80G", tp: 2 },
      precision: "fp8", traffic: { in_bucket: "2048", out_bucket: "512", concurrency: 64, streaming: true },
      peak_rps: 96, avg_output_tokens: 512, peak_concurrency: 480,
      usable_existing_gpus: 6.571, approved_reclaimable_gpus: 0, deployment_pool_id: "pool-A",
    },
    guardrail: { writes: 0, allowlisted: 18, blocked: 0, retries: 0 },
    pumaEvent: { eventId: "PUMA-EVT-88229", receivedAt: "2026-07-23T13:56:00Z", tools: ["grafana", "openshift"] },
    extraEvidence: [
      { source: "provisioning", kind: "demand_fields", value: "all six fields present in PROV-9014", asOf: "2026-07-23T13:57:00Z", trust: "trusted", staleness: "fresh", confidence: "high" },
      { source: "telemetry", kind: "p95_util", value: "0.79 over 30d", asOf: "2026-07-23T14:00:00Z", trust: "trusted", staleness: "fresh", confidence: "high" },
      { source: "maintenance", kind: "freeze", value: "pool-A frozen until 2026-08-14 (firmware)", asOf: "2026-07-23T13:58:00Z", trust: "trusted", staleness: "fresh", confidence: "high" },
    ],
    forecast: {
      baseFn: (d) => 78 + 0.02 * d, p10Factor: 0.9, p90Factor: 1.12, policyLine: 110,
      folds: [{ fold: 1, mape: 0.071 }, { fold: 2, mape: 0.077 }, { fold: 3, mape: 0.074 }],
      coverage: { present: 0.96, gaps: 1, longestGapDays: 2 },
      quality: { model: "Prophet v1.4", trained: "2026-07-22" },
    },
    narrative:
      "Claims triage needs 8.286 GPU; pool-A holds 6.571, leaving a 1.714 shortfall. Pool A is frozen until Aug 14 and pool B has 9.4 free but no contiguous block bigger than 0.143 — too fragmented for a 0.286 replica. Pool C has 12.0 contiguous, so the shortfall rebalances there.",
  },
  {
    id: "s4-reserved",
    title: "Shortfall exceeds every live pool → Activate reserved capacity",
    asOf: "2026-07-23T14:00:00Z",
    record: { id: "ASM-4495", useCase: "contact-centre copilot", requester: "d.abara", model: "meta-llama-3.3-70b", ticket: "PROV-9098", state: "awaiting_approval", projectId: "5038" },
    demand: {
      model_id: "meta-llama-3.3-70b", params_b: 70,
      runtime: { engine: "vllm", version: "0.8" }, hardware: { sku: "A100-80G", tp: 4 },
      precision: "bf16", traffic: { in_bucket: "1024", out_bucket: "256", concurrency: 32, streaming: true },
      peak_rps: 200, avg_output_tokens: 256, peak_concurrency: 400,
      usable_existing_gpus: 27.0, approved_reclaimable_gpus: 0, deployment_pool_id: "pool-D",
    },
    guardrail: { writes: 0, allowlisted: 19, blocked: 0, retries: 0 },
    pumaEvent: { eventId: "PUMA-EVT-88241", receivedAt: "2026-07-23T13:57:00Z", tools: ["puma", "grafana", "openshift"] },
    extraEvidence: [
      { source: "provisioning", kind: "demand_fields", value: "all six fields present in PROV-9098", asOf: "2026-07-23T13:55:00Z", trust: "trusted", staleness: "fresh", confidence: "high" },
      { source: "inventory", kind: "reserved_pool", value: "pool-G dormant · 36 GPU racked, unpowered · 5d activation", asOf: "2026-07-23T13:58:00Z", trust: "trusted", staleness: "fresh", confidence: "high" },
    ],
    forecast: {
      baseFn: (d) => 200 + 0.18 * d, p10Factor: 0.91, p90Factor: 1.11, policyLine: 260,
      folds: [{ fold: 1, mape: 0.088 }, { fold: 2, mape: 0.092 }, { fold: 3, mape: 0.086 }],
      coverage: { present: 0.9, gaps: 2, longestGapDays: 5 },
      quality: { model: "Prophet v1.4", trained: "2026-07-22" },
    },
    narrative:
      "The copilot needs ~41.7 GPU against 27.0 allocated. No live pool has both a big enough contiguous block and enough free capacity for the 14.7 shortfall, but the dormant reserved pool-G has 36 contiguous — so activation beats a 74-day procurement.",
  },
  {
    id: "s5-procure",
    title: "Rising demand → breach in 140d → Order infrastructure",
    asOf: "2026-07-23T14:00:00Z",
    record: { id: "ASM-4508", useCase: "voice agent (meta-llama-3.3-70b)", requester: "r.singh", model: "meta-llama-3.3-70b", ticket: "PROV-9142", state: "awaiting_approval" },
    demand: {
      model_id: "meta-llama-3.3-70b", params_b: 70,
      runtime: { engine: "vllm", version: "0.8" }, hardware: { sku: "A100-80G", tp: 4 },
      precision: "bf16", traffic: { in_bucket: "1024", out_bucket: "256", concurrency: 32, streaming: true },
      peak_rps: 245, avg_output_tokens: 256, peak_concurrency: 640,
      usable_existing_gpus: 11.428, approved_reclaimable_gpus: 2.0, deployment_pool_id: "pool-E",
    },
    guardrail: { writes: 0, allowlisted: 21, blocked: 0, retries: 2 },
    pumaEvent: { eventId: "PUMA-EVT-88251", receivedAt: "2026-07-23T13:57:00Z", tools: ["puma", "openshift", "grafana"] },
    extraEvidence: [
      { source: "provisioning", kind: "demand_fields", value: "all six fields present in PROV-9142", asOf: "2026-07-23T13:57:00Z", trust: "trusted", staleness: "fresh", confidence: "high" },
      { source: "telemetry", kind: "p95_util", value: "0.88 over 30d — trending up", asOf: "2026-07-23T14:00:00Z", trust: "trusted", staleness: "fresh", confidence: "high" },
    ],
    forecast: {
      baseFn: (d) => 245 + 1.16 * d, p10Factor: 0.9, p90Factor: 1.12, policyLine: 380,
      folds: [{ fold: 1, mape: 0.104 }, { fold: 2, mape: 0.126 }, { fold: 3, mape: 0.098 }],
      coverage: { present: 0.84, gaps: 5, longestGapDays: 8 },
      quality: { model: "Prophet v1.4", trained: "2026-07-22" },
    },
    narrative:
      "The voice agent needs 50.857 GPU against 13.428 usable — a 37.4 shortfall that overflows even the 36-GPU reserved pool. Demand also climbs 1.16 rps/day and crosses the policy line inside 180d, while rack lead time is 74d, so the order has to start now.",
  },
];

CONFIGS.push({
  id: "s6-manual",
  title: "No usable benchmark → Manual review",
  asOf: "2026-07-23T14:00:00Z",
  record: { id: "ASM-4521", useCase: "long-context legal review", requester: "s.novak", model: "meta-llama-3.3-70b", ticket: "PROV-9188", state: "awaiting_input" },
  demand: {
    model_id: "meta-llama-3.3-70b", params_b: 70,
    runtime: { engine: "trtllm", version: "0.12" }, hardware: { sku: "H100-80G", tp: 2 },
    precision: "fp8", traffic: { in_bucket: "4096", out_bucket: "1024", concurrency: 8, streaming: true },
    peak_rps: 60, avg_output_tokens: 1024, peak_concurrency: 96,
    usable_existing_gpus: 4.0, approved_reclaimable_gpus: 0, deployment_pool_id: "pool-E",
  },
  guardrail: { writes: 0, allowlisted: 12, blocked: 2, retries: 3 },
  pumaEvent: { eventId: "PUMA-EVT-88259", receivedAt: "2026-07-23T13:58:00Z", tools: ["grafana", "puma"] },
  hitl: {
    question:
      "No benchmark clears the usable band for TensorRT-LLM on H100 TP2 at fp8. Commission a benchmark run, or approve an explicit derate assumption?",
    fields: ["benchmark_request", "derate_assumption"],
    answered: false,
  },
  extraEvidence: [
    { source: "benchmark-registry", kind: "coverage_gap", value: "0 records for trtllm on H100-80G TP2 · nearest is vllm/A100 TP4", asOf: "2026-07-23T13:59:00Z", trust: "trusted", staleness: "fresh", confidence: "high" },
    { source: "provisioning", kind: "demand_fields", value: "all six fields present in PROV-9188", asOf: "2026-07-23T13:55:00Z", trust: "trusted", staleness: "fresh", confidence: "high" },
  ],
  forecast: {
    baseFn: (d) => 60 + 0.09 * d, p10Factor: 0.82, p90Factor: 1.24, policyLine: 90,
    folds: [{ fold: 1, mape: 0.192 }, { fold: 2, mape: 0.214 }, { fold: 3, mape: 0.181 }],
    coverage: { present: 0.71, gaps: 9, longestGapDays: 14 },
    quality: { model: "Prophet v1.4", trained: "2026-07-22" },
  },
  narrative:
    "Every candidate benchmark falls below the 0.65 usable band — a two-architecture hop plus an engine-family change. Policy forbids sizing off an unusable record, so the ladder short-circuits to manual review pending a commissioned benchmark.",
});

// ── Derivation ──────────────────────────────────────────────────────────────

const TONE_BY_STATE: Record<string, "ok" | "warn" | "bad" | "info"> = {
  available: "ok",
  scale_model: "warn",
  rebalance: "warn",
  activate: "warn",
  order_infra: "bad",
  manual_review: "info",
};

const LABEL_BY_STATE: Record<string, string> = {
  available: "Available / Ready",
  scale_model: "Scale existing deployment",
  rebalance: "Rebalance capacity",
  activate: "Activate reserved capacity",
  order_infra: "Order infrastructure",
  manual_review: "Manual review",
};

const BUCKET_BY_STATE: Record<string, DecisionBucket> = {
  available: "absorb",
  scale_model: "rebalance",
  rebalance: "rebalance",
  activate: "rebalance",
  order_infra: "provision",
  manual_review: "provision",
};

function deriveGpuImpact(shortfallGpus: number): GpuImpact {
  if (shortfallGpus <= 0) {
    return { deltaGpus: 0, label: "Absorbed in existing headroom" };
  }
  return { deltaGpus: shortfallGpus, label: `+${shortfallGpus.toFixed(3)} GPU needed` };
}

function deriveTokensSecImpact(peakRps: number, outTokens: number): TokensSecImpact {
  const tokensPerSec = Math.round(peakRps * outTokens);
  return { tokensPerSec, label: `${tokensPerSec.toLocaleString()} tok/s at peak` };
}

function buildForecast(cfg: ScenarioConfig["forecast"]): ForecastSeries {
  const baseline: number[] = [];
  const p10: number[] = [];
  const p90: number[] = [];
  for (let d = 0; d < 180; d++) {
    const v = Math.round(cfg.baseFn(d) * 100) / 100;
    baseline.push(v);
    p10.push(Math.round(v * cfg.p10Factor * 100) / 100);
    p90.push(Math.round(v * cfg.p90Factor * 100) / 100);
  }
  const idx = baseline.findIndex((v) => v >= cfg.policyLine);
  const lead = POLICY.lead_time_days.order + POLICY.lead_time_days.delivery + POLICY.lead_time_days.rack + POLICY.lead_time_days.network;
  return {
    baseline, p10, p90,
    policyLine: cfg.policyLine,
    breachDay: idx >= 0 ? idx : null,
    leadTimeDays: lead,
    quality: { ...cfg.quality, folds: cfg.folds },
    coverage: cfg.coverage,
  };
}

function mapLadder(engine: EngineRung[], recommended: number): LadderRung[] {
  return engine.map((r) => {
    const isRec = r.rank === recommended;
    const verdict: RungVerdict = isRec ? "win" : r.verdict;
    const cost = r.cost_monthly ?? r.capex ?? null;
    const bits: string[] = [];
    if (r.reason) bits.push(r.reason);
    if (r.cost_monthly != null) bits.push(`$${r.cost_monthly.toLocaleString()}/mo`);
    if (r.capex != null && r.rank === 5) bits.push(`$${r.capex.toLocaleString()} capex`);
    if (r.pool_id) bits.push(`pool ${r.pool_id}`);
    return {
      step: r.rank,
      strategy: r.option,
      verdict,
      detail: bits.join(" · ") || "—",
      deltaCost: cost,
      ack: r.rank === 5 && isRec ? "infra_planner" : undefined,
    };
  });
}

function evidenceForMatch(match: Match | undefined, demand: Demand): Evidence[] {
  const evs: Evidence[] = [];
  if (match) {
    const r = match.record;
    const measured = new Date(match.record.measured_at);
    const ageDays = Math.round((new Date("2026-07-23T14:00:00Z").getTime() - measured.getTime()) / 86400000);
    evs.push({
      source: "benchmark-registry", kind: "benchmark_record",
      value: `${r.id} · ${r.runtime.engine} ${r.runtime.version} · ${r.hardware.sku} TP${r.hardware.tp} · ${r.precision} · ${ageDays}d (score ${match.score.toFixed(2)}, ${match.band})`,
      asOf: r.measured_at, trust: "trusted",
      staleness: ageDays > 60 ? "stale" : "fresh",
      confidence: match.band === "direct" ? "high" : match.band === "derate" ? "medium" : "low",
    });
  }
  evs.push({
    source: "deployments", kind: "usable_existing_gpus",
    value: `${demand.usable_existing_gpus.toFixed(3)} GPU allocated in ${demand.deployment_pool_id}`,
    asOf: "2026-07-23T13:58:00Z", trust: "trusted", staleness: "fresh", confidence: "high",
  });
  evs.push({
    source: "inventory", kind: "fleet_snapshot",
    value: `${FLEET.inventory_snapshot} · ${FLEET.pools.length} pools · ${FLEET.pools.reduce((a, p) => a + p.total_gpus, 0)} GPUs`,
    asOf: FLEET.as_of, trust: "trusted", staleness: "fresh", confidence: "high",
  });
  return evs;
}

function buildScenario(cfg: ScenarioConfig): Scenario {
  const matches = rankMatches(cfg.demand, cfg.asOf);
  const best = matches[0];
  const sizing = computeSizing(cfg.demand, best);
  const gpr = best.record.gpus_per_replica;
  const rawLadder = evaluateLadder(sizing, gpr, cfg.demand.deployment_pool_id);
  // Policy gate: sizing off an unusable benchmark is forbidden, so the whole
  // ladder short-circuits to manual review no matter what the pools look like.
  const ladder = best.usable
    ? rawLadder
    : {
        recommended_rank: 6,
        state: "manual_review" as const,
        rungs: rawLadder.rungs.map((r) =>
          r.rank === 6
            ? { ...r, verdict: "met" as const, reason: `best match ${best.record_id} scores ${best.score.toFixed(2)} < 0.65 usable band` }
            : { ...r, verdict: "blocked" as const, reason: "gated: no usable benchmark", cost_monthly: undefined, capex: undefined, pool_id: undefined },
        ),
      };
  const chosen = ladder.rungs.find((r) => r.rank === ladder.recommended_rank)?.pool_id;
  const candidacyEngine = sweepCandidacy(gpr, sizing.shortfall_gpus, chosen);
  const forecast = buildForecast(cfg.forecast);

  const recStateLabel = LABEL_BY_STATE[ladder.state];
  const tone = TONE_BY_STATE[ladder.state];
  const confidence: "high" | "medium" | "low" =
    best.band === "direct" ? "high" : best.band === "derate" ? "medium" : "low";

  const decisionBucket = BUCKET_BY_STATE[ladder.state];
  const gpuImpact = deriveGpuImpact(sizing.shortfall_gpus);
  const tokensSecImpact = deriveTokensSecImpact(cfg.demand.peak_rps, cfg.demand.avg_output_tokens);

  const hash = hashOf({
    demand: cfg.demand,
    fleet_snapshot: FLEET.inventory_snapshot,
    policy_version: POLICY.version,
    match: best.record_id,
    ladder_state: ladder.state,
    shortfall: sizing.shortfall_gpus,
  });
  const shortHash = `${hash.slice(0, 4)}…${hash.slice(-4)}`;

  return {
    id: cfg.id,
    title: cfg.title,
    asOf: cfg.asOf,
    record: cfg.record,
    recommendation: { state: recStateLabel, confidence, tone, hash: shortHash },
    guardrail: cfg.guardrail,
    hitl: cfg.hitl,
    sizing: {
      model: cfg.demand.model_id,
      gpusPerReplica: gpr,
      replicas: sizing.required_replicas,
      requiredGpus: sizing.required_gpus,
      usableExisting: cfg.demand.usable_existing_gpus,
      reclaimable: cfg.demand.approved_reclaimable_gpus,
      shortfallGpus: sizing.shortfall_gpus,
      peakRps: cfg.demand.peak_rps,
      outTokens: cfg.demand.avg_output_tokens,
      concurrency: cfg.demand.peak_concurrency,
      benchmarkId: best.record_id,
      band: best.band,
      steps: sizing.steps,
      matchScore: best.score,
      matchDimensions: best.dimensions,
    },
    evidence: [...cfg.extraEvidence, ...evidenceForMatch(best, cfg.demand)],
    candidacy: candidacyEngine.map((p: PoolVerdict) => ({
      pool: p.pool,
      sku: p.sku,
      freeGpus: p.freeGpus,
      largestContiguous: p.largestContiguous,
      verdict: p.verdict,
      reason: p.reason,
      costMonthly: p.costMonthly,
    })),
    ladder: mapLadder(ladder.rungs, ladder.recommended_rank),
    forecast,
    narrative: cfg.narrative,
    pumaEvent: cfg.pumaEvent,
    decisionBucket,
    gpuImpact,
    tokensSecImpact,
  };
}

export const SCENARIOS: Record<ScenarioId, Scenario> = Object.fromEntries(
  CONFIGS.map((c) => [c.id, buildScenario(c)]),
) as Record<ScenarioId, Scenario>;

export const SCENARIO_ORDER: ScenarioId[] = [
  "s1-available",
  "s2-scale",
  "s3-rebalance",
  "s4-reserved",
  "s5-procure",
  "s6-manual",
];

export function manifestText(s: Scenario): string {
  const lines: string[] = [];
  lines.push(`# EVIDENCE MANIFEST · ${s.record.id} · asOf ${s.asOf}`);
  lines.push(`# recommendation: ${s.recommendation.state} · hash ${s.recommendation.hash}`);
  lines.push("");
  lines.push(`[demand_profile]`);
  lines.push(`  model=${s.sizing.model}`);
  lines.push(`  peak_rps=${s.sizing.peakRps}  out_tokens=${s.sizing.outTokens}  concurrency=${s.sizing.concurrency}`);
  lines.push(`  benchmark=${s.sizing.benchmarkId} band=${s.sizing.band} score=${s.sizing.matchScore.toFixed(3)}`);
  lines.push("");
  lines.push(`[sizing]`);
  lines.push(`  replicas=${s.sizing.replicas} × ${s.sizing.gpusPerReplica.toFixed(3)} GPU/replica`);
  lines.push(`  required=${s.sizing.requiredGpus.toFixed(3)}  usable=${s.sizing.usableExisting.toFixed(3)}  reclaimable=${s.sizing.reclaimable.toFixed(3)}`);
  lines.push(`  ⇒ shortfall=${s.sizing.shortfallGpus.toFixed(3)}`);
  lines.push("");
  lines.push(`[evidence]`);
  s.evidence.forEach((e) => {
    lines.push(
      `  ${e.source}.${e.kind}  = "${e.value}"  as_of=${e.asOf}  trust=${e.trust}  ${e.staleness}  conf=${e.confidence}`,
    );
  });
  lines.push("");
  lines.push(`[pool_candidacy]`);
  s.candidacy.forEach((p) => {
    lines.push(
      `  ${p.pool}  free=${p.freeGpus.toFixed(3)}  block=${p.largestContiguous.toFixed(3)}  ${p.verdict}  · ${p.reason}`,
    );
  });
  lines.push("");
  lines.push(`[ladder]`);
  s.ladder.forEach((r) => {
    const d = r.deltaCost == null ? "—" : `$${r.deltaCost.toLocaleString()}`;
    lines.push(`  ${r.step}. ${r.strategy}  [${r.verdict}]  ${d}  · ${r.detail}`);
  });
  return lines.join("\n");
}

// Re-export SKUS for callers that need to read pool prices.
export { SKUS };