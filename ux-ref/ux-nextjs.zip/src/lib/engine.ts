// Deterministic planning engine ported from the reference `capacity/` app.
// Pure functions, no I/O, no randomness — the same inputs always produce the
// same outputs, including the FNV-1a `hashOf()` used as the recommendation
// fingerprint. UI layers consume this via src/lib/scenarios.ts.

// ── Data ────────────────────────────────────────────────────────────────────

export const POLICY = {
  version: "cap-policy v3.2",
  target_utilization: 0.8,
  reserve_gpus: 0,
  minimum_HA_replicas: 3,
  staleness_hours: { telemetry: 48, inventory: 24 },
  min_coverage: 0.85,
  match: {
    weights: {
      model_identity: 0.25,
      hardware: 0.25,
      runtime: 0.15,
      precision: 0.15,
      traffic: 0.15,
      freshness: 0.05,
    },
    bands: { direct: 0.9, usable: 0.65 },
    freshness_max_days: 180,
  },
  lead_time_days: { order: 21, delivery: 35, rack: 10, network: 8 },
  max_assumptions_confident: 1,
} as const;

export type Sku = "H100-80G" | "A100-80G" | "L40S-48G";

export const SKUS: Record<
  Sku,
  { memory_gb: number; capex: number; cost_per_gpu_hour: number; granularity: number; tps_factor: number }
> = {
  "H100-80G": { memory_gb: 80, capex: 30000, cost_per_gpu_hour: 3.2, granularity: 1 / 7, tps_factor: 1.0 },
  "A100-80G": { memory_gb: 80, capex: 12000, cost_per_gpu_hour: 1.4, granularity: 1 / 7, tps_factor: 0.45 },
  "L40S-48G": { memory_gb: 48, capex: 8000, cost_per_gpu_hour: 0.9, granularity: 1 / 2, tps_factor: 0.3 },
};

export type Pool = {
  id: string;
  site: string;
  sku: Sku;
  total_gpus: number;
  free_gpus: number;
  largest_contiguous: number;
  maintenance?: { until: string; reason: string };
  reserved?: { state: string; note: string };
};

export const FLEET: { as_of: string; inventory_snapshot: string; pools: Pool[] } = {
  as_of: "2026-07-23T13:58:00Z",
  inventory_snapshot: "snap-2026-07-23T13:58Z",
  pools: [
    { id: "pool-A", site: "dc-east", sku: "H100-80G", total_gpus: 84, free_gpus: 6.857142857142857, largest_contiguous: 6.857142857142857, maintenance: { until: "2026-08-14", reason: "firmware" } },
    { id: "pool-B", site: "dc-east", sku: "A100-80G", total_gpus: 84, free_gpus: 9.428571428571429, largest_contiguous: 0.14285714285714285 },
    { id: "pool-C", site: "dc-east", sku: "A100-80G", total_gpus: 84, free_gpus: 12.0, largest_contiguous: 12.0 },
    { id: "pool-D", site: "dc-west", sku: "L40S-48G", total_gpus: 40, free_gpus: 8.0, largest_contiguous: 4.0 },
    { id: "pool-E", site: "dc-west", sku: "H100-80G", total_gpus: 28, free_gpus: 3.0, largest_contiguous: 2.0 },
    { id: "pool-F", site: "dc-west", sku: "A100-80G", total_gpus: 56, free_gpus: 5.0, largest_contiguous: 3.0 },
    { id: "pool-G", site: "dc-east", sku: "H100-80G", total_gpus: 36, free_gpus: 36.0, largest_contiguous: 36.0, reserved: { state: "dormant", note: "racked, unpowered" } },
  ],
};

export const MODELS = [
  { id: "mistral-7b", name: "Mistral 7B", params_b: 7, tps_h100: 7700 },
  { id: "mistral-nemo-instruct-fp8", name: "Mistral NeMo Instruct FP8", params_b: 12, tps_h100: 5200 },
  { id: "gemma-3-27b", name: "Gemma 3 27B", params_b: 27, tps_h100: 3400 },
  { id: "stellar", name: "Stellar", params_b: 109, tps_h100: 2600 },
  { id: "meta-llama-3.3-70b", name: "Meta Llama 3.3 70B", params_b: 70, tps_h100: 1400 },
] as const;

export type BenchmarkRecord = {
  id: string;
  model_id: string;
  runtime: { engine: string; version: string };
  hardware: { sku: Sku; tp: number };
  precision: string;
  traffic: { in_bucket: string; out_bucket: string; concurrency: number; streaming: boolean };
  measured_at: string;
  output_tps_per_replica: number;
  max_concurrency_per_replica: number;
  gpus_per_replica: number;
};

export const REGISTRY: BenchmarkRecord[] = [
  { id: "R-1187", model_id: "mistral-7b", runtime: { engine: "vllm", version: "0.9" }, hardware: { sku: "H100-80G", tp: 2 }, precision: "fp8", traffic: { in_bucket: "2048", out_bucket: "512", concurrency: 64, streaming: true }, measured_at: "2026-06-22T00:00:00Z", output_tps_per_replica: 2200, max_concurrency_per_replica: 24, gpus_per_replica: 2 / 7 },
  { id: "R-1044", model_id: "mistral-nemo-instruct-fp8", runtime: { engine: "vllm", version: "0.9" }, hardware: { sku: "A100-80G", tp: 2 }, precision: "bf16", traffic: { in_bucket: "2048", out_bucket: "512", concurrency: 48, streaming: true }, measured_at: "2026-06-01T00:00:00Z", output_tps_per_replica: 1500, max_concurrency_per_replica: 20, gpus_per_replica: 2 / 7 },
  { id: "R-0770", model_id: "meta-llama-3.3-70b", runtime: { engine: "vllm", version: "0.8" }, hardware: { sku: "A100-80G", tp: 4 }, precision: "bf16", traffic: { in_bucket: "1024", out_bucket: "256", concurrency: 32, streaming: true }, measured_at: "2026-04-20T00:00:00Z", output_tps_per_replica: 900, max_concurrency_per_replica: 16, gpus_per_replica: 4 / 7 },
  { id: "R-0932", model_id: "meta-llama-3.3-70b", runtime: { engine: "vllm", version: "0.8" }, hardware: { sku: "A100-80G", tp: 4 }, precision: "bf16", traffic: { in_bucket: "2048", out_bucket: "512", concurrency: 32, streaming: true }, measured_at: "2025-12-23T14:00:00Z", output_tps_per_replica: 950, max_concurrency_per_replica: 16, gpus_per_replica: 4 / 7 },
  { id: "R-0611", model_id: "meta-llama-3.3-70b", runtime: { engine: "vllm", version: "0.9" }, hardware: { sku: "L40S-48G", tp: 8 }, precision: "fp8", traffic: { in_bucket: "2048", out_bucket: "512", concurrency: 32, streaming: true }, measured_at: "2026-06-10T00:00:00Z", output_tps_per_replica: 420, max_concurrency_per_replica: 12, gpus_per_replica: 4.0 },
];

export const WORKFLOW = {
  nodes: [
    { id: "intake", label: "1 Intake", kind: "agent" as const },
    { id: "input_review", label: "2 Input Review", kind: "agent" as const },
    { id: "evidence", label: "3 Evidence", kind: "agent" as const },
    { id: "forecast", label: "4 Forecast", kind: "agent" as const },
    { id: "planning", label: "5 Planning Engine", kind: "engine" as const },
    { id: "record", label: "6 Record", kind: "record" as const },
    { id: "explain", label: "7 Explain", kind: "agent" as const },
  ],
  edges: [
    ["intake", "input_review"],
    ["input_review", "evidence"],
    ["evidence", "forecast"],
    ["forecast", "planning"],
    ["planning", "record"],
    ["record", "explain"],
  ] as [string, string][],
  tool_allowlist: [
    "prov.lookup", "registry.match", "deploy.headroom", "telemetry.utilization",
    "inventory.pools", "inventory.allocations", "fleet.maintenance",
    "scale.candidates", "forecast.series",
  ],
};

// ── Utilities ───────────────────────────────────────────────────────────────

export const round2 = (x: number) => Math.round((x + Number.EPSILON) * 100) / 100;
export const ceilToQuantum = (x: number, q: number) => Math.ceil(x / q - 1e-9) * q;

function stableStringify(v: unknown): string {
  if (v === null || typeof v !== "object") return JSON.stringify(v);
  if (Array.isArray(v)) return "[" + v.map(stableStringify).join(",") + "]";
  const keys = Object.keys(v as object).sort();
  return (
    "{" +
    keys.map((k) => JSON.stringify(k) + ":" + stableStringify((v as Record<string, unknown>)[k])).join(",") +
    "}"
  );
}

// FNV-1a over key-sorted serialization — deterministic across runs.
export function hashOf(obj: unknown): string {
  const s = stableStringify(obj);
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return (h >>> 0).toString(16).padStart(8, "0");
}

// ── Matcher ─────────────────────────────────────────────────────────────────

export type Demand = {
  model_id: string;
  params_b: number;
  runtime: { engine: string; version: string };
  hardware: { sku: Sku; tp: number };
  precision: string;
  traffic: { in_bucket: string; out_bucket: string; concurrency: number; streaming: boolean };
  peak_rps: number;
  avg_output_tokens: number;
  peak_concurrency: number;
  usable_existing_gpus: number;
  approved_reclaimable_gpus: number;
  deployment_pool_id: string;
};

export type MatchDimension = { name: string; weight: number; score: number; reason: string };
export type Match = {
  record_id: string;
  score: number;
  band: "direct" | "derate" | "unusable";
  usable: boolean;
  dimensions: MatchDimension[];
  record: BenchmarkRecord;
};

const ARCH: Record<Sku, string> = { "H100-80G": "hopper", "A100-80G": "ampere", "L40S-48G": "ada" };
const ARCH_ORDER = ["ada", "ampere", "hopper"];
const PREC_CLASS: Record<string, string> = { fp16: "16", bf16: "16", fp8: "8", int8: "8", int4: "4" };

type ScoreRes = { score: number; reason: string; hard?: boolean };

function daysBetween(a: string, b: string) {
  return (new Date(b).getTime() - new Date(a).getTime()) / 86400000;
}

function scoreRuntime(d: Demand, r: BenchmarkRecord): ScoreRes {
  if (d.runtime.engine !== r.runtime.engine) return { score: 0.4, reason: "different engine family" };
  const dv = String(d.runtime.version).split(".").map(Number);
  const rv = String(r.runtime.version).split(".").map(Number);
  if (dv[0] !== rv[0]) return { score: 0.65, reason: `${r.runtime.engine} ${r.runtime.version} → ${d.runtime.version} (major)` };
  if (dv[1] === rv[1]) return { score: 1.0, reason: "—" };
  return { score: 0.85, reason: `${r.runtime.engine} ${r.runtime.version} → ${d.runtime.version} (minor)` };
}

function scoreHardware(d: Demand, r: BenchmarkRecord): ScoreRes {
  const sameSku = d.hardware.sku === r.hardware.sku;
  if (sameSku && d.hardware.tp === r.hardware.tp) return { score: 1.0, reason: "—" };
  if (sameSku) return { score: 0.75, reason: `same SKU, TP${r.hardware.tp}→TP${d.hardware.tp}` };
  const hops = Math.abs(ARCH_ORDER.indexOf(ARCH[d.hardware.sku]) - ARCH_ORDER.indexOf(ARCH[r.hardware.sku]));
  return { score: hops >= 2 ? 0.25 : 0.45, reason: `${ARCH[r.hardware.sku]}→${ARCH[d.hardware.sku]} ${hops} arch hop(s); TP${r.hardware.tp}→TP${d.hardware.tp}` };
}

function scorePrecision(d: Demand, r: BenchmarkRecord): ScoreRes {
  if (!PREC_CLASS[r.precision]) return { score: 0.4, reason: "unknown quant method" };
  if (d.precision === r.precision) return { score: 1.0, reason: "—" };
  if (PREC_CLASS[d.precision] === PREC_CLASS[r.precision]) return { score: 0.95, reason: `${r.precision} ↔ ${d.precision} (same class)` };
  return { score: 0.6, reason: `${r.precision} → ${d.precision} (diff class)` };
}

function scoreTraffic(d: Demand, r: BenchmarkRecord): ScoreRes {
  if (d.traffic.streaming !== r.traffic.streaming) return { score: 0.55, reason: "streaming mismatch" };
  const sameBucket = d.traffic.in_bucket === r.traffic.in_bucket && d.traffic.out_bucket === r.traffic.out_bucket;
  const ratio = Math.max(d.traffic.concurrency, r.traffic.concurrency) / Math.min(d.traffic.concurrency, r.traffic.concurrency);
  if (sameBucket && ratio < 1.5) return { score: 1.0, reason: "—" };
  if (ratio >= 2) return { score: 0.7, reason: `conc ${r.traffic.concurrency}→${d.traffic.concurrency} (2× gap)` };
  return { score: 0.8, reason: `adjacent I/O bucket; conc ${r.traffic.concurrency}→${d.traffic.concurrency}` };
}

function scoreFreshness(r: BenchmarkRecord, asOf: string): ScoreRes {
  const age = daysBetween(r.measured_at, asOf);
  const max = POLICY.match.freshness_max_days;
  if (age > max) return { score: 0, reason: `${Math.round(age)}d > ${max}d max (hard gate)`, hard: true };
  return { score: 1.0 - 0.5 * (age / max), reason: `${Math.round(age)}d of ${max}d max` };
}

export function scoreRecord(demand: Demand, record: BenchmarkRecord, asOf: string): Match {
  const w = POLICY.match.weights;
  const identity: ScoreRes = demand.model_id === record.model_id
    ? { score: 1.0, reason: "—" }
    : { score: 0, reason: "different model", hard: true };
  const dims = [
    { name: "model_identity", weight: w.model_identity, r: identity },
    { name: "runtime", weight: w.runtime, r: scoreRuntime(demand, record) },
    { name: "hardware", weight: w.hardware, r: scoreHardware(demand, record) },
    { name: "precision", weight: w.precision, r: scorePrecision(demand, record) },
    { name: "traffic", weight: w.traffic, r: scoreTraffic(demand, record) },
    { name: "freshness", weight: w.freshness, r: scoreFreshness(record, asOf) },
  ];
  const gated = dims.some((d) => d.r.hard);
  const score = gated ? 0 : dims.reduce((acc, d) => acc * Math.pow(d.r.score, d.weight), 1);
  const band: Match["band"] = gated || score < POLICY.match.bands.usable
    ? "unusable"
    : score >= POLICY.match.bands.direct
      ? "direct"
      : "derate";
  return {
    record_id: record.id,
    score,
    band,
    usable: band !== "unusable",
    dimensions: dims.map((d) => ({ name: d.name, weight: d.weight, score: d.r.score, reason: d.r.reason })),
    record,
  };
}

export function rankMatches(demand: Demand, asOf: string): Match[] {
  return REGISTRY.filter((r) => r.model_id === demand.model_id)
    .map((r) => scoreRecord(demand, r, asOf))
    .sort((a, b) => (a.usable === b.usable ? b.score - a.score : a.usable ? -1 : 1));
}

// ── Sizing ──────────────────────────────────────────────────────────────────

export type SizingStep = { label: string; expr: string; value: number };
export type SizingResult = {
  steps: SizingStep[];
  demand_output_tps: number;
  safe_output_tps_per_replica: number;
  replicas_throughput: number;
  replicas_concurrency: number;
  required_replicas: number;
  required_gpus: number;
  required_gpus_alloc: number;
  shortfall_gpus: number;
};

export function computeSizing(demand: Demand, match: Match): SizingResult {
  const r = match.record;
  const sku = SKUS[r.hardware.sku];
  const benchmark_output_tps = r.output_tps_per_replica;
  const benchmark_match_factor = match.score;
  const target_utilization = POLICY.target_utilization;
  const demand_output_tps = demand.peak_rps * demand.avg_output_tokens;
  const safe_output_tps_per_replica = benchmark_output_tps * benchmark_match_factor * target_utilization;
  const replicas_throughput = Math.ceil(demand_output_tps / safe_output_tps_per_replica);
  const replicas_concurrency = Math.ceil(demand.peak_concurrency / r.max_concurrency_per_replica);
  const required_replicas = Math.max(replicas_throughput, replicas_concurrency, POLICY.minimum_HA_replicas);
  const required_gpus = required_replicas * r.gpus_per_replica;
  const required_gpus_alloc = ceilToQuantum(required_gpus, sku.granularity);
  const shortfall_gpus = Math.max(
    0,
    required_gpus + POLICY.reserve_gpus - demand.usable_existing_gpus - demand.approved_reclaimable_gpus,
  );
  const steps: SizingStep[] = [
    { label: "demand_output_tps", expr: `${demand.peak_rps} rps × ${demand.avg_output_tokens} tok`, value: demand_output_tps },
    { label: "safe_output_tps_per_replica", expr: `${benchmark_output_tps} × ${round2(benchmark_match_factor)} match × ${target_utilization} util`, value: safe_output_tps_per_replica },
    { label: "replicas_throughput", expr: `ceil(${demand_output_tps} / ${safe_output_tps_per_replica.toFixed(1)})`, value: replicas_throughput },
    { label: "replicas_concurrency", expr: `ceil(${demand.peak_concurrency} / ${r.max_concurrency_per_replica})`, value: replicas_concurrency },
    { label: "required_replicas", expr: `max(${replicas_throughput}, ${replicas_concurrency}, ${POLICY.minimum_HA_replicas} HA)`, value: required_replicas },
    { label: "required_gpus", expr: `${required_replicas} × ${r.gpus_per_replica.toFixed(3)} GPU/replica`, value: required_gpus },
    { label: "required_gpus_alloc", expr: `ceil_to_quantum(${required_gpus.toFixed(3)}, ${sku.granularity.toFixed(3)})`, value: required_gpus_alloc },
    { label: "shortfall_gpus", expr: `max(0, ${required_gpus.toFixed(3)} − ${demand.usable_existing_gpus.toFixed(3)} existing − ${demand.approved_reclaimable_gpus} reclaim)`, value: shortfall_gpus },
  ];
  return { steps, demand_output_tps, safe_output_tps_per_replica, replicas_throughput, replicas_concurrency, required_replicas, required_gpus, required_gpus_alloc, shortfall_gpus };
}

// ── Ladder ──────────────────────────────────────────────────────────────────

const HOURS_PER_MONTH = 730;

export type LadderVerdict = "met" | "blocked" | "eligible" | "na";
export type LadderRung = {
  rank: number;
  option: string;
  verdict: LadderVerdict;
  reason: string;
  sourced: number;
  cost_monthly?: number;
  capex?: number;
  lead_time_days?: number;
  pool_id?: string;
};
export type LadderResult = {
  rungs: LadderRung[];
  recommended_rank: number;
  state: "available" | "scale_model" | "rebalance" | "activate" | "order_infra" | "manual_review";
};

const STATE_BY_RANK: Record<number, LadderResult["state"]> = {
  1: "available", 2: "scale_model", 3: "rebalance", 4: "activate", 5: "order_infra", 6: "manual_review",
};

function canHost(p: Pool, gpr: number) {
  return !p.maintenance && p.largest_contiguous >= gpr - 1e-9;
}

function pickPool(gpr: number, shortfall: number, want: "reserved" | "non-reserved"): Pool | undefined {
  return FLEET.pools
    .filter((p) => (want === "reserved" ? !!p.reserved : !p.reserved))
    .filter((p) => canHost(p, gpr) && p.free_gpus >= shortfall - 1e-9)
    .sort((a, b) => (b.largest_contiguous - a.largest_contiguous) || (SKUS[a.sku].cost_per_gpu_hour - SKUS[b.sku].cost_per_gpu_hour))[0];
}

const cost = (sourced: number, sku: Sku) => round2(sourced * SKUS[sku].cost_per_gpu_hour * HOURS_PER_MONTH);

export function evaluateLadder(sizing: SizingResult, gpr: number, home_pool_id: string): LadderResult {
  const rungs: LadderRung[] = [];
  let recommended: number | null = null;
  const s = sizing.shortfall_gpus;

  if (s <= 1e-9) {
    rungs.push({ rank: 1, option: "Fits in live headroom", verdict: "met", reason: "no shortfall", sourced: 0 });
    recommended = 1;
  } else {
    rungs.push({ rank: 1, option: "Fits in live headroom", verdict: "blocked", reason: `shortfall ${round2(s)} GPU`, sourced: 0 });
  }

  const home = FLEET.pools.find((p) => p.id === home_pool_id);
  if (recommended === null) {
    if (home?.maintenance) {
      rungs.push({ rank: 2, option: "Scale existing deployment", verdict: "blocked", reason: `pool ${home.id} maintenance freeze until ${home.maintenance.until}`, sourced: 0 });
    } else if (home && canHost(home, gpr) && home.free_gpus >= s - 1e-9) {
      rungs.push({ rank: 2, option: "Scale existing deployment", verdict: "met", reason: `${home.id}, ${home.sku}`, sourced: round2(s), cost_monthly: cost(s, home.sku), pool_id: home.id });
      recommended = 2;
    } else {
      rungs.push({ rank: 2, option: "Scale existing deployment", verdict: "blocked", reason: "existing deployment cannot absorb shortfall", sourced: 0 });
    }
  } else {
    rungs.push({ rank: 2, option: "Scale existing deployment", verdict: "na", reason: "not needed", sourced: 0 });
  }

  if (recommended === null) {
    const p = pickPool(gpr, s, "non-reserved");
    if (p) {
      rungs.push({ rank: 3, option: "Rebalance across pools", verdict: "met", reason: `${p.id}, ${p.sku}`, sourced: round2(s), cost_monthly: cost(s, p.sku), pool_id: p.id });
      recommended = 3;
    } else {
      rungs.push({ rank: 3, option: "Rebalance across pools", verdict: "blocked", reason: "no non-reserved pool has a large enough contiguous block", sourced: 0 });
    }
  } else {
    rungs.push({ rank: 3, option: "Rebalance across pools", verdict: recommended < 3 ? "na" : "eligible", reason: "", sourced: 0 });
  }

  const reserved = pickPool(gpr, s, "reserved");
  if (recommended === null && reserved) {
    rungs.push({ rank: 4, option: "Activate reserved capacity", verdict: "met", reason: `${reserved.id}, ${reserved.sku}`, sourced: round2(s), cost_monthly: cost(s, reserved.sku), pool_id: reserved.id });
    recommended = 4;
  } else if (reserved) {
    rungs.push({ rank: 4, option: "Activate reserved capacity", verdict: "eligible", reason: `${reserved.id}, ${reserved.sku}`, sourced: round2(s), cost_monthly: cost(s, reserved.sku), pool_id: reserved.id });
  } else {
    rungs.push({ rank: 4, option: "Activate reserved capacity", verdict: "na", reason: "no reserved pool can host", sourced: 0 });
  }

  const whole = Math.max(0, Math.ceil(s - 1e-9));
  const lead = POLICY.lead_time_days.order + POLICY.lead_time_days.delivery + POLICY.lead_time_days.rack + POLICY.lead_time_days.network;
  const orderVerdict: LadderVerdict = recommended === null ? "met" : "eligible";
  if (recommended === null && whole > 0) recommended = 5;
  rungs.push({ rank: 5, option: "Order infrastructure", verdict: orderVerdict, reason: `${lead}d lead, whole nodes only`, sourced: whole, capex: whole * SKUS["H100-80G"].capex, lead_time_days: lead });

  if (recommended === null) {
    rungs.push({ rank: 6, option: "Manual review", verdict: "met", reason: "no option satisfies the shortfall", sourced: 0 });
    recommended = 6;
  } else {
    rungs.push({ rank: 6, option: "Manual review", verdict: "na", reason: "not required", sourced: 0 });
  }

  return { rungs, recommended_rank: recommended, state: STATE_BY_RANK[recommended] };
}

// ── Candidacy sweep (for UI) ────────────────────────────────────────────────

export type PoolVerdict = {
  pool: string;
  sku: Sku;
  freeGpus: number;
  largestContiguous: number;
  verdict: "eligible" | "blocked" | "chosen";
  reason: string;
  costMonthly?: number;
};

export function sweepCandidacy(gpr: number, shortfall: number, chosenPoolId: string | undefined): PoolVerdict[] {
  return FLEET.pools.map((p) => {
    if (p.reserved) {
      return {
        pool: p.id, sku: p.sku, freeGpus: p.free_gpus, largestContiguous: p.largest_contiguous,
        verdict: p.id === chosenPoolId ? "chosen" : "eligible",
        reason: `reserved · ${p.reserved.note}`,
      };
    }
    if (p.maintenance) {
      return {
        pool: p.id, sku: p.sku, freeGpus: p.free_gpus, largestContiguous: p.largest_contiguous,
        verdict: "blocked",
        reason: `maintenance freeze until ${p.maintenance.until}`,
      };
    }
    if (p.largest_contiguous < gpr - 1e-9) {
      const slices = Math.round(p.free_gpus / p.largest_contiguous);
      return {
        pool: p.id, sku: p.sku, freeGpus: p.free_gpus, largestContiguous: p.largest_contiguous,
        verdict: "blocked",
        reason: `largest contiguous ${round2(p.largest_contiguous)} < ${round2(gpr)} GPU/replica — fragmented across ${slices} slices`,
      };
    }
    if (p.free_gpus < shortfall - 1e-9) {
      return {
        pool: p.id, sku: p.sku, freeGpus: p.free_gpus, largestContiguous: p.largest_contiguous,
        verdict: "blocked",
        reason: `${round2(p.free_gpus)} free < ${round2(shortfall)} shortfall`,
      };
    }
    return {
      pool: p.id, sku: p.sku, freeGpus: p.free_gpus, largestContiguous: p.largest_contiguous,
      verdict: p.id === chosenPoolId ? "chosen" : "eligible",
      reason: p.id === chosenPoolId ? `contiguous block covers shortfall` : "eligible",
      costMonthly: p.id === chosenPoolId ? cost(shortfall, p.sku) : undefined,
    };
  });
}