import type { ForecastSeries } from "./scenarios";

export type WhatIfParams = {
  growthPct: number; // -20..100, percent change applied to day-over-day growth
  spike: boolean; // inject a +40% bump for a 14-day window starting day 30
  poolDeltaGpus: number; // shifts policyLine by this many GPU-equivalent units
};

export const DEFAULT_WHATIF: WhatIfParams = { growthPct: 0, spike: false, poolDeltaGpus: 0 };

const SPIKE_START_DAY = 30;
const SPIKE_LEN_DAYS = 14;
const SPIKE_FACTOR = 1.4;

function scaleSeries(series: number[], growthPct: number, spike: boolean): number[] {
  const growthFactor = 1 + growthPct / 100;
  return series.map((v, day) => {
    let out = v * (1 + (growthFactor - 1) * (day / (series.length - 1 || 1)));
    if (spike && day >= SPIKE_START_DAY && day < SPIKE_START_DAY + SPIKE_LEN_DAYS) {
      out *= SPIKE_FACTOR;
    }
    return Math.round(out * 100) / 100;
  });
}

export function applyWhatIf(forecast: ForecastSeries, params: WhatIfParams): ForecastSeries {
  const baseline = scaleSeries(forecast.baseline, params.growthPct, params.spike);
  const p10 = scaleSeries(forecast.p10, params.growthPct, params.spike);
  const p90 = scaleSeries(forecast.p90, params.growthPct, params.spike);
  const policyLine = Math.max(0, forecast.policyLine + params.poolDeltaGpus);
  const breachDay = (() => {
    const idx = baseline.findIndex((v) => v >= policyLine);
    return idx >= 0 ? idx : null;
  })();
  return { ...forecast, baseline, p10, p90, policyLine, breachDay };
}
