// Mock data for the GPU Forecasting prototype. All numbers are illustrative.

export type PersonaId =
  | "requester"
  | "capacity_manager"
  | "sre"
  | "infra_planner"
  | "perf_engineer";

export const PERSONAS: {
  id: PersonaId;
  label: string;
  short: string;
  landing: string;
  owns: string[];
}[] = [
  { id: "requester", label: "Application Requester", short: "REQ", landing: "/intake", owns: ["submit", "revise"] },
  { id: "capacity_manager", label: "GPU Capacity Manager", short: "CAP", landing: "/inbox", owns: ["approve", "reject", "request_revision"] },
  { id: "sre", label: "Model Platform SRE", short: "SRE", landing: "/capacity", owns: ["confirm_maintenance", "flag_stale_telemetry"] },
  { id: "infra_planner", label: "Infra Planner", short: "PLN", landing: "/forecast", owns: ["trigger_procurement", "set_target_utilization", "ack_derated"] },
  { id: "perf_engineer", label: "Model Performance Engineer", short: "PRF", landing: "/registry", owns: ["attach_benchmark", "override_benchmark", "dispute_sizing"] },
];

export type RecordState = "awaiting_input" | "awaiting_approval" | "approved" | "rejected" | "revision_requested";
export type RecommendationState = "green" | "amber" | "red" | "manual_review" | "insufficient_evidence" | "derated";

export type Assessment = {
  id: string;
  useCase: string;
  model: string;
  requester: string;
  recordState: RecordState;
  recState: RecommendationState;
  headroomDelta: number;
  ageHours: number;
  provRef?: string;
};

export const ASSESSMENTS: Assessment[] = [
  { id: "ASM-08-AXL-99", useCase: "Support triage assistant", model: "mistral-7b", requester: "sarah.k@acme", recordState: "awaiting_approval", recState: "amber", headroomDelta: -1.714, ageHours: 3, provRef: "PROV-8821" },
  { id: "ASM-08-BQR-14", useCase: "Semantic doc search", model: "meta-llama-3.1-8b", requester: "d.chen@acme", recordState: "awaiting_input", recState: "insufficient_evidence", headroomDelta: 0, ageHours: 6, provRef: "PROV-8834" },
  { id: "ASM-08-CMN-02", useCase: "Contract summarization", model: "gemma-3-27b", requester: "legal@acme", recordState: "awaiting_approval", recState: "red", headroomDelta: -6.0, ageHours: 11, provRef: "PROV-8802" },
  { id: "ASM-07-ZTL-88", useCase: "Retail product tagging", model: "clip-vit-l/14", requester: "cv-team@acme", recordState: "approved", recState: "green", headroomDelta: 4.2, ageHours: 28 },
  { id: "ASM-07-YFR-01", useCase: "Voice transcription", model: "whisper-large-v3", requester: "media@acme", recordState: "revision_requested", recState: "manual_review", headroomDelta: -0.3, ageHours: 44 },
  { id: "ASM-07-XBP-55", useCase: "Fraud scoring", model: "xgb-onnx-fraud-v9", requester: "risk@acme", recordState: "approved", recState: "derated", headroomDelta: 1.1, ageHours: 72 },
  { id: "ASM-07-WMV-19", useCase: "Marketing rewrite", model: "gpt-oss-20b", requester: "growth@acme", recordState: "rejected", recState: "red", headroomDelta: -12.0, ageHours: 96 },
];

export type PoolInventory = {
  id: string;
  region: string;
  dataCenter: string;
  cluster: string;
  source: string;
  gpu: string;
  total: number;
  allocated: number;
  live: number;
  maintenance?: string;
};

export const POOLS: PoolInventory[] = [
  { id: "pool-A", region: "dc-nam", dataCenter: "Rutherford (RUTDC)", cluster: "namrut20p", source: "prd-nam", gpu: "NVIDIA H200", total: 56, allocated: 48, live: 41, maintenance: "freeze until Aug 14" },
  { id: "pool-B", region: "dc-nam", dataCenter: "New York/NJ (NJDC)", cluster: "namnjd105d", source: "dev-nam", gpu: "NVIDIA H200", total: 56, allocated: 52, live: 49 },
  { id: "pool-C", region: "dc-nam", dataCenter: "Southwest (SWDC)", cluster: "namswd23p", source: "prd-nam", gpu: "NVIDIA A100 80GB", total: 80, allocated: 62, live: 55 },
  { id: "pool-D", region: "dc-emea", dataCenter: "Midwest (MWDC)", cluster: "nammwd002d", source: "dev-nam", gpu: "NVIDIA A100 80GB", total: 40, allocated: 22, live: 18 },
  { id: "pool-E", region: "dc-apac", dataCenter: "New York/NJ (NJDC)", cluster: "namnjd106p", source: "prd-nam", gpu: "Tesla V100S", total: 24, allocated: 14, live: 12 },
  { id: "pool-F", region: "dc-latam", dataCenter: "Georgetown (GTDC)", cluster: "namgtd001d", source: "dev-nam", gpu: "NVIDIA H200", total: 56, allocated: 30, live: 26 },
  { id: "pool-G", region: "dc-nam", dataCenter: "Southwest (SWDC)", cluster: "namswd24p", source: "prd-nam", gpu: "NVIDIA H200", total: 24, allocated: 0, live: 0 },
];

export type LadderRow = {
  step: number;
  strategy: string;
  sourced: string;
  deltaCost: number | null;
  verdict: "insufficient" | "blocked" | "recommended" | "secondary" | "ack_required" | "not_required";
  detail: string;
};

export const LADDER: LadderRow[] = [
  { step: 1, strategy: "Fits in live headroom", sourced: "—", deltaCost: null, verdict: "insufficient", detail: "shortfall 1.714 GPUs" },
  { step: 2, strategy: "Scale existing deployment", sourced: "pool A maintenance", deltaCost: null, verdict: "blocked", detail: "freeze until Aug 14" },
  { step: 3, strategy: "Rebalance across pools", sourced: "pool C, A100", deltaCost: 1752, verdict: "recommended", detail: "1.714 GPU × $1.40/h × 730h" },
  { step: 4, strategy: "Activate reserved capacity", sourced: "pool G, H100", deltaCost: 4005, verdict: "secondary", detail: "reserved contract, higher rate" },
  { step: 5, strategy: "Order infrastructure", sourced: "74d lead, whole nodes only", deltaCost: 60000, verdict: "ack_required", detail: "$60,000 capex; derated: node-only quantum" },
  { step: 6, strategy: "Manual review", sourced: "—", deltaCost: null, verdict: "not_required", detail: "recommendation available upstream" },
];

export const SIZING = {
  model: "mistral-7b",
  replicas: 30,
  gpuPerReplica: 0.286,
  quantum: "H100 MIG 2/7",
  requiredGpus: 60 / 7,
  usableExisting: 48 / 7,
  reserve: 0,
  shortfall: 12 / 7,
};

export type ForecastPoint = { day: number; date: string; baseline: number; lower: number; upper: number; planned?: number };

export const FORECAST: ForecastPoint[] = (() => {
  const out: ForecastPoint[] = [];
  const start = new Date("2026-07-27");
  for (let d = 0; d <= 180; d += 3) {
    const t = d / 180;
    const growth = 6.2 + 3.4 * t + 0.5 * Math.sin(d / 12);
    const noise = 0.4 * Math.cos(d / 7);
    const baseline = +(growth + noise).toFixed(3);
    const band = 0.6 + 1.2 * t;
    const date = new Date(start.getTime() + d * 86400000).toISOString().slice(0, 10);
    const planned = d >= 60 && d <= 120 ? baseline + 1.8 : undefined;
    out.push({ day: d, date, baseline, lower: +(baseline - band).toFixed(3), upper: +(baseline + band).toFixed(3), planned });
  }
  return out;
})();

export type BenchmarkRow = {
  id: string;
  model: string;
  hardware: string;
  quant: string;
  seqLen: number;
  concurrency: number;
  tokensPerSec: number;
  match: number;
  dims: { model: number; hardware: number; quant: number; seqLen: number; concurrency: number; runtime: number };
  version: string;
  asOf: string;
  reasons: string[];
};

export const BENCHMARKS: BenchmarkRow[] = [
  {
    id: "bench-2451",
    model: "mistral-7b",
    hardware: "H100 MIG 2/7",
    quant: "fp8",
    seqLen: 4096,
    concurrency: 32,
    tokensPerSec: 4820,
    match: 0.94,
    dims: { model: 1, hardware: 1, quant: 0.9, seqLen: 1, concurrency: 0.8, runtime: 1 },
    version: "vLLM 0.7.3",
    asOf: "2026-07-19T02:14Z",
    reasons: ["quantization uses fp8 vs requested bf16 (score 0.9)"],
  },
  {
    id: "bench-2109",
    model: "meta-llama-3.1-8b",
    hardware: "A100 80GB × 2",
    quant: "int8",
    seqLen: 8192,
    concurrency: 16,
    tokensPerSec: 1240,
    match: 0.71,
    dims: { model: 1, hardware: 0.6, quant: 0.7, seqLen: 1, concurrency: 0.5, runtime: 0.8 },
    version: "TensorRT-LLM 0.11",
    asOf: "2026-07-11T18:03Z",
    reasons: ["hardware differs (A100 vs requested H100)", "concurrency 16 vs requested 40"],
  },
  {
    id: "bench-1980",
    model: "gemma-3-27b",
    hardware: "H100 80GB × 2",
    quant: "bf16",
    seqLen: 4096,
    concurrency: 24,
    tokensPerSec: 2110,
    match: 0.42,
    dims: { model: 0.3, hardware: 1, quant: 1, seqLen: 1, concurrency: 0.6, runtime: 0.4 },
    version: "vLLM 0.6.9 (stale)",
    asOf: "2026-05-22T09:41Z",
    reasons: ["runtime version below usable threshold", "no MoE routing overhead measured"],
  },
];

export type EvidenceNode = {
  id: string;
  label: string;
  kind: "agent" | "engine" | "trigger" | "record";
  x: number;
  y: number;
  state: "done" | "running" | "pending" | "warn";
  toolCalls?: { name: string; asOf: string; ok: boolean; note?: string }[];
  output?: string;
};

export const NODES: EvidenceNode[] = [
  { id: "trigger", label: "Trigger", kind: "trigger", x: 40, y: 200, state: "done", output: "email → PROV-8821" },
  { id: "intake", label: "1. Intake", kind: "agent", x: 180, y: 200, state: "done", toolCalls: [{ name: "provisioning.fetch(PROV-8821)", asOf: "14:02:11", ok: true }], output: "9 fields captured, 2 assumed defaults" },
  { id: "review", label: "2. Input Review", kind: "agent", x: 320, y: 200, state: "done", toolCalls: [{ name: "hitl.notify", asOf: "14:02:44", ok: true, note: "amber fields confirmed" }], output: "demand_profile v1" },
  { id: "ev-bench", label: "benchmark match", kind: "agent", x: 480, y: 70, state: "done", toolCalls: [{ name: "registry.match(mistral-7b, H100 MIG 2/7)", asOf: "14:03:01", ok: true }], output: "bench-2451 · match 0.94" },
  { id: "ev-head", label: "live headroom", kind: "agent", x: 480, y: 130, state: "done", toolCalls: [{ name: "telemetry.headroom(pool-*, 5m)", asOf: "14:03:02", ok: true }], output: "6.857 GPU usable" },
  { id: "ev-util", label: "recent utilization", kind: "agent", x: 480, y: 190, state: "done", toolCalls: [{ name: "telemetry.utilization(7d)", asOf: "14:03:02", ok: true }], output: "p95 78%" },
  { id: "ev-inv", label: "pool inventory", kind: "agent", x: 480, y: 250, state: "done", toolCalls: [{ name: "inventory.snapshot", asOf: "14:03:04", ok: true }], output: "7 pools · 336 GPUs" },
  { id: "ev-maint", label: "maintenance state", kind: "agent", x: 480, y: 310, state: "warn", toolCalls: [{ name: "maintenance.windows", asOf: "14:03:05", ok: true, note: "pool A freeze until Aug 14" }], output: "1 pool frozen" },
  { id: "ev-scale", label: "scale candidates", kind: "agent", x: 480, y: 370, state: "done", toolCalls: [{ name: "candidates.scale", asOf: "14:03:07", ok: true }], output: "3 candidates found" },
  { id: "forecast", label: "4. Forecast", kind: "agent", x: 660, y: 200, state: "done", toolCalls: [{ name: "forecast.refresh(180d, mistral-7b)", asOf: "14:03:11", ok: true }], output: "p50 8.6 · p95 10.2" },
  { id: "engine", label: "5. Planning Engine v3.2", kind: "engine", x: 830, y: 200, state: "done", output: "recommended: rebalance (+$1,752/mo)" },
  { id: "explain", label: "6. Explain", kind: "agent", x: 990, y: 200, state: "done", output: "narrative + assumptions" },
  { id: "record", label: "7. Record", kind: "record", x: 1130, y: 200, state: "pending", output: "awaiting_approval" },
];

export const EDGES: [string, string][] = [
  ["trigger", "intake"],
  ["intake", "review"],
  ["review", "ev-bench"],
  ["review", "ev-head"],
  ["review", "ev-util"],
  ["review", "ev-inv"],
  ["review", "ev-maint"],
  ["review", "ev-scale"],
  ["ev-bench", "forecast"],
  ["ev-head", "forecast"],
  ["ev-util", "forecast"],
  ["ev-inv", "forecast"],
  ["ev-maint", "forecast"],
  ["ev-scale", "forecast"],
  ["forecast", "engine"],
  ["engine", "explain"],
  ["explain", "record"],
];

export const INTAKE_FIELDS = [
  { key: "model", label: "Model", value: "mistral-7b", source: "pulled from PROV-8821" },
  { key: "tokens_in", label: "Tokens / request (in)", value: "1,024", source: "you told me" },
  { key: "tokens_out", label: "Tokens / request (out)", value: "256", source: "you told me" },
  { key: "concurrency", label: "Peak concurrency", value: "40", source: "pulled from PROV-8821" },
  { key: "latency_slo", label: "Latency SLO (p95)", value: "1,200 ms", source: "you told me" },
  { key: "growth", label: "6-month growth", value: "20% / mo", source: "assumed default" },
  { key: "availability", label: "Availability target", value: "99.5%", source: "assumed default" },
  { key: "quant", label: "Quantization", value: "fp8", source: "pulled from PROV-8821" },
  { key: "region", label: "Preferred region", value: "us-east-1", source: "pulled from PROV-8821" },
] as const;

export type PipelineRow = {
  projectId: string;
  projectName: string;
  csiAppName: string;
  ptsUseCase: string;
  businessSponsor: string;
  sdlc: "UAT" | "PROD" | "COB";
  modelName: string;
  region: string;
  contextSize: string;
  avgInputTokens: number;
  totalUsers: number;
  requestsPerDay: number;
  maxTokens: number;
  avgQps: number;
  maxQps: number;
};

export const PIPELINE: PipelineRow[] = [
  {
    projectId: "5038",
    projectName: "Wholesale Credit Risk Reporting",
    csiAppName: "EntRisk Credit",
    ptsUseCase: "DC028282328",
    businessSponsor: "LK383333",
    sdlc: "PROD",
    modelName: "Stellar AI (Meta-Llama-3.3-70B)",
    region: "DC",
    contextSize: "< 128K",
    avgInputTokens: 2048,
    totalUsers: 340,
    requestsPerDay: 18500,
    maxTokens: 4096,
    avgQps: 4.2,
    maxQps: 22,
  },
];

export const CHAT: { role: "assistant" | "user"; text: string }[] = [
  { role: "assistant", text: "I pulled the request from PROV-8821. I have model, region, quantization, and concurrency. I still need tokens per request and latency SLO." },
  { role: "user", text: "1024 in, 256 out. p95 latency budget is 1200ms." },
  { role: "assistant", text: "Got it. I'm assuming 20% monthly growth and a 99.5% availability target unless you say otherwise. Those two remain amber until confirmed." },
  { role: "user", text: "Confirm both." },
  { role: "assistant", text: "Confirmed. Kicking off evidence gathering." },
];
