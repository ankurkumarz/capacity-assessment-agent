# PUMA Showcase Demo Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Turn CORE_COMPUTE into a demo that shows PUMA event intake → GPU/Tokens-per-sec impact → 3-bucket recommendation decision → what-if forecast → scripted conversational Q&A → real-time capacity view, with a plain-language "requester" persona view and a light/dark theme toggle.

**Architecture:** Everything is derived from the existing `src/lib/engine.ts` + `src/lib/scenarios.ts` data. No backend/API routes, no real Grafana/PUMA/OpenShift calls, no real LLM. New fields are added to the `Scenario` type and computed once in `buildScenario()`; pages read those fields. A new `applyWhatIf` pure function transforms an existing `ForecastSeries`. A new scripted-QA data file backs a shared chat drawer component. Theme is a third context value on the existing `AppShell` context, backed by a CSS class + localStorage exactly like `persona`/`scenarioId`.

**Tech Stack:** React 19, TanStack Start/Router, Tailwind v4 (oklch tokens), Recharts, Radix/shadcn `ui/*` primitives (Sheet, Collapsible, Slider, Switch, Badge), TypeScript, Vite, Bun.

## Global Constraints

- No real external tool calls (Grafana/PUMA/OpenShift) — badges/labels only.
- No live LLM — chat answers are scripted/keyword-matched from local data.
- No new backend routes; all data is client-side and derived from `src/lib/scenarios.ts` / `src/lib/engine.ts`.
- Follow existing code style: function components, no comments unless non-obvious, Tailwind utility classes matching current oklch token names (`bg-panel`, `text-text-dim`, `border-border`, `text-ok`/`text-warn`/`text-bad`, `font-mono` for data).
- Reuse existing `components/ui/*` primitives; do not add new UI libraries.
- Keep `SCENARIOS`/`buildScenario()` in `src/lib/scenarios.ts` as the single source of truth — no duplicate hardcoded numbers in route files.

---

## File Structure

- Modify `src/lib/scenarios.ts` — add `pumaEvent`, `decisionBucket`, `gpuImpact`, `tokensSecImpact` to `Scenario`, computed in `buildScenario()`.
- Create `src/lib/whatif.ts` — `applyWhatIf()` pure transform of `ForecastSeries`.
- Create `src/lib/chat-script.ts` — `buildQaScript()` + keyword matcher.
- Create `src/components/ChatDrawer.tsx` — shared chat Sheet, used by Run Detail / Forecast / Capacity.
- Create `src/components/ExecutiveSummaryCard.tsx` — plain-language card for the requester persona.
- Create `src/components/DecisionBanner.tsx` — 3-bucket decision banner + GPU/Tokens impact tiles, used by Run Detail.
- Create `src/components/ToolBadge.tsx` — small badge renderer for `"grafana" | "puma" | "openshift"`.
- Modify `src/components/AppShell.tsx` — add `theme` to context (localStorage-backed), theme toggle button in sidebar footer.
- Modify `src/styles.css` — replace mismatched `.dark {}` block with a real light palette under `:root`, move current dark cyber-industrial palette into `.dark {}`.
- Modify `src/routes/intake.tsx` — PUMA event banner, tool badges on fields, remove dead chat input, executive view.
- Modify `src/routes/run.$id.tsx` — insert `DecisionBanner`, tool badges on evidence, `ChatDrawer` trigger, executive view.
- Modify `src/routes/forecast.tsx` — what-if controls, GPU/Tokens metric toggle, `ChatDrawer` trigger, executive view.
- Modify `src/routes/capacity.tsx` — `ChatDrawer` trigger, executive view (collapsible technical detail).

---

### Task 1: Scenario data model — PUMA event, decision bucket, GPU/Tokens impact

**Files:**
- Modify: `src/lib/scenarios.ts`

**Interfaces:**
- Produces: `Scenario.pumaEvent: { eventId: string; receivedAt: string; tools: ("grafana"|"puma"|"openshift")[] }`
- Produces: `Scenario.decisionBucket: "absorb" | "provision" | "rebalance"`
- Produces: `Scenario.gpuImpact: { deltaGpus: number; label: string }`
- Produces: `Scenario.tokensSecImpact: { tokensPerSec: number; label: string }`
- Consumes: existing `Sizing.shortfallGpus`, `Sizing.peakRps`, `Sizing.outTokens`, ladder `state` (via existing `LABEL_BY_STATE`/`TONE_BY_STATE` keys — the raw engine `state` string, not the human label)

Note: `buildScenario()` currently only keeps `ladder.state` transiently (used to compute `recStateLabel`/`tone`); it must be threaded through to compute `decisionBucket` too.

- [ ] **Step 1: Add types**

In `src/lib/scenarios.ts`, add near the other type exports (after the `Sizing` type, ~line 83):

```ts
export type PumaTool = "grafana" | "puma" | "openshift";

export type PumaEvent = {
  eventId: string;
  receivedAt: string;
  tools: PumaTool[];
};

export type DecisionBucket = "absorb" | "provision" | "rebalance";

export type GpuImpact = { deltaGpus: number; label: string };
export type TokensSecImpact = { tokensPerSec: number; label: string };
```

Add to the `Scenario` type (after `guardrail`, before `hitl`, ~line 110):

```ts
  pumaEvent: PumaEvent;
  decisionBucket: DecisionBucket;
  gpuImpact: GpuImpact;
  tokensSecImpact: TokensSecImpact;
```

- [ ] **Step 2: Add `pumaEvent` to each `ScenarioConfig`**

Add `pumaEvent: PumaEvent` to the `ScenarioConfig` type (after `record`, ~line 127):

```ts
  pumaEvent: PumaEvent;
```

Add a `pumaEvent` entry to each of the 3 configs in `CONFIGS`. For `s1-available` (~line 148, after `record: {...}`):

```ts
    pumaEvent: { eventId: "PUMA-EVT-88214", receivedAt: "2026-07-23T13:55:00Z", tools: ["puma", "grafana"] },
```

For `s3-rebalance` (~line 179, after `record: {...}`):

```ts
    pumaEvent: { eventId: "PUMA-EVT-88229", receivedAt: "2026-07-23T13:56:00Z", tools: ["grafana", "openshift"] },
```

For `s5-procure` (~line 206, after `record: {...}`):

```ts
    pumaEvent: { eventId: "PUMA-EVT-88251", receivedAt: "2026-07-23T13:57:00Z", tools: ["puma", "openshift", "grafana"] },
```

- [ ] **Step 3: Add bucket mapping + impact derivation helpers**

Add below the existing `LABEL_BY_STATE` map (~line 248):

```ts
const BUCKET_BY_STATE: Record<string, DecisionBucket> = {
  available: "absorb",
  scale_model: "rebalance",
  rebalance: "rebalance",
  activate: "rebalance",
  order_infra: "provision",
  manual_review: "provision",
};

function deriveGpuImpact(shortfallGpus: number): GpuImpact {
  if (shortfallGpus <= 0) {
    return { deltaGpus: 0, label: "Absorbed in existing headroom" };
  }
  return { deltaGpus: shortfallGpus, label: `+${shortfallGpus.toFixed(3)} GPU needed` };
}

function deriveTokensSecImpact(peakRps: number, outTokens: number): TokensSecImpact {
  const tokensPerSec = Math.round(peakRps * outTokens);
  return { tokensPerSec, label: `${tokensPerSec.toLocaleString()} tok/s at peak` };
}
```

- [ ] **Step 4: Wire into `buildScenario()`**

In `buildScenario()` (~line 320-384), the `ladder.state` (engine state, e.g. `"available"`) is already computed as a local before being converted to `recStateLabel`/`tone`. Add right after the `tone`/`confidence` computation (~line 333, before the `hash` computation):

```ts
  const decisionBucket = BUCKET_BY_STATE[ladder.state];
  const gpuImpact = deriveGpuImpact(sizing.shortfall_gpus);
  const tokensSecImpact = deriveTokensSecImpact(cfg.demand.peak_rps, cfg.demand.avg_output_tokens);
```

Then add to the returned object (after `guardrail: cfg.guardrail,` ~line 351):

```ts
    pumaEvent: cfg.pumaEvent,
    decisionBucket,
    gpuImpact,
    tokensSecImpact,
```

- [ ] **Step 5: Typecheck**

Run: `cd /Users/ankkumar/sandbox/github/gpu-guard && bunx tsc --noEmit`
Expected: no errors related to `scenarios.ts`. (Pre-existing unrelated errors, if any, are out of scope — only confirm no NEW errors reference `scenarios.ts`.)

- [ ] **Step 6: Commit**

```bash
git add src/lib/scenarios.ts
git commit -m "feat: add PUMA event, decision bucket, and GPU/tokens impact to scenario model"
```

---

### Task 2: What-if forecast transform

**Files:**
- Create: `src/lib/whatif.ts`

**Interfaces:**
- Consumes: `ForecastSeries` from `src/lib/scenarios.ts` (fields: `baseline: number[]`, `p10: number[]`, `p90: number[]`, `policyLine: number`, `leadTimeDays: number`, `quality`, `coverage`)
- Produces: `WhatIfParams = { growthPct: number; spike: boolean; poolDeltaGpus: number }` and `applyWhatIf(forecast: ForecastSeries, params: WhatIfParams): ForecastSeries`

- [ ] **Step 1: Write the file**

```ts
import type { ForecastSeries } from "./scenarios";

export type WhatIfParams = {
  growthPct: number; // -20..100, percent change applied to day-over-day growth
  spike: boolean; // inject a +40% bump for a 14-day window starting day 30
  poolDeltaGpus: number; // shifts policyLine by this many GPU-equivalent units
};

export const DEFAULT_WHATIF: WhatIfParams = { growthPct: 0, spike: false, poolDeltaGpus: 0 };

const SPIKE_START_DAY = 30;
const SPIKE_LEN_DAYS = 14;
const SPIKE_FACTOR = 1.4;

function scaleSeries(series: number[], growthPct: number, spike: boolean): number[] {
  const growthFactor = 1 + growthPct / 100;
  return series.map((v, day) => {
    let out = v * (1 + (growthFactor - 1) * (day / (series.length - 1 || 1)));
    if (spike && day >= SPIKE_START_DAY && day < SPIKE_START_DAY + SPIKE_LEN_DAYS) {
      out *= SPIKE_FACTOR;
    }
    return Math.round(out * 100) / 100;
  });
}

export function applyWhatIf(forecast: ForecastSeries, params: WhatIfParams): ForecastSeries {
  const baseline = scaleSeries(forecast.baseline, params.growthPct, params.spike);
  const p10 = scaleSeries(forecast.p10, params.growthPct, params.spike);
  const p90 = scaleSeries(forecast.p90, params.growthPct, params.spike);
  const policyLine = Math.max(0, forecast.policyLine + params.poolDeltaGpus);
  const breachDay = (() => {
    const idx = baseline.findIndex((v) => v >= policyLine);
    return idx >= 0 ? idx : null;
  })();
  return { ...forecast, baseline, p10, p90, policyLine, breachDay };
}
```

- [ ] **Step 2: Typecheck**

Run: `cd /Users/ankkumar/sandbox/github/gpu-guard && bunx tsc --noEmit`
Expected: no errors referencing `whatif.ts`.

- [ ] **Step 3: Manual sanity check via a scratch script**

Run: `cd /Users/ankkumar/sandbox/github/gpu-guard && bun -e '
import { SCENARIOS } from "./src/lib/scenarios.ts";
import { applyWhatIf } from "./src/lib/whatif.ts";
const f = SCENARIOS["s5-procure"].forecast;
const out = applyWhatIf(f, { growthPct: 50, spike: true, poolDeltaGpus: -20 });
console.log("orig breachDay", f.breachDay, "new breachDay", out.breachDay);
console.log("orig policyLine", f.policyLine, "new policyLine", out.policyLine);
'`

Expected: prints two lines; `new breachDay` should be less than or equal to `orig breachDay` (growth up, policy line down → breach sooner or unchanged), and `new policyLine` = `orig policyLine - 20`.

- [ ] **Step 4: Commit**

```bash
git add src/lib/whatif.ts
git commit -m "feat: add pure what-if transform for forecast series"
```

---

### Task 3: Scripted chat Q&A data

**Files:**
- Create: `src/lib/chat-script.ts`

**Interfaces:**
- Consumes: `Scenario` type from `src/lib/scenarios.ts` (fields: `record`, `decisionBucket`, `gpuImpact`, `tokensSecImpact`, `ladder`, `forecast`, `sizing`)
- Produces: `QaPair = { q: string; a: string; keywords: string[] }` and `buildQaScript(scenario: Scenario): QaPair[]` and `matchQuestion(script: QaPair[], input: string): QaPair | null`

- [ ] **Step 1: Write the file**

```ts
import type { Scenario } from "./scenarios";

export type QaPair = { q: string; a: string; keywords: string[] };

const BUCKET_COPY: Record<Scenario["decisionBucket"], string> = {
  absorb: "No provisioning is required — the request is absorbed in existing headroom.",
  provision: "GPU infrastructure must be ordered to cover this request.",
  rebalance: "No new hardware is needed — capacity will be rebalanced across pools internally.",
};

export function buildQaScript(scenario: Scenario): QaPair[] {
  const recommended = scenario.ladder.find((r) => r.verdict === "win");
  const cost = recommended?.deltaCost;
  const costText = cost == null ? "no incremental monthly cost" : `about $${cost.toLocaleString()}/mo`;
  const breachText =
    scenario.forecast.breachDay == null
      ? "no capacity breach is projected within the 180-day forecast window"
      : `capacity is projected to breach policy in ${scenario.forecast.breachDay} days`;

  return [
    {
      q: "What decision did the recommendation engine make?",
      a: `${BUCKET_COPY[scenario.decisionBucket]} (recommended strategy: "${recommended?.strategy ?? "n/a"}").`,
      keywords: ["decision", "recommend", "why", "bucket"],
    },
    {
      q: "What is the GPU impact?",
      a: scenario.gpuImpact.label,
      keywords: ["gpu", "impact", "shortfall"],
    },
    {
      q: "What is the tokens/sec impact?",
      a: scenario.tokensSecImpact.label,
      keywords: ["token", "tokens/sec", "throughput", "tok/s"],
    },
    {
      q: "What will this cost?",
      a: `The recommended path costs ${costText}.`,
      keywords: ["cost", "price", "$", "budget"],
    },
    {
      q: "When will we run out of capacity?",
      a: breachText,
      keywords: ["when", "breach", "run out", "timeline", "forecast"],
    },
    {
      q: "What evidence backs this?",
      a: `Backed by ${scenario.evidence.length} evidence records, most recently as of ${scenario.asOf}.`,
      keywords: ["evidence", "source", "proof", "trust"],
    },
  ];
}

export function matchQuestion(script: QaPair[], input: string): QaPair | null {
  const lower = input.toLowerCase();
  return script.find((qa) => qa.keywords.some((k) => lower.includes(k))) ?? null;
}
```

- [ ] **Step 2: Typecheck**

Run: `cd /Users/ankkumar/sandbox/github/gpu-guard && bunx tsc --noEmit`
Expected: no errors referencing `chat-script.ts`.

- [ ] **Step 3: Manual sanity check**

Run: `cd /Users/ankkumar/sandbox/github/gpu-guard && bun -e '
import { SCENARIOS } from "./src/lib/scenarios.ts";
import { buildQaScript, matchQuestion } from "./src/lib/chat-script.ts";
const script = buildQaScript(SCENARIOS["s3-rebalance"]);
console.log(script.length, "pairs");
console.log(matchQuestion(script, "how much will this cost me")?.a);
console.log(matchQuestion(script, "asdkjfh")?.a ?? "no match");
'`

Expected: `6 pairs`, a cost sentence, then `no match`.

- [ ] **Step 4: Commit**

```bash
git add src/lib/chat-script.ts
git commit -m "feat: add scripted Q&A data for conversational chat drawer"
```

---

### Task 4: `ToolBadge` component

**Files:**
- Create: `src/components/ToolBadge.tsx`

**Interfaces:**
- Consumes: `PumaTool` type from `src/lib/scenarios.ts`, `Badge` from `@/components/ui/badge`
- Produces: `ToolBadge({ tool }: { tool: PumaTool })`, `ToolBadgeRow({ tools }: { tools: PumaTool[] })`

- [ ] **Step 1: Write the component**

```tsx
import { Badge } from "@/components/ui/badge";
import type { PumaTool } from "@/lib/scenarios";

const TOOL_LABEL: Record<PumaTool, string> = {
  grafana: "Grafana",
  puma: "PUMA",
  openshift: "OpenShift",
};

const TOOL_TONE: Record<PumaTool, string> = {
  grafana: "border-warn/40 text-warn bg-warn/10",
  puma: "border-brand/40 text-brand bg-brand/10",
  openshift: "border-bad/40 text-bad bg-bad/10",
};

export function ToolBadge({ tool }: { tool: PumaTool }) {
  return (
    <Badge variant="outline" className={`font-mono text-[9px] uppercase tracking-widest ${TOOL_TONE[tool]}`}>
      {TOOL_LABEL[tool]}
    </Badge>
  );
}

export function ToolBadgeRow({ tools }: { tools: PumaTool[] }) {
  return (
    <div className="flex gap-1.5">
      {tools.map((t) => (
        <ToolBadge key={t} tool={t} />
      ))}
    </div>
  );
}
```

- [ ] **Step 2: Typecheck**

Run: `cd /Users/ankkumar/sandbox/github/gpu-guard && bunx tsc --noEmit`
Expected: no errors referencing `ToolBadge.tsx`.

- [ ] **Step 3: Commit**

```bash
git add src/components/ToolBadge.tsx
git commit -m "feat: add ToolBadge component for Grafana/PUMA/OpenShift tags"
```

---

### Task 5: Theme toggle (light/dark)

**Files:**
- Modify: `src/styles.css`
- Modify: `src/components/AppShell.tsx`

**Interfaces:**
- Produces: `AppCtx.theme: "light" | "dark"`, `AppCtx.setTheme: (t: "light" | "dark") => void`, exported via a new hook `useTheme()` in `AppShell.tsx` (mirrors `usePersona`/`useScenario` pattern already in the file).
- Consumes: existing `Ctx` context, existing localStorage pattern (`localStorage.getItem("persona")` etc, ~line 41-44 of `AppShell.tsx`).

- [ ] **Step 1: Replace the mismatched `.dark {}` block in `src/styles.css` with a real light palette**

Read current `:root` block (lines 65-109) — it holds the dark cyber-industrial palette. Read current `.dark {}` block (lines 111-144) — unused shadcn boilerplate to be replaced.

Rename the existing `:root { ... }` block (lines 65-109) to `.dark { ... }` (keep contents identical — this preserves current visuals as the dark theme). Then write a new `:root { ... }` block with a light palette using the same token names and matching hues (same brand cyan-ish hue at ~200, ok green ~155, warn amber ~55, bad red ~25) but light surfaces and dark text:

```css
:root {
  --radius: 0.5rem;
  --surface: oklch(0.98 0.005 260);
  --panel: oklch(1 0 0);
  --panel-2: oklch(0.95 0.008 260);
  --brand: oklch(0.55 0.16 200);
  --brand-dim: oklch(0.62 0.14 200);
  --text-dim: oklch(0.45 0.02 260);
  --warn: oklch(0.55 0.17 55);
  --ok: oklch(0.5 0.17 155);
  --bad: oklch(0.5 0.22 25);

  --background: var(--surface);
  --foreground: oklch(0.2 0.01 260);
  --card: var(--panel);
  --card-foreground: oklch(0.2 0.01 260);
  --popover: var(--panel);
  --popover-foreground: oklch(0.2 0.01 260);
  --primary: var(--brand);
  --primary-foreground: oklch(0.98 0 0);
  --secondary: var(--panel-2);
  --secondary-foreground: oklch(0.2 0.01 260);
  --muted: var(--panel-2);
  --muted-foreground: var(--text-dim);
  --accent: var(--panel-2);
  --accent-foreground: oklch(0.2 0.01 260);
  --destructive: var(--bad);
  --destructive-foreground: oklch(0.98 0 0);
  --border: oklch(0.85 0.01 260);
  --input: oklch(0.85 0.01 260);
  --ring: var(--brand);
  --chart-1: oklch(0.55 0.16 200);
  --chart-2: oklch(0.5 0.17 155);
  --chart-3: oklch(0.55 0.17 55);
  --chart-4: oklch(0.5 0.2 300);
  --chart-5: oklch(0.5 0.22 25);
  --sidebar: var(--surface);
  --sidebar-foreground: oklch(0.2 0.01 260);
  --sidebar-primary: var(--brand);
  --sidebar-primary-foreground: oklch(0.98 0 0);
  --sidebar-accent: var(--panel);
  --sidebar-accent-foreground: oklch(0.2 0.01 260);
  --sidebar-border: oklch(0.85 0.01 260);
  --sidebar-ring: var(--brand);
}
```

The `.dark { ... }` block should now contain exactly what `:root` used to contain (the original lines 65-109 content, unchanged).

- [ ] **Step 2: Verify CSS structure**

Run: `cd /Users/ankkumar/sandbox/github/gpu-guard && grep -n "^:root\|^\.dark" src/styles.css`
Expected: two lines, `:root {` and `.dark {`, with `:root` appearing first (light) and `.dark` second (dark, was previously `:root`'s content).

- [ ] **Step 3: Add `theme` to `AppShell` context**

In `src/components/AppShell.tsx`, extend `AppCtx` type (~line 6-11):

```ts
type Theme = "light" | "dark";

type AppCtx = {
  persona: PersonaId;
  setPersona: (p: PersonaId) => void;
  scenarioId: ScenarioId;
  setScenarioId: (s: ScenarioId) => void;
  theme: Theme;
  setTheme: (t: Theme) => void;
};
```

Update the default `Ctx` value (~line 12-17) to add:

```ts
  theme: "dark",
  setTheme: () => {},
```

Add a new hook after `useScenario` (~line 22):

```ts
export const useTheme = () => {
  const { theme, setTheme } = useContext(Ctx);
  return { theme, setTheme };
};
```

- [ ] **Step 4: Wire theme state, localStorage, and DOM class in `AppShell`**

In the `AppShell` function body, add state (after the `scenarioId` state, ~line 35):

```ts
  const [theme, setThemeState] = useState<Theme>("dark");
```

In the existing localStorage-restore `useEffect` (~line 39-45), add after the scenario restore:

```ts
    const t = localStorage.getItem("theme");
    if (t === "light" || t === "dark") setThemeState(t);
```

Add a `setTheme` function alongside `setPersona`/`setScenarioId` (~line 47-57):

```ts
  const setTheme = (t: Theme) => {
    setThemeState(t);
    if (typeof window !== "undefined") localStorage.setItem("theme", t);
  };
```

Add a second `useEffect` (after the restore effect) to apply the class to `<html>`:

```ts
  useEffect(() => {
    if (typeof document === "undefined") return;
    document.documentElement.classList.toggle("dark", theme === "dark");
  }, [theme]);
```

Update the `Ctx.Provider value={{...}}` (~line 63) to include `theme, setTheme`.

- [ ] **Step 5: Add toggle button to sidebar footer**

Replace the sidebar footer block (~lines 156-161):

```tsx
          <div className="p-4 border-t border-border flex items-center justify-between">
            <div className="text-[10px] font-mono text-text-dim flex items-center gap-2">
              <span className="size-1.5 rounded-full bg-ok animate-pulse"></span>
              telemetry OK · 14:03:12Z
            </div>
            <button
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              className="text-[10px] font-mono border border-border rounded px-2 py-1 hover:bg-panel shrink-0"
              title="Toggle light/dark theme"
            >
              {theme === "dark" ? "☾ DARK" : "☀ LIGHT"}
            </button>
          </div>
```

`theme`/`setTheme` are already in scope in `AppShell` from Step 4's `useState`/local function — no destructuring needed since they're locals, not from `useContext` inside this component.

- [ ] **Step 6: Typecheck**

Run: `cd /Users/ankkumar/sandbox/github/gpu-guard && bunx tsc --noEmit`
Expected: no errors referencing `AppShell.tsx` or `styles.css`.

- [ ] **Step 7: Manual visual check**

Run: `cd /Users/ankkumar/sandbox/github/gpu-guard && bun run dev`
Open the app in a browser, click the theme toggle in the sidebar footer. Confirm the whole app switches between a light surface/dark text look and the original dark cyber-industrial look, and that reloading the page preserves the last choice.
Stop the dev server after confirming (Ctrl-C).

- [ ] **Step 8: Commit**

```bash
git add src/styles.css src/components/AppShell.tsx
git commit -m "feat: add light/dark theme toggle with real light palette"
```

---

### Task 6: `DecisionBanner` component (3-bucket decision + impact tiles)

**Files:**
- Create: `src/components/DecisionBanner.tsx`

**Interfaces:**
- Consumes: `Scenario` type (`decisionBucket`, `gpuImpact`, `tokensSecImpact`) from `src/lib/scenarios.ts`
- Produces: `DecisionBanner({ scenario }: { scenario: Scenario })`

- [ ] **Step 1: Write the component**

```tsx
import type { Scenario } from "@/lib/scenarios";

const BUCKET_COPY: Record<Scenario["decisionBucket"], { label: string; tone: "ok" | "warn" | "bad" }> = {
  absorb: { label: "No impact — absorbed, no provisioning required", tone: "ok" },
  provision: { label: "GPU provisioning required (order infrastructure)", tone: "bad" },
  rebalance: { label: "Workload rebalance required (internal prioritization)", tone: "warn" },
};

const TONE_CLASS = {
  ok: "border-ok/40 bg-ok/10 text-ok",
  warn: "border-warn/40 bg-warn/10 text-warn",
  bad: "border-bad/40 bg-bad/10 text-bad",
} as const;

export function DecisionBanner({ scenario }: { scenario: Scenario }) {
  const bucket = BUCKET_COPY[scenario.decisionBucket];
  return (
    <div className={`rounded-xl border-2 p-4 flex items-center gap-6 ${TONE_CLASS[bucket.tone]}`}>
      <div className="flex-1">
        <div className="text-[10px] font-mono uppercase tracking-widest opacity-70">
          Agent recommendation engine · decision
        </div>
        <div className="text-lg font-bold mt-1">{bucket.label}</div>
      </div>
      <div className="flex gap-4">
        <ImpactTile label="GPU impact" value={scenario.gpuImpact.label} />
        <ImpactTile label="Tokens/sec impact" value={scenario.tokensSecImpact.label} />
      </div>
    </div>
  );
}

function ImpactTile({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-surface/60 border border-border rounded-lg px-4 py-2 min-w-[180px]">
      <div className="text-[9px] font-mono uppercase tracking-widest text-text-dim">{label}</div>
      <div className="text-sm font-mono mt-1">{value}</div>
    </div>
  );
}
```

- [ ] **Step 2: Typecheck**

Run: `cd /Users/ankkumar/sandbox/github/gpu-guard && bunx tsc --noEmit`
Expected: no errors referencing `DecisionBanner.tsx`.

- [ ] **Step 3: Commit**

```bash
git add src/components/DecisionBanner.tsx
git commit -m "feat: add DecisionBanner for 3-bucket recommendation display"
```

---

### Task 7: `ExecutiveSummaryCard` component (requester persona view)

**Files:**
- Create: `src/components/ExecutiveSummaryCard.tsx`

**Interfaces:**
- Consumes: `Scenario` type (`decisionBucket`, `gpuImpact`, `tokensSecImpact`, `ladder`, `forecast`, `record`) from `src/lib/scenarios.ts`
- Produces: `ExecutiveSummaryCard({ scenario }: { scenario: Scenario })`

- [ ] **Step 1: Write the component**

```tsx
import type { Scenario } from "@/lib/scenarios";

const BUCKET_COPY: Record<Scenario["decisionBucket"], string> = {
  absorb: "No action needed — your request fits in existing capacity.",
  provision: "New GPU hardware will be ordered to support your request.",
  rebalance: "Your request will be served by shifting capacity between pools — no new hardware needed.",
};

export function ExecutiveSummaryCard({ scenario }: { scenario: Scenario }) {
  const recommended = scenario.ladder.find((r) => r.verdict === "win");
  const cost = recommended?.deltaCost;
  const readyBy =
    scenario.forecast.breachDay == null
      ? "already within plan — no timeline risk"
      : `within ${Math.max(scenario.forecast.leadTimeDays, 1)} days if action starts now`;

  return (
    <div className="bg-panel border border-border rounded-xl p-6 max-w-xl">
      <div className="text-[10px] font-mono uppercase tracking-widest text-text-dim mb-2">
        What this means for you
      </div>
      <p className="text-base leading-relaxed">{BUCKET_COPY[scenario.decisionBucket]}</p>
      <dl className="mt-4 grid grid-cols-2 gap-4 text-sm">
        <div>
          <dt className="text-[10px] uppercase tracking-widest text-text-dim">GPU impact</dt>
          <dd className="mt-1 font-mono">{scenario.gpuImpact.label}</dd>
        </div>
        <div>
          <dt className="text-[10px] uppercase tracking-widest text-text-dim">Tokens/sec impact</dt>
          <dd className="mt-1 font-mono">{scenario.tokensSecImpact.label}</dd>
        </div>
        <div>
          <dt className="text-[10px] uppercase tracking-widest text-text-dim">Cost impact</dt>
          <dd className="mt-1 font-mono">{cost == null ? "No added cost" : `$${cost.toLocaleString()}/mo`}</dd>
        </div>
        <div>
          <dt className="text-[10px] uppercase tracking-widest text-text-dim">Ready by</dt>
          <dd className="mt-1 font-mono">{readyBy}</dd>
        </div>
      </dl>
    </div>
  );
}
```

- [ ] **Step 2: Typecheck**

Run: `cd /Users/ankkumar/sandbox/github/gpu-guard && bunx tsc --noEmit`
Expected: no errors referencing `ExecutiveSummaryCard.tsx`.

- [ ] **Step 3: Commit**

```bash
git add src/components/ExecutiveSummaryCard.tsx
git commit -m "feat: add ExecutiveSummaryCard for requester persona plain-language view"
```

---

### Task 8: `ChatDrawer` component (scripted conversational Q&A)

**Files:**
- Create: `src/components/ChatDrawer.tsx`

**Interfaces:**
- Consumes: `Scenario` type from `src/lib/scenarios.ts`; `buildQaScript`, `matchQuestion`, `QaPair` from `src/lib/chat-script.ts`; `Sheet`, `SheetContent`, `SheetTrigger`, `SheetHeader`, `SheetTitle` from `@/components/ui/sheet`; `ScrollArea` from `@/components/ui/scroll-area`
- Produces: `ChatDrawer({ scenario }: { scenario: Scenario })` — self-contained, renders its own floating trigger button + sheet.

- [ ] **Step 1: Check the `Sheet` component's exported names**

Run: `cd /Users/ankkumar/sandbox/github/gpu-guard && grep -n "^const \|^export" src/components/ui/sheet.tsx`

Confirm exact export names (expect something like `Sheet, SheetTrigger, SheetClose, SheetContent, SheetHeader, SheetFooter, SheetTitle, SheetDescription`). Use whatever the grep shows in Step 2 — adjust import names to match exactly.

- [ ] **Step 2: Write the component**

```tsx
import { useState } from "react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { ScrollArea } from "@/components/ui/scroll-area";
import { buildQaScript, matchQuestion, type QaPair } from "@/lib/chat-script";
import type { Scenario } from "@/lib/scenarios";

type Msg = { role: "user" | "assistant"; text: string };

export function ChatDrawer({ scenario }: { scenario: Scenario }) {
  const script = buildQaScript(scenario);
  const [messages, setMessages] = useState<Msg[]>([
    { role: "assistant", text: `Ask me about ${scenario.record.useCase}'s GPU impact, decision, cost, or timeline.` },
  ]);
  const [input, setInput] = useState("");

  function ask(text: string) {
    if (!text.trim()) return;
    const found = matchQuestion(script, text);
    const answer =
      found?.a ??
      "I can help with GPU impact, tokens/sec impact, the recommendation decision, cost, and timeline for this scenario.";
    setMessages((m) => [...m, { role: "user", text }, { role: "assistant", text: answer }]);
    setInput("");
  }

  return (
    <Sheet>
      <SheetTrigger asChild>
        <button className="fixed bottom-6 right-6 z-20 bg-brand text-surface rounded-full px-5 py-3 text-sm font-bold shadow-lg hover:brightness-110">
          Ask about this scenario
        </button>
      </SheetTrigger>
      <SheetContent side="right" className="w-[420px] flex flex-col p-0">
        <SheetHeader className="p-4 border-b border-border">
          <SheetTitle>Capacity Q&amp;A · {scenario.record.id}</SheetTitle>
        </SheetHeader>
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-3">
            {messages.map((m, i) => (
              <div key={i} className={m.role === "user" ? "flex justify-end" : ""}>
                <div
                  className={
                    "max-w-[85%] px-3 py-2 rounded text-sm " +
                    (m.role === "assistant" ? "bg-panel border border-border" : "bg-brand/10 border border-brand/30")
                  }
                >
                  {m.text}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
        <div className="p-3 border-t border-border space-y-2">
          <div className="flex flex-wrap gap-1.5">
            {script.map((qa: QaPair) => (
              <button
                key={qa.q}
                onClick={() => ask(qa.q)}
                className="text-[10px] border border-border rounded px-2 py-1 hover:bg-panel"
              >
                {qa.q}
              </button>
            ))}
          </div>
          <div className="flex gap-2">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && ask(input)}
              placeholder="Ask a question…"
              className="flex-1 bg-panel border border-border rounded px-3 py-2 text-sm outline-none focus:border-brand"
            />
            <button
              onClick={() => ask(input)}
              className="bg-brand text-surface px-3 py-2 rounded text-xs font-bold hover:brightness-110"
            >
              SEND
            </button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
```

- [ ] **Step 3: Typecheck**

Run: `cd /Users/ankkumar/sandbox/github/gpu-guard && bunx tsc --noEmit`
Expected: no errors referencing `ChatDrawer.tsx`. If `SheetContent`/`SheetHeader`/`SheetTitle` names differ from Step 1's grep output, fix the import to match before proceeding.

- [ ] **Step 4: Commit**

```bash
git add src/components/ChatDrawer.tsx
git commit -m "feat: add scripted conversational ChatDrawer component"
```

---

### Task 9: Wire Run Detail page (`run.$id.tsx`) — decision banner, tool badges, chat, executive view

**Files:**
- Modify: `src/routes/run.$id.tsx`

**Interfaces:**
- Consumes: `DecisionBanner` (Task 6), `ExecutiveSummaryCard` (Task 7), `ChatDrawer` (Task 8), `ToolBadgeRow` (Task 4), `usePersona` (existing, from `AppShell.tsx`), `Collapsible`/`CollapsibleTrigger`/`CollapsibleContent` from `@/components/ui/collapsible`

- [ ] **Step 1: Add imports**

At the top of `src/routes/run.$id.tsx`, add:

```ts
import { DecisionBanner } from "@/components/DecisionBanner";
import { ExecutiveSummaryCard } from "@/components/ExecutiveSummaryCard";
import { ChatDrawer } from "@/components/ChatDrawer";
import { ToolBadgeRow } from "@/components/ToolBadge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
```

- [ ] **Step 2: Insert `DecisionBanner` and split technical detail behind executive view**

In `RunDetail()`, `usePersona` is already imported from `AppShell` at line 3. Add persona read at the top of the function body (after `const { scenario: current } = useScenario();` ~line 25):

```ts
  const { persona } = usePersona();
  const isExecutive = persona === "requester";
```

Replace the `<section>` body (currently lines 63-83: `GuardrailBar` through `EvidenceManifest`) with:

```tsx
        <section className="flex-1 overflow-auto p-6 space-y-6 bg-[radial-gradient(oklch(0.28_0.02_260/0.4)_1px,transparent_1px)] [background-size:22px_22px]">
          <DecisionBanner scenario={scenario} />

          {isExecutive ? (
            <>
              <ExecutiveSummaryCard scenario={scenario} />
              <Collapsible>
                <CollapsibleTrigger className="text-[10px] font-mono uppercase tracking-widest text-brand hover:underline">
                  Show technical detail ▾
                </CollapsibleTrigger>
                <CollapsibleContent className="space-y-6 mt-4">
                  <GuardrailBar scenario={scenario} />
                  {scenario.hitl && <HitlPanel scenario={scenario} />}
                  <Graph nodes={nodes} selected={selected} onSelect={setSelected} />
                  <SizingDerivation scenario={scenario} />
                  <CandidacyTable scenario={scenario} />
                  <PlanningLadder rungs={scenario.ladder} />
                  <EvidenceManifest scenario={scenario} />
                </CollapsibleContent>
              </Collapsible>
            </>
          ) : (
            <>
              <GuardrailBar scenario={scenario} />
              {scenario.hitl && <HitlPanel scenario={scenario} />}

              <div className="mb-1 flex items-center justify-between">
                <h2 className="text-sm font-bold uppercase tracking-widest text-text-dim">
                  Workflow · agents (rounded) → deterministic engine (hard-edged) → record
                </h2>
                <div className="flex gap-3 text-[10px] font-mono text-text-dim">
                  <Legend swatch="rounded-full bg-panel border border-border" label="agent" />
                  <Legend swatch="rounded-none bg-brand/20 border border-brand" label="engine" />
                  <Legend swatch="rounded-sm bg-ok/20 border border-ok" label="record" />
                </div>
              </div>
              <Graph nodes={nodes} selected={selected} onSelect={setSelected} />

              <SizingDerivation scenario={scenario} />
              <CandidacyTable scenario={scenario} />
              <PlanningLadder rungs={scenario.ladder} />
              <EvidenceManifest scenario={scenario} />
            </>
          )}
        </section>
```

(This preserves the original non-executive layout exactly, and moves it into the `else` branch verbatim.)

- [ ] **Step 3: Add tool badges to evidence rows**

In `EvidenceRail()`'s "Trusted sources" list (~lines 381-398), add `ToolBadgeRow` when evidence source implies a tool. Update the `<li>` block:

```tsx
            {scenario.evidence.map((e, i) => (
              <li key={i} className="bg-surface border border-border rounded p-2 text-[11px] font-mono">
                <div className="flex justify-between text-text-dim">
                  <span>
                    {e.source}.{e.kind}
                  </span>
                  <span>{e.staleness}</span>
                </div>
                <div className="mt-1 text-foreground break-words">{e.value}</div>
                <div className="text-text-dim">
                  as_of {e.asOf} · trust {e.trust} · conf {e.confidence}
                </div>
                {e.source === "telemetry" && <div className="mt-1"><ToolBadgeRow tools={["grafana"]} /></div>}
                {e.source === "inventory" && <div className="mt-1"><ToolBadgeRow tools={["openshift"]} /></div>}
                {e.source === "provisioning" && <div className="mt-1"><ToolBadgeRow tools={["puma"]} /></div>}
              </li>
            ))}
```

- [ ] **Step 4: Add `ChatDrawer`**

At the end of the `<AppShell>` JSX, right before the closing `</AppShell>` tag (after the `<aside>...</aside>` block, ~line 87), add:

```tsx
      <ChatDrawer scenario={scenario} />
```

- [ ] **Step 5: Typecheck**

Run: `cd /Users/ankkumar/sandbox/github/gpu-guard && bunx tsc --noEmit`
Expected: no errors referencing `run.$id.tsx`.

- [ ] **Step 6: Manual check**

Run: `cd /Users/ankkumar/sandbox/github/gpu-guard && bun run dev`
Navigate to a run detail page. Confirm: decision banner shows above the graph with correct bucket wording per scenario; switching persona (sidebar) to "Application Requester" replaces the technical detail with the executive card + a "Show technical detail" toggle that expands the original view; clicking "Ask about this scenario" opens the chat drawer and answers scripted questions. Stop the dev server (Ctrl-C) after confirming.

- [ ] **Step 7: Commit**

```bash
git add src/routes/run.$id.tsx
git commit -m "feat: add decision banner, tool badges, chat, and executive view to Run Detail"
```

---

### Task 10: Wire Forecast page (`forecast.tsx`) — what-if controls, metric toggle, chat, executive view

**Files:**
- Modify: `src/routes/forecast.tsx`

**Interfaces:**
- Consumes: `applyWhatIf`, `DEFAULT_WHATIF`, `WhatIfParams` (Task 2); `ChatDrawer` (Task 8); `Slider` from `@/components/ui/slider`; `Switch` from `@/components/ui/switch`; `usePersona` (existing)

- [ ] **Step 1: Check `Slider`/`Switch` prop shapes**

Run: `cd /Users/ankkumar/sandbox/github/gpu-guard && grep -n "onValueChange\|checked\|onCheckedChange" src/components/ui/slider.tsx src/components/ui/switch.tsx`

Radix `Slider` takes `value: number[]`, `onValueChange: (v: number[]) => void`, `min`, `max`, `step`. Radix `Switch` takes `checked: boolean`, `onCheckedChange: (v: boolean) => void`. Confirm this matches the grep output before using them in Step 3.

- [ ] **Step 2: Add imports and state**

At the top of `src/routes/forecast.tsx`, add:

```ts
import { useMemo, useState } from "react";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { ChatDrawer } from "@/components/ChatDrawer";
import { applyWhatIf, DEFAULT_WHATIF, type WhatIfParams } from "@/lib/whatif";
import { usePersona } from "@/components/AppShell";
```

(`AppShell`/`PageHeader`/`useScenario` are already imported at line 2 — add `usePersona` to that existing import instead of a new line: `import { AppShell, PageHeader, usePersona, useScenario } from "@/components/AppShell";`.)

In `ForecastPage()`, after `const { scenario } = useScenario();` (~line 21):

```ts
  const { persona } = usePersona();
  const isExecutive = persona === "requester";
  const [whatIf, setWhatIf] = useState<WhatIfParams>(DEFAULT_WHATIF);
  const [metric, setMetric] = useState<"gpu" | "tokens">("gpu");
```

- [ ] **Step 3: Replace `f`/`data` computation to use `applyWhatIf`**

Replace (~line 22-25):

```ts
  const f = scenario.forecast;
  const data = f.baseline.map((v, i) => ({
    day: i, baseline: v, p10: f.p10[i], p90: f.p90[i], band: [f.p10[i], f.p90[i] - f.p10[i]],
  }));
```

with:

```ts
  const f = useMemo(() => applyWhatIf(scenario.forecast, whatIf), [scenario.forecast, whatIf]);
  const metricScale = metric === "tokens" ? scenario.sizing.outTokens : 1;
  const metricUnit = metric === "tokens" ? "tok/s" : "rps";
  const data = f.baseline.map((v, i) => ({
    day: i,
    baseline: v * metricScale,
    p10: f.p10[i] * metricScale,
    p90: f.p90[i] * metricScale,
    band: [f.p10[i] * metricScale, (f.p90[i] - f.p10[i]) * metricScale],
  }));
```

Every other reference to `f.baseline[179]`, `f.p90[179]`, `f.policyLine` in the KPI tiles (~lines 44-46) and chart (`ReferenceLine y={f.policyLine}` ~line 69) must also be scaled by `metricScale` for consistency. Update:

```tsx
          <Kpi label="Baseline day 180" value={(f.baseline[179] * metricScale).toFixed(1)} unit={metricUnit} />
          <Kpi label="p90 day 180" value={(f.p90[179] * metricScale).toFixed(1)} unit={metricUnit} tone="warn" />
          <Kpi label="Policy line" value={(f.policyLine * metricScale).toFixed(0)} unit={metricUnit} />
```

And the `ReferenceLine`:

```tsx
                <ReferenceLine y={f.policyLine * metricScale} stroke="oklch(0.65 0.22 25)" strokeDasharray="4 3" label={{ value: `policy ${(f.policyLine * metricScale).toFixed(0)}`, position: "right", fill: "oklch(0.65 0.22 25)", fontSize: 10 }} />
```

- [ ] **Step 4: Add what-if control panel + metric toggle (technical view) and simplified control (executive view)**

Insert right after the `<PageHeader ... />` closing tag and before the KPI grid (~line 42, before `<div className="grid grid-cols-4 gap-4">`):

```tsx
        {isExecutive ? (
          <div className="bg-panel border border-border rounded-xl p-4 flex items-center gap-4">
            <span className="text-[10px] font-mono uppercase tracking-widest text-text-dim">Growth scenario</span>
            <select
              value={whatIf.growthPct}
              onChange={(e) => setWhatIf((w) => ({ ...w, growthPct: Number(e.target.value) }))}
              className="bg-panel-2 border border-border text-sm rounded p-2 outline-none focus:border-brand"
            >
              <option value={-20}>Slower than expected</option>
              <option value={0}>As expected</option>
              <option value={50}>Faster than expected</option>
              <option value={100}>Much faster than expected</option>
            </select>
          </div>
        ) : (
          <div className="bg-panel border border-border rounded-xl p-4 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold uppercase tracking-widest">What-if controls</h3>
              <div className="flex gap-2 text-[10px] font-mono">
                <button
                  onClick={() => setMetric("gpu")}
                  className={`px-2 py-1 rounded border ${metric === "gpu" ? "border-brand text-brand bg-brand/10" : "border-border text-text-dim"}`}
                >
                  GPU Impact
                </button>
                <button
                  onClick={() => setMetric("tokens")}
                  className={`px-2 py-1 rounded border ${metric === "tokens" ? "border-brand text-brand bg-brand/10" : "border-border text-text-dim"}`}
                >
                  Tokens/sec Impact
                </button>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-6">
              <div>
                <div className="flex justify-between text-[10px] font-mono text-text-dim mb-2">
                  <span>Demand growth</span><span>{whatIf.growthPct > 0 ? "+" : ""}{whatIf.growthPct}%</span>
                </div>
                <Slider
                  value={[whatIf.growthPct]}
                  min={-20} max={100} step={5}
                  onValueChange={([v]) => setWhatIf((w) => ({ ...w, growthPct: v }))}
                />
              </div>
              <div>
                <div className="flex justify-between text-[10px] font-mono text-text-dim mb-2">
                  <span>Pool size delta</span><span>{whatIf.poolDeltaGpus > 0 ? "+" : ""}{whatIf.poolDeltaGpus} GPU</span>
                </div>
                <Slider
                  value={[whatIf.poolDeltaGpus]}
                  min={-40} max={40} step={5}
                  onValueChange={([v]) => setWhatIf((w) => ({ ...w, poolDeltaGpus: v }))}
                />
              </div>
              <div className="flex items-center gap-3">
                <span className="text-[10px] font-mono text-text-dim">Traffic spike (+40%, 2wk)</span>
                <Switch checked={whatIf.spike} onCheckedChange={(v: boolean) => setWhatIf((w) => ({ ...w, spike: v }))} />
              </div>
            </div>
          </div>
        )}
```

Place this JSX block directly inside the existing `<div className="flex-1 overflow-auto p-6 space-y-6">` wrapper (~line 42), as its first child, before the KPI grid `<div className="grid grid-cols-4 gap-4">`.

- [ ] **Step 5: Wrap technical charts/backtest sections behind executive collapse**

Import `Collapsible`/`CollapsibleTrigger`/`CollapsibleContent` from `@/components/ui/collapsible` (add to the import block from Step 2).

Wrap the "Backtest folds" / "Coverage" two-column grid (~lines 81-104, the `<div className="grid grid-cols-2 gap-6">...</div>` block) so it only renders unconditionally in technical view, and sits behind a toggle in executive view. Replace that block with:

```tsx
        {isExecutive ? (
          <Collapsible>
            <CollapsibleTrigger className="text-[10px] font-mono uppercase tracking-widest text-brand hover:underline">
              Show technical detail ▾
            </CollapsibleTrigger>
            <CollapsibleContent className="mt-4">
              <div className="grid grid-cols-2 gap-6">
                <div className="bg-panel rounded-xl border border-border p-6">
                  <h3 className="text-sm font-bold uppercase tracking-widest mb-4">Backtest folds</h3>
                  <div className="space-y-2 font-mono text-xs">
                    {f.quality.folds.map((fold) => (
                      <div key={fold.fold} className="flex justify-between items-center border-b border-border pb-2">
                        <span className="text-text-dim">fold {fold.fold}</span>
                        <span className={fold.mape < 0.1 ? "text-ok" : "text-warn"}>MAPE {(fold.mape * 100).toFixed(1)}%</span>
                      </div>
                    ))}
                    <div className="flex justify-between pt-1"><span className="text-text-dim">avg</span><span className={avgMape < 0.1 ? "text-ok" : "text-warn"}>{(avgMape * 100).toFixed(1)}%</span></div>
                  </div>
                </div>
                <div className="bg-panel rounded-xl border border-border p-6">
                  <h3 className="text-sm font-bold uppercase tracking-widest mb-4">Coverage</h3>
                  <Coverage label="Series present" pct={Math.round(f.coverage.present * 100)} warn={f.coverage.present < 0.9} />
                  <div className="mt-3 font-mono text-[11px] text-text-dim space-y-1">
                    <div>gaps: <span className="text-foreground">{f.coverage.gaps}</span></div>
                    <div>longest gap: <span className="text-foreground">{f.coverage.longestGapDays}d</span></div>
                    <div>policy_line: <span className="text-foreground">{(f.policyLine * metricScale).toFixed(0)} {metricUnit}</span></div>
                    <div>lead_time: <span className="text-foreground">{f.leadTimeDays}d</span></div>
                  </div>
                </div>
              </div>
            </CollapsibleContent>
          </Collapsible>
        ) : (
          <div className="grid grid-cols-2 gap-6">
            <div className="bg-panel rounded-xl border border-border p-6">
              <h3 className="text-sm font-bold uppercase tracking-widest mb-4">Backtest folds</h3>
              <div className="space-y-2 font-mono text-xs">
                {f.quality.folds.map((fold) => (
                  <div key={fold.fold} className="flex justify-between items-center border-b border-border pb-2">
                    <span className="text-text-dim">fold {fold.fold}</span>
                    <span className={fold.mape < 0.1 ? "text-ok" : "text-warn"}>MAPE {(fold.mape * 100).toFixed(1)}%</span>
                  </div>
                ))}
                <div className="flex justify-between pt-1"><span className="text-text-dim">avg</span><span className={avgMape < 0.1 ? "text-ok" : "text-warn"}>{(avgMape * 100).toFixed(1)}%</span></div>
              </div>
            </div>
            <div className="bg-panel rounded-xl border border-border p-6">
              <h3 className="text-sm font-bold uppercase tracking-widest mb-4">Coverage</h3>
              <Coverage label="Series present" pct={Math.round(f.coverage.present * 100)} warn={f.coverage.present < 0.9} />
              <div className="mt-3 font-mono text-[11px] text-text-dim space-y-1">
                <div>gaps: <span className="text-foreground">{f.coverage.gaps}</span></div>
                <div>longest gap: <span className="text-foreground">{f.coverage.longestGapDays}d</span></div>
                <div>policy_line: <span className="text-foreground">{(f.policyLine * metricScale).toFixed(0)} {metricUnit}</span></div>
                <div>lead_time: <span className="text-foreground">{f.leadTimeDays}d</span></div>
              </div>
            </div>
          </div>
        )}
```

- [ ] **Step 6: Add `ChatDrawer`**

Right before the closing `</AppShell>` tag (~line 106), add:

```tsx
      <ChatDrawer scenario={scenario} />
```

- [ ] **Step 7: Typecheck**

Run: `cd /Users/ankkumar/sandbox/github/gpu-guard && bunx tsc --noEmit`
Expected: no errors referencing `forecast.tsx`.

- [ ] **Step 8: Manual check**

Run: `cd /Users/ankkumar/sandbox/github/gpu-guard && bun run dev`
Navigate to `/forecast`. Confirm: dragging the growth slider moves the chart and KPI tiles live; toggling the spike switch bumps the line for a 14-day window; toggling the metric buttons relabels units between "rps"→ wait, relabels between GPU/Tokens with different scaled numbers; switching persona to "Application Requester" replaces the slider panel with a single "Growth scenario" dropdown and hides backtest/coverage behind "Show technical detail". Stop the dev server (Ctrl-C) after confirming.

- [ ] **Step 9: Commit**

```bash
git add src/routes/forecast.tsx
git commit -m "feat: add what-if controls, GPU/tokens metric toggle, chat, and executive view to Forecast"
```

---

### Task 11: Wire Capacity page (`capacity.tsx`) — chat drawer, executive view

**Files:**
- Modify: `src/routes/capacity.tsx`

**Interfaces:**
- Consumes: `ChatDrawer` (Task 8), `Collapsible`/`CollapsibleTrigger`/`CollapsibleContent` from `@/components/ui/collapsible`, `usePersona` (existing import already present at line 2)

- [ ] **Step 1: Add imports**

At the top of `src/routes/capacity.tsx`, add:

```ts
import { ChatDrawer } from "@/components/ChatDrawer";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
```

- [ ] **Step 2: Add executive flag**

In `CapacityPage()`, after `const { persona } = usePersona();` (~line 18):

```ts
  const isExecutive = persona === "requester";
```

- [ ] **Step 3: Wrap the pool table + heatmap behind executive collapse**

Replace the block from the pool table `<div className="bg-panel rounded-xl border border-border overflow-hidden">` through the heatmap's closing `</div>` (~lines 47-111) by wrapping both in a conditional. Keep the KPI grid (~lines 40-45) unconditional (already simple enough per the design). New structure:

```tsx
        {isExecutive ? (
          <Collapsible>
            <CollapsibleTrigger className="text-[10px] font-mono uppercase tracking-widest text-brand hover:underline">
              Show technical detail ▾
            </CollapsibleTrigger>
            <CollapsibleContent className="space-y-6 mt-4">
              {/* pool table block, unchanged, moved here */}
              {/* heatmap block, unchanged, moved here */}
            </CollapsibleContent>
          </Collapsible>
        ) : (
          <>
            {/* pool table block, unchanged */}
            {/* heatmap block, unchanged */}
          </>
        )}
```

Concretely: take the existing JSX for the pool table `<div className="bg-panel rounded-xl border border-border overflow-hidden">...</div>` (table markup, unchanged) and the heatmap `<div className="bg-panel rounded-xl border border-border p-6">...</div>` (heatmap markup, unchanged) and place identical copies inside both the `CollapsibleContent` and the `<>...</>` fragment above — no changes to their internals, only where they're mounted.

- [ ] **Step 4: Add `ChatDrawer`**

Right before the closing `</AppShell>` tag (~line 113), add:

```tsx
      <ChatDrawer scenario={scenario} />
```

- [ ] **Step 5: Typecheck**

Run: `cd /Users/ankkumar/sandbox/github/gpu-guard && bunx tsc --noEmit`
Expected: no errors referencing `capacity.tsx`.

- [ ] **Step 6: Manual check**

Run: `cd /Users/ankkumar/sandbox/github/gpu-guard && bun run dev`
Navigate to `/capacity`. Confirm KPI tiles always show; switching persona to "Application Requester" hides the pool table/heatmap behind "Show technical detail"; chat drawer opens and answers questions. Stop the dev server (Ctrl-C) after confirming.

- [ ] **Step 7: Commit**

```bash
git add src/routes/capacity.tsx
git commit -m "feat: add chat drawer and executive view to Capacity page"
```

---

### Task 12: Wire Intake page (`intake.tsx`) — PUMA event banner, tool badges, remove dead chat input, executive view

**Files:**
- Modify: `src/routes/intake.tsx`

**Interfaces:**
- Consumes: `useScenario` (existing, from `AppShell.tsx` — note: `intake.tsx` currently does NOT import `useScenario`, only `usePersona`; must add it), `ToolBadgeRow` (Task 4), `ExecutiveSummaryCard` (Task 7)

- [ ] **Step 1: Add imports and scenario read**

At the top of `src/routes/intake.tsx`, change:

```ts
import { AppShell, PageHeader, usePersona } from "@/components/AppShell";
```

to:

```ts
import { AppShell, PageHeader, usePersona, useScenario } from "@/components/AppShell";
import { ToolBadgeRow } from "@/components/ToolBadge";
import { ExecutiveSummaryCard } from "@/components/ExecutiveSummaryCard";
```

In `IntakePage()`, after `const { persona } = usePersona();` (~line 25):

```ts
  const { scenario } = useScenario();
  const isExecutive = persona === "requester";
```

- [ ] **Step 2: Replace the chat transcript section with a PUMA event banner**

Replace the entire `<section className="flex-1 flex flex-col border-r border-border">...</section>` block (~lines 50-86, which currently renders `CHAT` messages and the dead input) with:

```tsx
        <section className="flex-1 flex flex-col border-r border-border">
          <div className="p-4 border-b border-border">
            <div className="text-[10px] font-mono uppercase tracking-widest text-text-dim">
              PUMA event intake
            </div>
          </div>
          <div className="flex-1 overflow-auto p-6 space-y-6">
            <div className="bg-panel border border-brand/40 rounded-xl p-5">
              <div className="flex items-center justify-between">
                <div className="text-sm font-bold">Event received from PUMA</div>
                <ToolBadgeRow tools={scenario.pumaEvent.tools} />
              </div>
              <div className="mt-2 font-mono text-[11px] text-text-dim space-y-1">
                <div>event_id: <span className="text-foreground">{scenario.pumaEvent.eventId}</span></div>
                <div>received_at: <span className="text-foreground">{scenario.pumaEvent.receivedAt}</span></div>
                <div>ticket: <span className="text-foreground">{scenario.record.ticket}</span></div>
                <div>use_case: <span className="text-foreground">{scenario.record.useCase}</span></div>
                <div>requester: <span className="text-foreground">{scenario.record.requester}</span></div>
              </div>
            </div>
            {isExecutive && <ExecutiveSummaryCard scenario={scenario} />}
          </div>
        </section>
```

This removes the `msg`/`setMsg` state and the `CHAT` import usage — remove `const [msg, setMsg] = useState("");` (~line 27) and remove `CHAT` from the `import { CHAT, INTAKE_FIELDS } from "@/lib/mock-data";` line (~line 3), leaving `import { INTAKE_FIELDS } from "@/lib/mock-data";`. Also remove the now-unused `import { useState } from "react";` (~line 4) since `msg` state is gone — but first grep to confirm nothing else in the file uses `useState`.

- [ ] **Step 3: Verify no remaining `useState` usage before removing the import**

Run: `cd /Users/ankkumar/sandbox/github/gpu-guard && grep -n "useState" src/routes/intake.tsx`
Expected: no matches after Step 2's edit. If there are matches, keep the import and skip removing it.

- [ ] **Step 4: Tag demand-profile fields with tool badges where relevant, hide field detail behind collapse for executive view**

Wrap the `<aside>`'s field list (~lines 94-116) — for executive view, only show the field list behind a "Show technical detail" collapsible; for technical view, show as-is. Add `Collapsible` import:

```ts
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
```

Replace the `<div className="flex-1 overflow-auto p-4 space-y-2">...</div>` block (~lines 94-116) with:

```tsx
          <div className="flex-1 overflow-auto p-4 space-y-2">
            {isExecutive ? (
              <Collapsible>
                <CollapsibleTrigger className="text-[10px] font-mono uppercase tracking-widest text-brand hover:underline">
                  Show technical detail ▾
                </CollapsibleTrigger>
                <CollapsibleContent className="space-y-2 mt-3">
                  <FieldList />
                </CollapsibleContent>
              </Collapsible>
            ) : (
              <FieldList />
            )}
          </div>
```

Add a small local component in the same file (after `IntakePage`, alongside other helpers — there are none currently, so add it right after `IntakePage`'s closing brace):

```tsx
function FieldList() {
  return (
    <>
      {INTAKE_FIELDS.map((f) => (
        <div
          key={f.key}
          className="bg-panel border border-border rounded p-3 flex items-start justify-between gap-3"
        >
          <div className="min-w-0">
            <div className="text-[10px] font-mono uppercase tracking-widest text-text-dim">
              {f.label}
            </div>
            <div className="text-sm font-mono mt-1 truncate">{f.value}</div>
          </div>
          <span
            className={`shrink-0 text-[9px] px-2 py-0.5 rounded border font-mono uppercase ${SOURCE_TONE[f.source] ?? "border-border text-text-dim"}`}
          >
            {f.source}
          </span>
        </div>
      ))}
      <div className="text-[10px] text-text-dim font-mono p-2">
        2 amber fields require confirmation before profile hardens.
      </div>
    </>
  );
}
```

- [ ] **Step 5: Typecheck**

Run: `cd /Users/ankkumar/sandbox/github/gpu-guard && bunx tsc --noEmit`
Expected: no errors referencing `intake.tsx`.

- [ ] **Step 6: Manual check**

Run: `cd /Users/ankkumar/sandbox/github/gpu-guard && bun run dev`
Navigate to `/intake`. Confirm the PUMA event banner shows eventId/receivedAt/tool badges matching the active scenario; switching persona to "Application Requester" shows the executive summary card and collapses the field list; switching scenarios via the sidebar updates the banner. Stop the dev server (Ctrl-C) after confirming.

- [ ] **Step 7: Commit**

```bash
git add src/routes/intake.tsx
git commit -m "feat: replace static chat mock with PUMA event banner and executive view on Intake"
```

---

### Task 13: Full-app verification pass

**Files:** none (verification only)

- [ ] **Step 1: Full typecheck**

Run: `cd /Users/ankkumar/sandbox/github/gpu-guard && bunx tsc --noEmit`
Expected: no errors anywhere in the project.

- [ ] **Step 2: Lint**

Run: `cd /Users/ankkumar/sandbox/github/gpu-guard && bun run lint`
Expected: no new lint errors introduced by this work (pre-existing unrelated warnings, if any, are out of scope).

- [ ] **Step 3: Production build**

Run: `cd /Users/ankkumar/sandbox/github/gpu-guard && bun run build`
Expected: build completes successfully with no errors.

- [ ] **Step 4: End-to-end manual walkthrough**

Run: `cd /Users/ankkumar/sandbox/github/gpu-guard && bun run dev`

Walk through, as `capacity_manager` persona, for each of the 3 scenarios (via sidebar scenario dropdown):
1. `/intake` — PUMA event banner shows correct eventId/tools per scenario.
2. `/run/$id` — decision banner shows the correct bucket (absorb/provision/rebalance) matching the scenario's known ladder outcome (`s1-available`→absorb, `s3-rebalance`→rebalance, `s5-procure`→provision); GPU/Tokens impact tiles show numbers; chat drawer opens and answers all 6 scripted questions plus an unmatched question (fallback message).
3. `/forecast` — what-if sliders move the chart and breach day live; spike toggle changes the curve; metric toggle relabels units; chat drawer works.
4. `/capacity` — chat drawer works; table/heatmap display as before.
5. Toggle theme (sidebar footer) on each page — light and dark both render legibly (no invisible text, no low-contrast borders).

Then switch persona to "Application Requester" and repeat 1-4, confirming each page shows the plain-language executive card and a working "Show technical detail" toggle instead of raw tables.

Stop the dev server (Ctrl-C) after confirming everything above.

- [ ] **Step 5: Commit any final fixups**

If Step 2-4 surfaced fixes, commit them:

```bash
git add -A
git commit -m "fix: address issues found in full verification pass"
```

(Skip this step entirely if no fixes were needed.)

---

## Self-Review Notes

**Spec coverage:**
- Goal #1 (onboard use-case / PUMA event, tool badges) → Task 1 (data), Task 12 (Intake banner).
- Goal #2 (run scenario, workflow viz, GPU/Tokens impact) → Task 1 (impact fields), Task 6 (banner), Task 9 (Run Detail wiring).
- Goal #3 (3-bucket decision) → Task 1 (`decisionBucket`), Task 6 (`DecisionBanner`), Task 9.
- Goal #4 (forecast + what-if) → Task 2 (`applyWhatIf`), Task 10.
- Goal #5 (conversational Q&A) → Task 3 (script data), Task 8 (`ChatDrawer`), wired in Tasks 9/10/11.
- Goal #6 (real-time capacity + Q&A) → Task 11 (existing capacity viz + chat drawer).
- Executive/requester simplification → Task 7 (`ExecutiveSummaryCard`), applied in Tasks 9/10/11/12.
- Light/dark toggle → Task 5.

**Type consistency check:** `Scenario.decisionBucket`/`gpuImpact`/`tokensSecImpact`/`pumaEvent` (Task 1) are consumed with matching field names in `DecisionBanner` (Task 6), `ExecutiveSummaryCard` (Task 7), `chat-script.ts` (Task 3), and route files (Tasks 9/10/12) — verified consistent throughout. `WhatIfParams` fields (`growthPct`, `spike`, `poolDeltaGpus`) match between Task 2's definition and Task 10's usage. `QaPair` fields (`q`, `a`, `keywords`) match between Task 3 and Task 8.

**No placeholders:** all steps contain full code, not descriptions of code.


