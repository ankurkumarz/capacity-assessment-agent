# PUMA Showcase Demo — Design

Date: 2026-07-29

## Context

PUMA is an internal Provisioning and Request Intake system. This app (CORE_COMPUTE /
GPU_PLAN) receives an **event** from PUMA when a new request lands there. The goal is
to showcase, end to end, how this app reacts to a PUMA intake event: sizes the request,
recommends a decision, forecasts capacity impact under what-if scenarios, and exposes a
conversational Q&A surface — all as a demo (no real Grafana/PUMA/OpenShift API calls,
no real LLM backend). The six requested capabilities:

1. Onboard a use-case triggered by a PUMA event (tool badges only, no real integration)
2. Visualize the intake workflow with GPU Impact / Tokens-per-sec Impact
3. Visualize the Agent Recommendation Engine's decision as one of 3 buckets: Absorb (no
   action) / Provision (order infra) / Rebalance (internal prioritization)
4. Visualize a forecast of GPU Impact and Tokens/sec with what-if controls
5. Conversational agentic Q&A (scripted, deterministic — not a live LLM)
6. Real-time capacity visualization with the same conversational Q&A surface

Plus a smaller, independent addition: a light/dark theme toggle.

This is a single connected demo narrative: Inbox → Intake (PUMA event) → Run Detail
(decision) → Forecast (what-if) → Capacity, all driven by the existing scenario data in
`src/lib/scenarios.ts` and `src/lib/engine.ts`. No backend/API routes are added; all data
stays client-side mock data.

## Existing foundation (do not rebuild)

- `src/lib/engine.ts` — deterministic sizing + 6-rung decision ladder
  (`available/scale_model/rebalance/activate/order_infra/manual_review`).
- `src/lib/scenarios.ts` — 3 scenarios (`s1-available`, `s3-rebalance`, `s5-procure`)
  deriving `recommendation`, `sizing`, `evidence`, `candidacy`, `ladder`, `forecast` from
  the engine.
- `run.$id.tsx` — workflow graph, ladder table, evidence rail (real, richest page).
- `forecast.tsx` — Recharts `ComposedChart` with baseline/p10/p90/policy line/breach day
  (real chart, single fixed series, no what-if).
- `capacity.tsx` — KPI tiles, pool table, static heatmap.
- `intake.tsx` — static mock chat transcript + demand-field list (no live send).
- `AppShell.tsx` — persona/scenario context (localStorage-backed), sidebar nav.

## Data model additions

All additions live in `src/lib/scenarios.ts` unless noted, and are pure derivations from
existing engine output — no new simulation logic beyond arithmetic transforms.

```ts
// New fields on Scenario:
pumaEvent: {
  eventId: string;          // e.g. "PUMA-EVT-88213"
  receivedAt: string;       // ISO timestamp
  tools: ("grafana" | "puma" | "openshift")[]; // cosmetic badges only
};
decisionBucket: "absorb" | "provision" | "rebalance"; // collapsed from ladder.state
gpuImpact: { deltaGpus: number; label: string };        // from sizing.shortfallGpus
tokensSecImpact: { tokensPerSec: number; label: string }; // derived from peakRps * outTokens
```

Mapping `ladder.state` → `decisionBucket`:
`available` → `absorb`; `scale_model` | `rebalance` | `activate` → `rebalance`;
`order_infra` | `manual_review` → `provision`.

Each of the 3 scenario configs gets a plausible `pumaEvent.tools` set (e.g. rebalance
scenario tags `grafana` + `openshift`; procure scenario tags `puma` + `grafana`).

New file `src/lib/whatif.ts`:

```ts
export type WhatIfParams = { growthPct: number; spike: boolean; poolDeltaGpus: number };
export function applyWhatIf(forecast: ForecastSeries, params: WhatIfParams): ForecastSeries
```

Recomputes `baseline`/`p10`/`p90`/`breachDay` from the existing series by scaling growth,
optionally injecting a temporary spike window, and shifting `policyLine` by `poolDeltaGpus`
converted to the series' units. Pure function, no engine changes.

New file `src/lib/chat-script.ts`:

```ts
export type QaPair = { q: string; a: string; keywords: string[] };
export function buildQaScript(scenario: Scenario): QaPair[]
```

Returns a fixed set of Q&A pairs (decision rationale, cost, timing, GPU/tokens impact)
templated with the scenario's real numbers.

## Component/page changes

### Intake (`intake.tsx`) — goals #1, #2

- Replace the static chat transcript with a **PUMA event banner**: "Event received from
  PUMA · `{eventId}` · `{receivedAt}`" plus tool chips from `pumaEvent.tools`.
- Keep the existing demand-field list; tag fields with a tool badge where relevant.
- Remove the non-functional free-text input (superseded by the shared chat drawer).

### Run Detail (`run.$id.tsx`) — goal #3

- Add a **Decision Banner** above the workflow graph: 3-state indicator sourced from
  `decisionBucket` (Absorb — No Action / GPU Provisioning Required / Rebalance
  Required), plus two stat tiles for `gpuImpact` and `tokensSecImpact`.
- Existing ladder table remains underneath as technical detail (collapsible for the
  requester persona — see below).
- Tag relevant evidence rows with tool badges (telemetry → Grafana, inventory snapshot →
  OpenShift).

### Forecast (`forecast.tsx`) — goal #4

- Add a what-if panel: growth-rate slider (-20%…+100%), spike toggle (+40% for 2 weeks),
  GPU-pool-size slider. Feeds `applyWhatIf` via local React state; chart re-renders live,
  no server round-trip.
- Add a metric toggle to relabel the same underlying series as "GPU Impact" or
  "Tokens/sec Impact" (no new series, per reframing decision).
- Breach-day/order-by markers recompute live as sliders move.

### Capacity (`capacity.tsx`) — goal #6

- No structural changes to KPI tiles/pool table/heatmap.
- Add the shared chat drawer entry point.

### Conversational chat drawer — goals #5, #6

- New `src/components/ChatDrawer.tsx` using existing `Sheet`/`ScrollArea` primitives.
- Floating "Ask" trigger on Run Detail, Forecast, Capacity.
- Renders `buildQaScript(scenario)` as suggested-question chips; free text does keyword
  matching against `QaPair.keywords`, falling back to a generic capability message.
- Fully client-side and deterministic — no LLM call.

### Persona executive view (requester)

- In `AppShell`, expose `isExecutiveView = persona === "requester"`.
- New `src/components/ExecutiveSummaryCard.tsx`: plain-language card — "Your request
  needs `{gpuImpact.label}`. Decision: `{decisionBucket}`. Cost impact:
  `{ladder cost}`. Expected ready by `{date}`."
- Run Detail: show `ExecutiveSummaryCard` instead of the graph/ladder/evidence when
  `isExecutiveView`; technical blocks moved behind a `Collapsible` "Show technical
  detail".
- Forecast: keep the chart (visual, not jargon-heavy); hide what-if sliders behind
  "Show technical detail", show one plain "growth scenario" selector instead.
- Capacity: KPI tiles stay; pool table + heatmap behind "Show technical detail".
- Intake: PUMA event banner stays; field-provenance detail behind "Show technical
  detail".

## Addendum: Light/Dark theme toggle

Independent of the PUMA work. Current state: `src/styles.css` `:root` is actually the
dark "cyber-industrial" palette (despite the name), and the existing `.dark {}` block is
unused shadcn boilerplate with mismatched hues — there is no real light theme today.

- Design a new light oklch palette mirroring current brand/ok/warn/bad hues, with light
  surface/panel and dark text, replacing the current mismatched `.dark {}` block content
  so that `:root` = light, `.dark` = dark (matches the existing `@custom-variant dark
  (&:is(.dark *))` convention already in the CSS).
- Add a `theme` value (`"light" | "dark"`) to the existing `AppCtx` in `AppShell.tsx`,
  localStorage-backed like `persona`/`scenarioId`, defaulting to `"dark"`.
- Toggle applies the `dark` class to `<html>` (or a top-level wrapper) based on `theme`.
- UI: sun/moon icon button in the sidebar footer next to the telemetry status line.

## Testing/verification

- No automated tests exist for this app currently (visual/demo app). Verification is
  manual: run `bun run dev` (or `vite dev`), click through Inbox → Intake → Run Detail →
  Forecast → Capacity for each of the 3 scenarios and both personas
  (`capacity_manager`/`requester`), toggle theme, exercise what-if sliders, and open the
  chat drawer to confirm scripted answers render.
