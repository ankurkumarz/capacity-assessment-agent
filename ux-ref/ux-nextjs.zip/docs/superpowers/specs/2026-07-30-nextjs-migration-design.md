# Migrate to Next.js 16.2 + Tailwind 4.2.1

## Context

`gpu-guard` (CORE_COMPUTE) is currently a TanStack Start app: file-based routes under `src/routes/`, React 19, Tailwind 4.2.1 already in place, deployed to Cloudflare Workers via Nitro. All app state (persona, scenario, theme) lives in `localStorage` and React context — there is no real server-side data fetching, no `createServerFn` usage, and no active use of the `QueryClient` that's wired into the root route despite `@tanstack/react-query` being a dependency.

Goal: port the app to Next.js 16.2 App Router, exploring feasibility (no external driver — team standardization or missing features). Deploy target: plain Node.js server (`next start`), no Vercel- or Cloudflare-specific adapter.

Because there's no real data layer to redesign, this is a structural port: swap the routing/SSR framework, keep every page's UI and business logic (`src/lib/*`, `src/components/*`) untouched except for router-API call sites.

## Scope

In scope:
- Convert `src/routes/**` to Next.js App Router (`app/**`)
- Convert `src/routes/__root.tsx` to `app/layout.tsx`
- Swap TanStack Router APIs in `AppShell.tsx` (and any other consumer) for Next.js `next/link` / `next/navigation` equivalents
- Swap Tailwind's Vite plugin for the PostCSS plugin
- Replace Google Fonts `<link>` tags with `next/font/google`
- Replace Nitro/Cloudflare/h3-specific error plumbing with Next.js error boundaries
- Update `package.json`, `tsconfig.json`, ESLint config for Next.js
- Remove TanStack Start/Router/Vite/Nitro dependencies and files

Out of scope:
- Removing `@tanstack/react-query` / `QueryClientProvider` (unused today, but not part of a routing migration)
- Any behavior change to business logic in `src/lib/*` or `src/components/*` (besides router API calls)
- Deployment automation/CI changes beyond making `next build && next start` work

## Route mapping

| Current (TanStack Start) | New (Next.js App Router) | Notes |
|---|---|---|
| `src/routes/__root.tsx` | `app/layout.tsx` | Root `<html>`/`<body>`, metadata, fonts, `QueryClientProvider` |
| `src/routes/index.tsx` | `app/page.tsx` | `redirect("/inbox")` via `next/navigation` |
| `src/routes/inbox.tsx` | `app/inbox/page.tsx` | Static metadata |
| `src/routes/intake.tsx` | `app/intake/page.tsx` | Static metadata |
| `src/routes/capacity.tsx` | `app/capacity/page.tsx` | Static metadata |
| `src/routes/forecast.tsx` | `app/forecast/page.tsx` | Static metadata |
| `src/routes/registry.tsx` | `app/registry/page.tsx` | Static metadata |
| `src/routes/run.$id.tsx` | `app/run/[id]/page.tsx` | Dynamic metadata via `generateMetadata({ params })`; async `page.tsx` unwraps `params` and passes `id` to a `"use client"` component |

Each route's `head: () => ({ meta: [...] })` becomes `export const metadata: Metadata = {...}`, translated field-for-field (title, description, og:title, og:description, twitter:card, etc.).

Every existing route component uses hooks/state/effects, so each becomes (or delegates to) a `"use client"` component. Route-level `page.tsx` files stay server components only where they just export `metadata` and render the client component — `run/[id]/page.tsx` is async to await `params`.

## Router API translation

In `src/components/AppShell.tsx` and any other call sites:

| TanStack Router | Next.js |
|---|---|
| `Link` from `@tanstack/react-router` | `Link` from `next/link` |
| `useNavigate()` + `navigate({ to, params, search })` | `useRouter()` from `next/navigation`, `router.push(path)` with the path built as a plain string/query string |
| `useRouterState({ select: (s) => s.location.pathname })` | `usePathname()` from `next/navigation` |
| `useParams({ from: "/run/$id" })` | `params` prop passed down from the route's `page.tsx` |
| `useSearch({ from: "/run/$id" })` (reads `?run=`) | `useSearchParams()` from `next/navigation` |
| `validateSearch` | dropped; read `run` directly from `useSearchParams()` in the client component |

No changes to `usePersona`, `useScenario`, `useTheme`, or the context/localStorage logic in `AppShell.tsx` — only the router import source and call shapes change.

## Config & tooling changes

- **Removed files**: `vite.config.ts`, `src/router.tsx`, `src/routeTree.gen.ts`, `src/start.ts`, `src/server.ts`, `src/lib/error-capture.ts`, `src/lib/error-page.ts`
- **Added files**: `next.config.ts` (minimal — plain Node output), `postcss.config.mjs` (`@tailwindcss/postcss` plugin), `app/error.tsx`, `app/global-error.tsx`, `app/not-found.tsx`
- **`src/styles.css`** moves to `app/globals.css`, content unchanged (theme tokens, `@import "tailwindcss"`, `@source`, etc. — Tailwind v4 syntax is framework-agnostic)
- **Fonts**: `next/font/google` for Inter + JetBrains Mono in `app/layout.tsx`, exposed as CSS variables feeding the existing `--font-sans` / `--font-mono` theme tokens; drop the `<link rel="preconnect">` / Google Fonts stylesheet tags
- **Error handling**: `app/error.tsx` replaces the root route's `errorComponent` (`ErrorComponent`); `app/not-found.tsx` replaces `notFoundComponent` (`NotFoundComponent`); `app/global-error.tsx` is the top-level catch-all replacing the Nitro/h3 SSR-error-sniffing logic in `server.ts` — that logic is Cloudflare/h3-specific and has no Next.js equivalent, so it's deleted rather than ported
- **`package.json`**:
  - scripts: `dev` → `next dev`, `build` → `next build`, `start` → `next start` (drop `build:dev`/`preview`)
  - removed deps: `@tanstack/react-router`, `@tanstack/react-start`, `@tanstack/router-plugin`, `@tailwindcss/vite`, `vite`, `@vitejs/plugin-react`, `vite-tsconfig-paths`, `nitro`
  - added deps: `next@16.2`, `@tailwindcss/postcss`, `eslint-config-next`
  - kept as-is: `@tanstack/react-query`, `tailwindcss@4.2.1`, all Radix/UI/lib dependencies
- **`tsconfig.json`**: `moduleResolution: "bundler"`, add `plugins: [{ "name": "next" }]`, include `.next/types/**/*.ts`, `next-env.d.ts`
- **ESLint**: swap Vite/React-refresh-specific rules for `eslint-config-next`

## Testing / verification

- `next build` completes without type errors
- `next start` serves all six routes (`/`, `/inbox`, `/intake`, `/capacity`, `/forecast`, `/registry`, `/run/[id]`) with correct redirects, metadata, and no console errors
- Sidebar navigation (`AppShell`), scenario switching, persona switching, and theme toggle all still work (localStorage persistence, active-link highlighting)
- `/run/[id]?run=...` reads the search param correctly and renders the run detail view
- 404 and error boundary pages render as expected
