# Pluggable CopilotKit Assistant — Design

Date: 2026-07-30

## Context

CORE_COMPUTE currently provides scenario-aware, deterministic Q&A through
`src/components/ChatDrawer.tsx`. The product should optionally provide CopilotKit's
open-source chat experience backed by a configurable OpenAI-compatible endpoint, without
removing or coupling the application to the existing scripted assistant.

A separate LangGraph agent exists behind FastAPI, but it does not expose AG-UI. Connecting
that agent is explicitly deferred. This phase must not add an AG-UI endpoint or modify the
FastAPI service. The frontend boundary should permit that backend to replace the direct
model adapter later without another chat UI rewrite.

## Goals

1. Preserve the existing scripted `ChatDrawer` as the default assistant.
2. Add CopilotKit's chat UI as a deployment-selectable alternative.
3. Route CopilotKit requests through this application's server so model credentials never
   enter the browser bundle.
4. Support a configurable OpenAI-compatible base URL, API key, and model.
5. Give CopilotKit the active scenario as read-only context so answers remain relevant to
   GPU impact, recommendation, cost, and timeline.
6. Keep the provider boundary narrow enough to connect the existing LangGraph/FastAPI
   agent through AG-UI in a later phase.

## Non-goals

- No AG-UI endpoint or adapter.
- No connection to the existing LangGraph/FastAPI agent.
- No changes to the LangGraph graph or model configuration.
- No user-facing or per-session provider switch.
- No replacement of the existing scripted Q&A implementation.
- No browser-to-model requests and no browser-visible API credentials.

## Provider selection

The assistant provider is fixed at deployment/build time:

```env
VITE_ASSISTANT_PROVIDER=scripted
# or
VITE_ASSISTANT_PROVIDER=copilotkit
```

`scripted` is the default when the variable is absent or invalid. Invalid values also emit
a diagnostic warning. A single `ScenarioAssistant` component owns this selection, and
routes render that component rather than importing a concrete assistant implementation.

Provider implementations:

- `scripted` renders the existing `ChatDrawer` unchanged.
- `copilotkit` renders a CopilotKit provider and CopilotKit chat surface.

The selection is not stored in localStorage and cannot be changed by an end user.

## Server-side model configuration

CopilotKit mode reads server-only environment variables:

```env
OPENAI_BASE_URL=https://provider.example.com/v1
OPENAI_API_KEY=secret
OPENAI_MODEL=model-name
```

`OPENAI_BASE_URL` must target an API implementing the OpenAI-compatible chat-completions
contract expected by the selected CopilotKit service adapter. The base URL and model may
vary by deployment. `OPENAI_API_KEY` remains optional at the type/configuration level to
support trusted local endpoints that do not require authentication; when supplied, it is
sent only from the server.

None of these settings use the `VITE_` prefix. They must not be serialized into SSR output,
returned by a configuration endpoint, logged, or referenced from client modules.

## Architecture

The request path is:

```text
CopilotKit chat UI
  -> same-origin CopilotKit runtime endpoint in TanStack Start
  -> CopilotKit OpenAI-compatible service adapter
  -> configured model endpoint
```

The application adds the open-source CopilotKit React UI/core and runtime packages. The
server endpoint constructs its runtime and service adapter from server-only environment
variables. It accepts CopilotKit runtime requests and streams responses back using the
protocol expected by the CopilotKit React client.

CopilotKit-specific setup stays in focused modules:

- `ScenarioAssistant`: provider selection only.
- `ScriptedScenarioAssistant`: thin wrapper or direct delegation to `ChatDrawer`.
- `CopilotKitScenarioAssistant`: CopilotKit provider, chat surface, and scenario context.
- server runtime module/route: environment validation and model adapter construction.

Routes remain unaware of runtime URLs, model settings, or CopilotKit internals.

## Chat experience and scenario context

CopilotKit mode uses CopilotKit's standard chat surface, preserving its streaming,
conversation history, loading, and error UX. It retains the existing floating assistant
entry-point pattern where practical so switching providers does not restructure pages.

The active `Scenario` is transformed into a compact, read-only context object. It includes
only fields needed to answer user questions:

- request ID and use-case name;
- model and demand details;
- recommendation and decision bucket;
- GPU and tokens-per-second impact;
- cost and expected timeline/readiness values available in the scenario;
- evidence summaries needed to explain the recommendation.

The context is supplied through CopilotKit's supported readable-context mechanism, not by
copying the full application state into every component. Labels explain that this data is
a planning scenario and instruct the model to ground answers in it. No client-side action
or mutation tool is added in this phase.

When the selected scenario changes, the context updates. Conversation lifecycle follows
CopilotKit's default behavior; the context always identifies the current scenario so the
model can distinguish it from earlier messages.

## Configuration and failure behavior

Scripted mode has no CopilotKit runtime dependency and continues to work if all model
variables are absent.

In CopilotKit mode:

- missing `OPENAI_BASE_URL` or `OPENAI_MODEL` makes the runtime unavailable;
- malformed URLs and upstream authentication/network/model errors are converted to safe,
  actionable chat errors;
- server responses and logs never include API keys;
- configuration failure does not silently send traffic to OpenAI or another default host;
- the chat surface shows that the assistant is unavailable and directs operators to check
  deployment configuration.

The application does not silently change to scripted mode after a CopilotKit runtime
failure. Provider selection remains deterministic; an operator can select `scripted` in
the deployment environment when a guaranteed offline fallback is desired. Only an absent
or invalid `VITE_ASSISTANT_PROVIDER` resolves to scripted mode.

## Future LangGraph integration

A later phase can expose the FastAPI/LangGraph agent through AG-UI and register it with the
CopilotKit runtime. That change should replace the runtime's direct model registration,
not the route integrations or `CopilotKitScenarioAssistant`. The provider value can remain
`copilotkit`; AG-UI is a backend transport choice rather than a third visible assistant.

## Security

- Model credentials are read only in server code.
- The browser calls only a same-origin runtime endpoint.
- Existing TanStack Start request/error protections remain in effect.
- Errors returned to clients are sanitized.
- Scenario context contains existing demo/planning data only; no new secrets are added.
- Dependency versions are pinned by the repository lockfile and use CopilotKit's
  open-source packages rather than its hosted enterprise service.

## Testing and verification

Automated tests should cover focused logic where the repository setup permits:

1. Provider parsing defaults absent/unknown values to `scripted` and recognizes
   `copilotkit`.
2. Scenario serialization includes required planning context and excludes unrelated state.
3. Runtime configuration rejects missing base URL/model and accepts an API-key-free local
   endpoint.
4. Runtime errors are sanitized and never expose configured credentials.

Project verification:

- lint and production build pass;
- scripted mode renders and answers exactly as before;
- CopilotKit mode renders the CopilotKit chat experience;
- a mock or test OpenAI-compatible endpoint receives the configured model and chat request;
- changing scenarios updates readable context;
- missing configuration produces the explicit unavailable state;
- built client assets and browser-visible requests contain no API key;
- no request is made to an implicit/default OpenAI endpoint;
- existing Run Detail, Forecast, and Capacity assistant entry points work in both provider
  builds.

## Documentation

Add an example environment file or README section documenting:

- both supported values of `VITE_ASSISTANT_PROVIDER`;
- the three server-side OpenAI-compatible settings;
- that `OPENAI_API_KEY` may be omitted only for endpoints that intentionally require no
  authentication;
- that CopilotKit currently talks directly to the model and not to LangGraph;
- that AG-UI integration is deferred.
